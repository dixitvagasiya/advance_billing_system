"""Preview Invoice page + Download PDF (xhtml2pdf), with data read from the DB."""
import re
from datetime import date
from decimal import Decimal
from io import BytesIO

from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse
from pypdf import PdfReader

from accounts.models import UserProfile

from .models import Invoice, InvoiceItem


def user(email, role=UserProfile.ROLE_DISTRIBUTOR):
    u = User.objects.create_user(username=email, email=email, password='x', first_name='Dist', last_name='Ributor')
    UserProfile.objects.create(user=u, role=role)
    return u


class _Base(TestCase):
    def setUp(self):
        self.dist = user('d@x.com')
        self.other = user('o@x.com')
        self.admin = user('a@x.com', UserProfile.ROLE_ADMIN)
        self.client.force_login(self.dist)
        self.inv = Invoice.objects.create(distributor=self.dist, customer_name='Zenith Traders',
                                          issue_date=date(2026, 10, 12), due_date=date(2026, 11, 12))
        InvoiceItem.objects.create(invoice=self.inv, description='Basmati Rice', quantity=2,
                                   unit_price=Decimal('1850'), gst_percent=Decimal('5'))
        self.inv.refresh_from_db()

    def pdf(self, query=''):
        resp = self.client.get(reverse('invoice_pdf', args=[self.inv.pk]) + query)
        self.assertEqual(resp.status_code, 200)
        return resp


class PreviewAndPDFTests(_Base):
    # ---- Preview page
    def test_preview_url_and_detail_url_both_work(self):
        for name in ('invoice_preview', 'invoice_detail'):
            resp = self.client.get(reverse(name, args=[self.inv.pk]))
            self.assertEqual(resp.status_code, 200, name)
            self.assertContains(resp, 'Preview Invoice')

    def test_preview_shows_id_customer_total_date_from_the_database(self):
        resp = self.client.get(reverse('invoice_preview', args=[self.inv.pk]))
        record = resp.context['record']
        self.assertEqual(record['invoice_number'], self.inv.invoice_number)
        self.assertEqual(record['customer_name'], 'Zenith Traders')
        self.assertEqual(record['total_amount'], Decimal('3885.00'))
        self.assertEqual(record['issue_date'], date(2026, 10, 12))
        for text in (self.inv.invoice_number, 'Zenith Traders', '₹3885.00', '12 Oct 2026', 'Basmati Rice'):
            self.assertContains(resp, text)

    def test_preview_reflects_database_changes(self):
        Invoice.objects.filter(pk=self.inv.pk).update(customer_name='Renamed Ltd')
        self.assertContains(self.client.get(reverse('invoice_preview', args=[self.inv.pk])), 'Renamed Ltd')

    def test_preview_has_qr_and_download_button(self):
        html = self.client.get(reverse('invoice_preview', args=[self.inv.pk])).content.decode()
        self.assertIn('src="data:image/png;base64,', html)
        self.assertIn(reverse('invoice_pdf', args=[self.inv.pk]) + '?download=1', html)
        self.assertIn('Download PDF', html)

    def test_list_links_to_preview(self):
        self.assertContains(self.client.get(reverse('invoice_list')), reverse('invoice_preview', args=[self.inv.pk]))

    def test_preview_access_control(self):
        url = reverse('invoice_preview', args=[self.inv.pk])
        self.assertEqual(Client().get(url).status_code, 302)                 # anonymous -> login
        c = Client(); c.force_login(self.other)
        self.assertEqual(c.get(url).status_code, 404)                        # someone else's invoice
        c = Client(); c.force_login(self.admin)
        self.assertEqual(c.get(url).status_code, 200)                        # admin sees all

    # ---- PDF

    def test_download_headers(self):
        resp = self.pdf('?download=1')
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        self.assertEqual(resp['Content-Disposition'], f'attachment; filename="{self.inv.invoice_number}.pdf"')
        self.assertTrue(resp.content.startswith(b'%PDF'))
        self.assertTrue(self.pdf()['Content-Disposition'].startswith('inline'))

    def test_pdf_contains_id_customer_total_date_and_qr(self):
        reader = PdfReader(BytesIO(self.pdf('?download=1').content))
        text = ' '.join(page.extract_text() for page in reader.pages)
        for expected in (self.inv.invoice_number, 'Zenith Traders', '3,885.00', '12 Oct 2026', 'Basmati Rice'):
            self.assertIn(expected, text)
        images = [img for page in reader.pages for img in page.images]
        self.assertEqual(len(images), 2)                                      # logo + QR

    def test_pdf_updates_after_data_changes(self):
        InvoiceItem.objects.create(invoice=self.inv, description='Extra', quantity=1, unit_price=Decimal('100'))
        text = ' '.join(p.extract_text() for p in PdfReader(BytesIO(self.pdf().content)).pages)
        self.assertIn('Extra', text)
        self.assertIn('3,985.00', text)

    def test_pdf_total_equals_stored_total(self):
        self.inv.refresh_from_db()
        text = ' '.join(p.extract_text() for p in PdfReader(BytesIO(self.pdf().content)).pages)
        self.assertIn(f'{self.inv.total_amount:,.2f}', text)

    def test_pdf_access_control(self):
        url = reverse('invoice_pdf', args=[self.inv.pk])
        self.assertEqual(Client().get(url).status_code, 302)
        c = Client(); c.force_login(self.other)
        self.assertEqual(c.get(url).status_code, 404)


class PDFLayoutTests(_Base):
    """Layout details of the exported PDF (inherits the fixture; re-runs are cheap)."""

    def reader(self):
        return PdfReader(BytesIO(self.pdf().content))

    def test_single_a4_page_with_metadata(self):
        r = self.reader()
        self.assertEqual(len(r.pages), 1)
        self.assertEqual(round(float(r.pages[0].mediabox.width)), 595)       # A4
        self.assertIn(self.inv.invoice_number, r.metadata.title)
        self.assertIn('Zenith Traders', r.metadata.title)

    def test_embedded_qr_is_the_stored_qr(self):
        """The QR drawn in the PDF is the PNG saved on the invoice, pixel for pixel."""
        from PIL import Image
        self.inv.refresh_from_db()
        stored = Image.open(BytesIO(bytes(self.inv.qr_png))).convert('L')
        found = []
        for img in self.reader().pages[0].images:
            pil = img.image.convert('L')
            if pil.size == stored.size:
                found.append(list(pil.getdata()) == list(stored.getdata()))
        self.assertEqual(found, [True])

    def test_qr_caption_and_paid_stamp(self):
        text = self.reader().pages[0].extract_text()
        self.assertIn('Scan for invoice summary', text)
        self.assertNotIn('PAID', text)
        Invoice.objects.filter(pk=self.inv.pk).update(status=Invoice.STATUS_PAID)
        self.assertIn('PAID', self.reader().pages[0].extract_text())

    def test_many_items_flow_onto_extra_pages_with_footer(self):
        for n in range(40):
            InvoiceItem.objects.create(invoice=self.inv, description=f'Item {n}', quantity=1, unit_price=Decimal('10'))
        r = self.reader()
        self.assertGreater(len(r.pages), 1)
        self.assertIn(f'Page {len(r.pages)} of {len(r.pages)}', r.pages[-1].extract_text().replace('\n', ' '))
