from django import forms
from django.contrib.auth.models import User

from accounts.models import UserProfile


class DateRangeForm(forms.Form):
    """Optional issue-date range (inclusive) shared by every report."""

    date_from = forms.DateField(
        required=False, input_formats=['%Y-%m-%d'], label='From',
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'field-input'}),
    )
    date_to = forms.DateField(
        required=False, input_formats=['%Y-%m-%d'], label='To',
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'field-input'}),
    )

    def clean(self):
        cleaned = super().clean()
        start, end = cleaned.get('date_from'), cleaned.get('date_to')
        if start and end and start > end:
            self.add_error('date_to', 'The end date cannot be before the start date.')
        return cleaned


class StockThresholdForm(forms.Form):
    """'Low stock' cut-off for the inventory section of the product report."""

    low_stock = forms.IntegerField(
        required=False, min_value=0, max_value=100000, label='Low stock at or below',
        widget=forms.NumberInput(attrs={'class': 'field-input', 'min': '0'}),
    )


class InvoiceReportForm(forms.Form):
    """The 'Generate report' form: a required date range plus optional narrowing."""

    STATUS_CHOICES = (('', 'All statuses'), ('paid', 'Paid'), ('unpaid', 'Unpaid'), ('overdue', 'Overdue'))

    date_from = forms.DateField(
        input_formats=['%Y-%m-%d'], label='From date',
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'field-input'}, format='%Y-%m-%d'),
        error_messages={'required': 'Choose a start date.', 'invalid': 'Enter a valid start date.'},
    )
    date_to = forms.DateField(
        input_formats=['%Y-%m-%d'], label='To date',
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'field-input'}, format='%Y-%m-%d'),
        error_messages={'required': 'Choose an end date.', 'invalid': 'Enter a valid end date.'},
    )
    status = forms.ChoiceField(
        choices=STATUS_CHOICES, required=False, label='Status',
        widget=forms.Select(attrs={'class': 'field-input'}),
    )
    distributor = forms.ModelChoiceField(
        queryset=User.objects.filter(profile__role=UserProfile.ROLE_DISTRIBUTOR).order_by('first_name', 'username'),
        required=False, empty_label='All distributors', label='Distributor',
        widget=forms.Select(attrs={'class': 'field-input'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['distributor'].label_from_instance = lambda u: u.get_full_name() or u.username

    def clean(self):
        cleaned = super().clean()
        start, end = cleaned.get('date_from'), cleaned.get('date_to')
        if start and end and start > end:
            self.add_error('date_to', 'The end date cannot be before the start date.')
        return cleaned
