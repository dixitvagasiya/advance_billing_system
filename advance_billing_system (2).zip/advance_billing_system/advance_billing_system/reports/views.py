import csv
from datetime import date, timedelta
from urllib.parse import urlencode

from django.http import HttpResponse
from django.shortcuts import render
from django.utils import timezone

from accounts.decorators import admin_required
from billing.pdf import PDFGenerationError

from . import logic, services
from .forms import DateRangeForm, InvoiceReportForm, StockThresholdForm
from .pdf import render_report_pdf

TOP_PRODUCTS_SHOWN = 25
INVOICE_ROWS_SHOWN = 200


# ---------------------------------------------------------------------------
# Export helpers (CSV + PDF share one table description per report)
#
# A table is {'title', 'headers', 'kinds', 'rows', 'empty'}; `kinds` says how
# each column is typed (text / int / qty / money / date) so the PDF can align
# and format it, while the CSV keeps the raw values.
# ---------------------------------------------------------------------------

def _csv_response(filename, table):
    response = HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    response.write('\ufeff')            # BOM so Excel reads UTF-8 (₹, accents) correctly
    writer = csv.writer(response)
    writer.writerow(table['headers'])
    for row in table['rows']:
        writer.writerow([logic.csv_cell(cell) for cell in row])
    return response


def _pdf_response(filename, title, subtitle, summary, sections, today):
    try:
        pdf = render_report_pdf(title=title, subtitle=subtitle, summary=summary,
                                sections=sections, generated_on=today)
    except PDFGenerationError:
        return HttpResponse('The PDF could not be generated. Please try again.', status=500,
                            content_type='text/plain')
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}.pdf"'
    return response


def _headline(totals):
    """The figures shown above PDF tables."""
    return [
        ('Invoices', str(totals.count)),
        ('Total billed', logic.format_money(totals.total)),
        ('Amount collected', logic.format_money(totals.paid)),
        ('Outstanding', logic.format_money(totals.outstanding)),
        ('Overdue', logic.format_money(totals.overdue)),
    ]


def _financial_year_start(today):
    return date(today.year if today.month >= 4 else today.year - 1, 4, 1)


def _presets(today, date_from, date_to, extra=None):
    candidates = [
        ('This month', today.replace(day=1), today),
        ('Last 30 days', today - timedelta(days=29), today),
        ('This financial year', _financial_year_start(today), today),
        ('This year', date(today.year, 1, 1), today),
    ]
    out = []
    for label, start, end in candidates:
        params = dict(extra or {})
        params.update({'date_from': start.isoformat(), 'date_to': end.isoformat()})
        out.append({'label': label, 'qs': urlencode(params), 'active': (start, end) == (date_from, date_to)})
    return out


def _range_context(request, today):
    """Validate the optional ?date_from / ?date_to filter shared by the reports.

    Returns (date_from, date_to, context). An invalid range is reported on the
    form and the report falls back to 'all time' rather than guessing.
    """
    form = DateRangeForm(request.GET)
    date_from = date_to = None
    if form.is_valid():
        date_from, date_to = form.cleaned_data['date_from'], form.cleaned_data['date_to']

    params = {}
    if date_from:
        params['date_from'] = date_from.isoformat()
    if date_to:
        params['date_to'] = date_to.isoformat()

    return date_from, date_to, {
        'form': form, 'presets': _presets(today, date_from, date_to), 'qs': urlencode(params),
        'date_from': date_from, 'date_to': date_to, 'filtered': bool(params),
    }


# ---------------------------------------------------------------------------
# Reports (all admin-only)
# ---------------------------------------------------------------------------

@admin_required
def overview_view(request):
    """Sales overview: headline numbers plus a month-by-month breakdown."""
    today = timezone.localdate()
    date_from, date_to, ctx = _range_context(request, today)
    figures = services.collect(date_from, date_to, today)
    months = services.monthly(figures)
    totals = services.summarise(figures)

    export = request.GET.get('export')
    if export in ('csv', 'pdf'):
        table = {
            'title': 'Sales by month', 'empty': 'No invoices were issued in this period.',
            'headers': ['Month', 'Invoices', 'Subtotal', 'Discount', 'GST', 'Total billed', 'Collected', 'Outstanding'],
            'kinds': ['text', 'int', 'money', 'money', 'money', 'money', 'money', 'money'],
            'rows': [[m['month'].strftime('%b %Y'), m['totals'].count, m['totals'].subtotal, m['totals'].discount,
                      m['totals'].tax, m['totals'].total, m['totals'].paid, m['totals'].outstanding] for m in months],
        }
        name = f'sales-by-month-{today.isoformat()}'
        if export == 'csv':
            return _csv_response(name, table)
        return _pdf_response(name, 'Sales overview', logic.range_label(date_from, date_to),
                             _headline(totals), [table], today)

    ctx.update({'section': 'overview', 'totals': totals, 'months': months})
    return render(request, 'reports/overview.html', ctx)


@admin_required
def distributors_view(request):
    today = timezone.localdate()
    date_from, date_to, ctx = _range_context(request, today)
    figures = services.collect(date_from, date_to, today)
    rows = services.by_distributor(figures)
    totals = services.summarise(figures)

    export = request.GET.get('export')
    if export in ('csv', 'pdf'):
        table = {
            'title': 'Distributors', 'empty': 'No distributors have registered yet.',
            'headers': ['Distributor', 'Email', 'Invoices', 'Total billed', 'Collected',
                        'Outstanding', 'Overdue', 'Customers', 'Products'],
            'kinds': ['text', 'text', 'int', 'money', 'money', 'money', 'money', 'int', 'int'],
            'rows': [[r['name'], r['user'].email or r['user'].username, r['totals'].count, r['totals'].total,
                      r['totals'].paid, r['totals'].outstanding, r['totals'].overdue, r['customers'], r['products']]
                     for r in rows],
        }
        name = f'distributors-{today.isoformat()}'
        if export == 'csv':
            return _csv_response(name, table)
        return _pdf_response(name, 'Distributors report', logic.range_label(date_from, date_to),
                             _headline(totals), [table], today)

    ctx.update({'section': 'distributors', 'rows': rows, 'totals': totals})
    return render(request, 'reports/distributors.html', ctx)


@admin_required
def products_view(request):
    """Best sellers in the period + current stock alerts."""
    today = timezone.localdate()
    date_from, date_to, ctx = _range_context(request, today)

    stock_form = StockThresholdForm(request.GET)
    threshold = services.DEFAULT_LOW_STOCK
    if stock_form.is_valid() and stock_form.cleaned_data['low_stock'] is not None:
        threshold = stock_form.cleaned_data['low_stock']

    sales = services.product_sales(date_from, date_to)
    alerts = services.stock_alerts(threshold)

    sales_table = {
        'title': 'Best sellers', 'empty': 'No products were billed in this period.',
        'headers': ['Product', 'In catalog', 'Units sold', 'Invoices', 'Net sales', 'GST'],
        'kinds': ['text', 'text', 'qty', 'int', 'money', 'money'],
        'rows': [[r['name'], 'No (removed)' if r['removed'] else 'Yes', r['units'], r['invoices'], r['net'], r['gst']]
                 for r in sales],
    }
    stock_table = {
        'title': f'Stock alerts (at or below {threshold})', 'empty': f'No products are at or below {threshold} units.',
        'headers': ['Product', 'Category', 'Distributor', 'Stock', 'Price'],
        'kinds': ['text', 'text', 'text', 'int', 'money'],
        'rows': [[p.name, p.category, services.display_name(p.distributor), p.stock, p.price] for p in alerts],
    }

    export = request.GET.get('export')
    if export == 'sales':
        return _csv_response(f'product-sales-{today.isoformat()}', sales_table)
    if export == 'stock':
        return _csv_response(f'low-stock-{today.isoformat()}', stock_table)
    if export == 'pdf':
        totals = services.summarise(services.collect(date_from, date_to, today))
        summary = [('Invoices', str(totals.count)), ('Amount collected', logic.format_money(totals.paid)),
                   ('Products sold', str(len(sales))), ('Low / out of stock', str(len(alerts)))]
        return _pdf_response(f'products-and-stock-{today.isoformat()}', 'Products & stock report',
                             logic.range_label(date_from, date_to), summary, [sales_table, stock_table], today)

    ctx.update({
        'section': 'products',
        'totals': services.summarise(services.collect(date_from, date_to, today)),
        'sales': sales[:TOP_PRODUCTS_SHOWN], 'sales_total': len(sales),
        'alerts': alerts, 'threshold': threshold, 'stock_form': stock_form,
        'out_of_stock': sum(1 for p in alerts if p.stock == 0),
    })
    return render(request, 'reports/products.html', ctx)


@admin_required
def receivables_view(request):
    """Money still owed as of today, aged by days past due. Not date-filtered."""
    today = timezone.localdate()
    rows, aging = services.receivables(today)
    owed_total = sum((r['total'] for r in rows), logic.ZERO)

    export = request.GET.get('export')
    if export in ('csv', 'pdf'):
        table = {
            'title': 'Outstanding invoices', 'empty': 'Nothing outstanding.',
            'headers': ['Invoice', 'Customer', 'Distributor', 'Issued', 'Due', 'Status', 'Days overdue', 'Ageing', 'Amount'],
            'kinds': ['text', 'text', 'text', 'date', 'date', 'text', 'int', 'text', 'money'],
            'rows': [[r['invoice'].invoice_number, r['invoice'].customer_name, services.display_name(r['invoice'].distributor),
                      r['invoice'].issue_date, r['invoice'].due_date, r['status'].title(), r['days'], r['bucket'], r['total']]
                     for r in rows],
        }
        name = f'receivables-{today.isoformat()}'
        if export == 'csv':
            return _csv_response(name, table)
        summary = [('Invoices owed', str(len(rows))), ('Total owed', logic.format_money(owed_total))]
        summary += [(a['label'], logic.format_money(a['amount'])) for a in aging if a['count']][:3]
        return _pdf_response(name, 'Receivables report', f'Outstanding as of {logic.format_cell("date", today)}',
                             summary, [table], today)

    return render(request, 'reports/receivables.html', {
        'section': 'receivables', 'rows': rows, 'aging': aging, 'owed_total': owed_total, 'today': today,
    })


@admin_required
def invoices_view(request):
    """Report generation form: pick a date range (and optionally a status or
    distributor), generate the invoice list, then view, print or download it."""
    today = timezone.localdate()
    submitted = 'generate' in request.GET
    initial = {'date_from': today.replace(day=1), 'date_to': today}
    form = InvoiceReportForm(request.GET) if submitted else InvoiceReportForm(initial=initial)

    ctx = {'section': 'invoices', 'form': form, 'submitted': submitted, 'generated': False}
    if not (submitted and form.is_valid()):
        ctx['presets'] = _presets(today, None, None, {'generate': '1'})
        return render(request, 'reports/invoices.html', ctx)

    date_from, date_to = form.cleaned_data['date_from'], form.cleaned_data['date_to']
    status, distributor = form.cleaned_data['status'], form.cleaned_data['distributor']

    figures = services.collect(date_from, date_to, today, distributor=distributor)
    if status:
        figures = [f for f in figures if f.status == status]
    figures.sort(key=lambda f: (f.invoice.issue_date, f.invoice.invoice_number), reverse=True)
    totals = services.summarise(figures)

    params = {'generate': '1', 'date_from': date_from.isoformat(), 'date_to': date_to.isoformat()}
    if status:
        params['status'] = status
    if distributor:
        params['distributor'] = distributor.pk

    scope = []
    if status:
        scope.append(status.title())
    if distributor:
        scope.append(services.display_name(distributor))
    subtitle = logic.range_label(date_from, date_to) + (f' · {" · ".join(scope)}' if scope else '')

    export = request.GET.get('export')
    if export in ('csv', 'pdf'):
        table = {
            'title': 'Invoices', 'empty': 'No invoices match these filters.',
            'headers': ['Invoice', 'Customer', 'Distributor', 'Issued', 'Due', 'Status', 'Subtotal', 'GST', 'Total'],
            'kinds': ['text', 'text', 'text', 'date', 'date', 'text', 'money', 'money', 'money'],
            'rows': [[f.invoice.invoice_number, f.invoice.customer_name, services.display_name(f.invoice.distributor),
                      f.invoice.issue_date, f.invoice.due_date, f.status.title(), f.subtotal, f.tax, f.total]
                     for f in figures],
        }
        name = f'invoices-{date_from.isoformat()}-to-{date_to.isoformat()}'
        if export == 'csv':
            return _csv_response(name, table)
        return _pdf_response(name, 'Invoice report', subtitle, _headline(totals), [table], today)

    ctx.update({
        'generated': True, 'totals': totals, 'subtitle': subtitle,
        'rows': figures[:INVOICE_ROWS_SHOWN], 'row_total': len(figures),
        'qs': urlencode(params), 'date_from': date_from, 'date_to': date_to,
        'presets': _presets(today, date_from, date_to, {'generate': '1'}),
    })
    return render(request, 'reports/invoices.html', ctx)
