"""Keep Invoice.total_amount in step with its line items."""
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver

from .models import Invoice, InvoiceItem


@receiver([post_save, post_delete], sender=InvoiceItem)
def sync_invoice_total(sender, instance, **kwargs):
    invoice = Invoice.objects.filter(pk=instance.invoice_id).first()
    if invoice is not None:          # None when the whole invoice is being cascade-deleted
        invoice.refresh_total_amount()
