"""Invoice data really is in the database: id, customer name, total amount, date."""
from datetime import date
from decimal import Decimal
from io import StringIO

from django.contrib.auth.models import User
from django.core.management import call_command
from django.core.management.base import CommandError
from django.db import connection
from django.test import TestCase

from accounts.models import UserProfile
from products.models import Product

from .models import Invoice, InvoiceItem


class InvoiceDataTests(TestCase):
    def setUp(self):
        self.dist = User.objects.create_user(username='d@x.com', email='d@x.com', password='x')
        UserProfile.objects.create(user=self.dist, role=UserProfile.ROLE_DISTRIBUTOR)

    def make(self, **kw):
        d = dict(distributor=self.dist, customer_name='Acme Traders', issue_date=date(2026, 10, 1))
        d.update(kw)
        return Invoice.objects.create(**d)

    def item(self, inv, qty='2', price='100', disc='10', gst='18', desc='Widget'):
        return InvoiceItem.objects.create(invoice=inv, description=desc, quantity=Decimal(qty),
                                          unit_price=Decimal(price), discount_percent=Decimal(disc),
                                          gst_percent=Decimal(gst))

    def test_columns_exist_in_the_table(self):
        with connection.cursor() as cur:
            cols = {c.name for c in connection.introspection.get_table_description(cur, 'billing_invoice')}
        for col in ('id', 'invoice_number', 'customer_name', 'total_amount', 'issue_date', 'created_at'):
            self.assertIn(col, cols)

    def test_saved_row_has_id_customer_total_and_date(self):
        inv = self.make()
        self.item(inv)                               # 200 - 10% = 180; +18% GST = 212.40
        row = Invoice.objects.values('id', 'invoice_number', 'customer_name', 'total_amount', 'issue_date').get(pk=inv.pk)
        self.assertEqual(row['customer_name'], 'Acme Traders')
        self.assertTrue(row['invoice_number'].startswith('INV-'))
        self.assertEqual(row['issue_date'], date(2026, 10, 1))
        self.assertEqual(row['total_amount'], Decimal('212.40'))

    def test_stored_total_matches_computed_property(self):
        inv = self.make()
        self.item(inv); self.item(inv, qty='3', price='49.99', disc='0', gst='5', desc='B')
        fresh = Invoice.objects.prefetch_related('items').get(pk=inv.pk)
        self.assertEqual(fresh.total_amount, fresh.total)

    def test_total_follows_item_edit_and_delete(self):
        inv = self.make()
        a = self.item(inv)
        b = self.item(inv, qty='1', price='50', disc='0', gst='0', desc='B')
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('262.40'))
        a.quantity = Decimal('1'); a.save()
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('156.20'))   # 90 x 1.18 = 106.20, plus 50
        b.delete()
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('106.20'))

    def test_legacy_invoice_wide_tax_is_included(self):
        inv = self.make(tax_percent=Decimal('10'))
        self.item(inv, qty='1', price='100', disc='0', gst='0')
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('110.00'))
        inv.tax_percent = Decimal('0'); inv.save()
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('100.00'))

    def test_empty_invoice_total_is_zero_and_deleting_invoice_is_safe(self):
        inv = self.make()
        self.item(inv)
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount.__class__, Decimal)
        inv.delete()
        self.assertFalse(Invoice.objects.exists())

    def test_invoice_numbers_are_unique_and_sequential(self):
        a, b = self.make(), self.make()
        self.assertNotEqual(a.invoice_number, b.invoice_number)
        self.assertLess(a.invoice_number, b.invoice_number)

    def test_verify_command_passes_on_good_data(self):
        inv = self.make(); self.item(inv)
        out = StringIO()
        call_command('verify_invoices', stdout=out)
        self.assertIn('OK', out.getvalue())
        self.assertIn('Acme Traders', out.getvalue())

    def test_verify_command_detects_and_fixes_bad_total(self):
        inv = self.make(); self.item(inv)
        Invoice.objects.filter(pk=inv.pk).update(total_amount=Decimal('1.00'))
        with self.assertRaises(CommandError):
            call_command('verify_invoices', stdout=StringIO())
        call_command('verify_invoices', '--fix', stdout=StringIO())
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('212.40'))

    def test_verify_command_flags_missing_customer_name(self):
        inv = self.make(); self.item(inv)
        Invoice.objects.filter(pk=inv.pk).update(customer_name='')
        with self.assertRaises(CommandError):
            call_command('verify_invoices', stdout=StringIO())
