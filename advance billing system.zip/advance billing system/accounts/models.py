import random
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone


class UserProfile(models.Model):
    """Extends Django's built-in User with a role and phone number.

    Role decides which login route / dashboard a user belongs to
    (task 2: separate Admin and Distributor routes).
    """

    ROLE_ADMIN = 'admin'
    ROLE_DISTRIBUTOR = 'distributor'
    ROLE_CHOICES = (
        (ROLE_ADMIN, 'Admin'),
        (ROLE_DISTRIBUTOR, 'Distributor'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_DISTRIBUTOR)
    phone = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.get_full_name() or self.user.username} ({self.get_role_display()})'


class OTP(models.Model):
    """One-time codes used for password reset (task 5 & 6).

    Codes are short-lived and single-use; validity window is controlled by
    settings.OTP_VALIDITY_MINUTES.
    """

    PURPOSE_PASSWORD_RESET = 'password_reset'
    PURPOSE_CHOICES = (
        (PURPOSE_PASSWORD_RESET, 'Password Reset'),
    )

    email = models.EmailField()
    code = models.CharField(max_length=6)
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES, default=PURPOSE_PASSWORD_RESET)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.email} · {self.code}'

    @property
    def is_expired(self):
        validity = getattr(settings, 'OTP_VALIDITY_MINUTES', 10)
        return timezone.now() > self.created_at + timedelta(minutes=validity)

    def is_valid(self):
        return not self.is_used and not self.is_expired

    @staticmethod
    def generate_code():
        return f'{random.randint(0, 999999):06d}'

    @classmethod
    def issue(cls, email, purpose=PURPOSE_PASSWORD_RESET):
        """Create a fresh OTP for an email, invalidating older unused ones."""
        cls.objects.filter(email=email, purpose=purpose, is_used=False).update(is_used=True)
        return cls.objects.create(email=email, code=cls.generate_code(), purpose=purpose)
