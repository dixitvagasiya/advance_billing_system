from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import UserProfile
from products.models import Product

from .forms import InvoiceForm, InvoiceItemFormSet
from .models import Invoice
from .pdf import render_invoice_pdf


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


@login_required(login_url='distributor_login')
def invoice_list_view(request):
    """Admins see every invoice; distributors see only their own."""
    invoices = Invoice.objects.select_related('distributor').prefetch_related('items')

    if not _is_admin(request.user):
        invoices = invoices.filter(distributor=request.user)

    status = request.GET.get('status')
    if status in dict(Invoice.STATUS_CHOICES):
        invoices = invoices.filter(status=status)

    paginator = Paginator(invoices, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'billing/invoice_list.html', {
        'page_obj': page_obj,
        'active_status': status or '',
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def invoice_create_view(request):
    """Task: create invoices. Restricted to distributors — they raise
    their own bills; admins get an oversight view via invoice_list_view.
    """
    if _is_admin(request.user):
        messages.info(request, 'Invoices are raised by distributor accounts.')
        return redirect('invoice_list')

    blank_invoice = Invoice(distributor=request.user)
    form = InvoiceForm(request.POST or None, instance=blank_invoice, distributor=request.user)
    formset = InvoiceItemFormSet(
        request.POST or None, instance=blank_invoice,
        form_kwargs={'distributor': request.user},
    )

    if request.method == 'POST' and form.is_valid() and formset.is_valid():
        # One transaction: the invoice and all its items are saved together
        # or not at all (no half-saved invoice if an item insert fails).
        with transaction.atomic():
            invoice = form.save(commit=False)
            invoice.distributor = request.user
            invoice.save()
            formset.instance = invoice
            formset.save()
        count = invoice.items.count()
        messages.success(
            request,
            f'Invoice {invoice.invoice_number} created successfully with '
            f'{count} item{"s" if count != 1 else ""}.',
        )
        return redirect('invoice_detail', pk=invoice.pk)

    return render(request, 'billing/invoice_form.html', {
        'form': form,
        'formset': formset,
        'has_customers': form.fields['customer'].queryset.exists(),
        'has_products': Product.objects.filter(distributor=request.user).exists(),
    })


def _invoice_for_user(request, pk):
    """Fetch an invoice the signed-in user may see: admins see all,
    distributors only their own (anyone else gets a 404, not a 403, so
    invoice ids can't be probed)."""
    qs = Invoice.objects.select_related('customer', 'distributor__profile').prefetch_related('items')
    if not _is_admin(request.user):
        qs = qs.filter(distributor=request.user)
    return get_object_or_404(qs, pk=pk)


@login_required(login_url='distributor_login')
def invoice_detail_view(request, pk):
    invoice = _invoice_for_user(request, pk)
    return render(request, 'billing/invoice_detail.html', {
        'invoice': invoice,
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def invoice_pdf_view(request, pk):
    """Branded PDF of one invoice. Opens in the browser by default;
    add ?download=1 to force a file download."""
    invoice = _invoice_for_user(request, pk)
    pdf = render_invoice_pdf(invoice)

    disposition = 'attachment' if request.GET.get('download') else 'inline'
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'{disposition}; filename="{invoice.invoice_number}.pdf"'
    return response
