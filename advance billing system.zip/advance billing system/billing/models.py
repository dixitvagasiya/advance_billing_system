from decimal import ROUND_HALF_UP, Decimal

from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils import timezone

CENT = Decimal('0.01')


def money(value):
    """Round to 2 dp, half-up. The invoice page's JavaScript rounds the same
    way at each step, so the live preview matches what gets saved."""
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)


class Invoice(models.Model):
    """A distributor-raised bill to a customer. Line items live in
    InvoiceItem; totals are computed from them rather than stored,
    so they can never drift out of sync.
    """

    STATUS_UNPAID = 'unpaid'
    STATUS_PAID = 'paid'
    STATUS_OVERDUE = 'overdue'
    STATUS_CHOICES = (
        (STATUS_UNPAID, 'Unpaid'),
        (STATUS_PAID, 'Paid'),
        (STATUS_OVERDUE, 'Overdue'),
    )

    distributor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='invoices')
    invoice_number = models.CharField(max_length=20, unique=True, editable=False)

    # Link to the customer book. SET_NULL so deleting a customer never
    # destroys financial records; the customer_* fields below are a snapshot
    # taken at billing time, so the invoice still reads correctly afterwards.
    # Nullable so invoices created before this link existed stay valid.
    customer = models.ForeignKey(
        'customers.Customer', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='invoices',
    )

    customer_name = models.CharField(max_length=150)
    customer_phone = models.CharField(max_length=15, blank=True)
    customer_email = models.EmailField(blank=True)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_UNPAID)
    issue_date = models.DateField(default=timezone.localdate)
    due_date = models.DateField(null=True, blank=True)
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0'))
    notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.invoice_number

    @classmethod
    def _next_invoice_number(cls):
        year = timezone.localdate().year
        prefix = f'INV-{year}-'
        last = (
            cls.objects.filter(invoice_number__startswith=prefix)
            .order_by('-invoice_number')
            .first()
        )
        last_seq = int(last.invoice_number.rsplit('-', 1)[-1]) if last else 0
        return f'{prefix}{last_seq + 1:04d}'

    def save(self, *args, **kwargs):
        if not self.invoice_number:
            self.invoice_number = self._next_invoice_number()
        super().save(*args, **kwargs)

    # Totals. Per-item GST and discount are summed from the line items.
    # `tax_percent` is the older invoice-wide tax; the invoice form no longer
    # sets it (always 0 on new invoices) but it is still honoured for invoices
    # that were created with it.
    @property
    def subtotal(self):
        """Sum of quantity x unit price, before discount and tax."""
        return sum((item.gross_amount for item in self.items.all()), Decimal('0'))

    @property
    def discount_total(self):
        return sum((item.discount_amount for item in self.items.all()), Decimal('0'))

    @property
    def taxable_total(self):
        return self.subtotal - self.discount_total

    @property
    def tax_amount(self):
        item_gst = sum((item.gst_amount for item in self.items.all()), Decimal('0'))
        legacy = money(self.taxable_total * self.tax_percent / Decimal('100'))
        return item_gst + legacy

    @property
    def total(self):
        return self.taxable_total + self.tax_amount

    @property
    def is_overdue(self):
        return (
            self.status == self.STATUS_UNPAID
            and self.due_date is not None
            and self.due_date < timezone.localdate()
        )


class InvoiceItem(models.Model):
    """One billed line. Amounts are computed, never stored:

        gross    = quantity x unit_price
        discount = gross x discount_percent
        taxable  = gross - discount
        gst      = taxable x gst_percent
        total    = taxable + gst

    Each step is rounded to 2 dp (half-up).
    """

    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='items')
    # SET_NULL, same reasoning as Invoice.customer: the line survives a
    # product being deleted; description / unit_price / gst_percent are the
    # billed snapshot.
    product = models.ForeignKey(
        'products.Product', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='invoice_items',
    )
    description = models.CharField(max_length=200)
    quantity = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal('1'),
        validators=[MinValueValidator(Decimal('0.01'), message='Quantity must be greater than 0.')],
    )
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2, default=Decimal('0'),
        validators=[MinValueValidator(Decimal('0'), message='Price cannot be negative.')],
    )
    discount_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal('0'),
        validators=[MinValueValidator(Decimal('0')), MaxValueValidator(Decimal('100'))],
        help_text='Discount percentage, 0-100.',
    )
    gst_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal('0'),
        validators=[MinValueValidator(Decimal('0')), MaxValueValidator(Decimal('100'))],
        help_text='GST percentage, 0-100.',
    )

    @property
    def gross_amount(self):
        return money(self.quantity * self.unit_price)

    @property
    def discount_amount(self):
        return money(self.gross_amount * self.discount_percent / Decimal('100'))

    @property
    def taxable_amount(self):
        return self.gross_amount - self.discount_amount

    @property
    def gst_amount(self):
        return money(self.taxable_amount * self.gst_percent / Decimal('100'))

    @property
    def line_total(self):
        """Final amount for the line, including GST."""
        return self.taxable_amount + self.gst_amount

    def __str__(self):
        return self.description
