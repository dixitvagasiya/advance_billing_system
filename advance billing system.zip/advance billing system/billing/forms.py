from django import forms

from customers.models import Customer
from products.models import Product

from .models import Invoice, InvoiceItem


def _style(field, placeholder=None, extra_classes=''):
    css = f'field-input {extra_classes}'.strip()
    field.widget.attrs['class'] = css
    if placeholder:
        field.widget.attrs['placeholder'] = placeholder
    return field


class DataAttrSelect(forms.Select):
    """<select> whose <option>s carry extra data-* attributes taken from the
    model instance, so JavaScript can read a customer's contact details or a
    product's price/GST without another request."""

    def __init__(self, *args, option_data=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.option_data = option_data or {}  # {pk: {'price': '10.00', ...}}

    def create_option(self, name, value, label, selected, index, subindex=None, attrs=None):
        option = super().create_option(name, value, label, selected, index, subindex=subindex, attrs=attrs)
        key = getattr(value, 'value', value)
        for attr, val in self.option_data.get(key, {}).items():
            option['attrs'][f'data-{attr}'] = val
        return option


class InvoiceForm(forms.ModelForm):
    class Meta:
        model = Invoice
        fields = ['customer', 'issue_date', 'due_date', 'notes']
        widgets = {
            'issue_date': forms.DateInput(attrs={'type': 'date'}),
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, distributor=None, **kwargs):
        super().__init__(*args, **kwargs)
        # Dropdown options come straight from the database, limited to the
        # signed-in distributor's own customer book.
        customers = Customer.objects.filter(distributor=distributor) if distributor else Customer.objects.none()
        field = self.fields['customer']
        field.widget = DataAttrSelect(option_data={
            c.pk: {'phone': c.phone, 'email': c.email, 'address': c.address} for c in customers
        })
        field.queryset = customers
        field.required = True
        field.empty_label = 'Select a customer'
        _style(field)
        _style(self.fields['issue_date'])
        _style(self.fields['due_date'])
        _style(self.fields['notes'], 'Optional — payment terms, references, etc.')
        self.fields['due_date'].required = False
        self.fields['notes'].required = False

    def save(self, commit=True):
        # Snapshot the customer's details onto the invoice.
        invoice = super().save(commit=False)
        customer = self.cleaned_data['customer']
        invoice.customer_name = customer.name
        invoice.customer_phone = customer.phone
        invoice.customer_email = customer.email
        if commit:
            invoice.save()
        return invoice


class InvoiceItemForm(forms.ModelForm):
    class Meta:
        model = InvoiceItem
        fields = ['product', 'quantity', 'unit_price', 'discount_percent', 'gst_percent']

    def __init__(self, *args, distributor=None, **kwargs):
        super().__init__(*args, **kwargs)
        products = Product.objects.filter(distributor=distributor) if distributor else Product.objects.none()
        field = self.fields['product']
        # Swap the widget first, then set the queryset, so the new widget
        # picks up the choices.
        field.widget = DataAttrSelect(option_data={
            p.pk: {'price': str(p.price), 'gst': str(p.gst_rate), 'stock': str(p.stock)} for p in products
        })
        field.queryset = products
        field.required = True
        field.empty_label = 'Select a product'
        _style(field)

        _style(self.fields['quantity'], extra_classes='field-narrow')
        self.fields['quantity'].widget.attrs.update({'min': '0.01', 'step': '0.01'})
        _style(self.fields['unit_price'], extra_classes='field-narrow')
        self.fields['unit_price'].widget.attrs.update({'min': '0', 'step': '0.01'})
        _style(self.fields['discount_percent'], extra_classes='field-narrow')
        self.fields['discount_percent'].widget.attrs.update({'min': '0', 'max': '100', 'step': '0.01'})
        _style(self.fields['gst_percent'], extra_classes='field-narrow')
        self.fields['gst_percent'].widget.attrs.update({'min': '0', 'max': '100', 'step': '0.01'})
        # Column headers already label these; no per-row help text (it would add aria-describedby ids).
        for name in ('discount_percent', 'gst_percent'):
            self.fields[name].help_text = ''

    def save(self, commit=True):
        # description is the billed snapshot of the product's name.
        item = super().save(commit=False)
        item.description = item.product.name
        if commit:
            item.save()
        return item


class BaseInvoiceItemFormSet(forms.BaseInlineFormSet):
    default_error_messages = {
        **forms.BaseInlineFormSet.default_error_messages,
        'too_few_forms': 'Add at least one product to the invoice.',
    }


InvoiceItemFormSet = forms.inlineformset_factory(
    Invoice,
    InvoiceItem,
    form=InvoiceItemForm,
    formset=BaseInvoiceItemFormSet,
    extra=0,            # min_num=1 already gives one blank row
    can_delete=False,   # rows are added/removed client-side; removed rows are simply not submitted
    min_num=1,
    validate_min=True,
)
