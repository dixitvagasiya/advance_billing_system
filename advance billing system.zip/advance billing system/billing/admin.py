from django.contrib import admin

from .models import Invoice, InvoiceItem


class InvoiceItemInline(admin.TabularInline):
    model = InvoiceItem
    extra = 0
    fields = ('product', 'description', 'quantity', 'unit_price', 'discount_percent', 'gst_percent')


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ('invoice_number', 'distributor', 'customer', 'customer_name', 'status', 'issue_date', 'due_date')
    list_filter = ('status',)
    search_fields = ('invoice_number', 'customer_name', 'distributor__username')
    readonly_fields = ('invoice_number', 'created_at')
    inlines = [InvoiceItemInline]
