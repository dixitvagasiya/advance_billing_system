"""Invoice -> PDF using xhtml2pdf (pure Python; no system libraries needed)."""
import os
from io import BytesIO

from django.conf import settings
from django.contrib.staticfiles import finders
from django.template.loader import render_to_string
from xhtml2pdf import pisa


class PDFGenerationError(Exception):
    pass


def _link_callback(uri, rel):
    """Let the PDF template reference {% static %} files (logo, fonts):
    map /static/... URLs to files on disk."""
    static_url = settings.STATIC_URL
    if uri.startswith(static_url):
        path = finders.find(uri[len(static_url):])
        if path and os.path.isfile(path):
            return path
    raise PDFGenerationError(f'Could not resolve resource for PDF: {uri}')


def render_invoice_pdf(invoice):
    """Return the invoice as PDF bytes."""
    html = render_to_string('billing/pdf_invoice.html', {
        'invoice': invoice,
        'items': list(invoice.items.all()),
        'brand': settings.INVOICE_BRANDING,
    })
    buffer = BytesIO()
    result = pisa.CreatePDF(src=html, dest=buffer, encoding='utf-8', link_callback=_link_callback)
    if result.err:
        raise PDFGenerationError(f'PDF rendering failed with {result.err} error(s).')
    return buffer.getvalue()
