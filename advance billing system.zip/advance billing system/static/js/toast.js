/* Toast notifications: auto-dismiss + manual close. Toasts are rendered by
 * the server (Django messages); errors stay until closed, others fade out. */
(function () {
  'use strict';
  var stack = document.getElementById('toast-stack');
  if (!stack) return;

  function dismiss(toast) {
    if (!toast || toast.classList.contains('toast-leaving')) return;
    toast.classList.add('toast-leaving');
    setTimeout(function () { toast.remove(); }, 300);
  }

  stack.querySelectorAll('.toast').forEach(function (toast, i) {
    // stagger the entrance slightly when several arrive together
    toast.style.animationDelay = (i * 90) + 'ms';
    if (!toast.classList.contains('toast-error')) {
      var timer = setTimeout(function () { dismiss(toast); }, 6000 + i * 600);
      // pause the countdown while the pointer is over the toast
      toast.addEventListener('mouseenter', function () { clearTimeout(timer); });
      toast.addEventListener('mouseleave', function () {
        timer = setTimeout(function () { dismiss(toast); }, 2500);
      });
    }
  });

  stack.addEventListener('click', function (e) {
    if (e.target.classList.contains('toast-close')) dismiss(e.target.closest('.toast'));
  });
})();
