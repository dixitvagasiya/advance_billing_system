/*
 * Invoice form: dynamic product rows + live totals.
 *
 * Per-line maths (must match billing/models.py InvoiceItem):
 *   gross    = qty x unit price
 *   discount = gross x discount%
 *   taxable  = gross - discount
 *   gst      = taxable x gst%
 *   total    = taxable + gst
 * Each step is rounded to 2 dp (half-up), exactly like the server, so the
 * preview matches the saved invoice. The server recalculates on save; this
 * is display only.
 */
(function () {
  'use strict';

  var form = document.getElementById('invoice-form');
  if (!form) return;

  var rows = document.getElementById('item-rows');
  var addBtn = document.getElementById('add-item-row');
  var totalForms = document.getElementById('id_items-TOTAL_FORMS');
  var maxForms = document.getElementById('id_items-MAX_NUM_FORMS');
  var template = document.getElementById('empty-row-template').innerHTML;

  // ---- maths -------------------------------------------------------------

  // Round to 2 dp, half-up. toPrecision strips float noise (e.g. 1.005*100).
  function round2(n) {
    return Math.round(Number((n * 100).toPrecision(15))) / 100;
  }

  function num(input) {
    var v = parseFloat(input && input.value);
    return isFinite(v) && v > 0 ? v : 0;   // blank / negative counts as 0
  }

  function calcLine(qty, price, discountPct, gstPct) {
    var gross = round2(qty * price);
    var discount = round2(gross * Math.min(discountPct, 100) / 100);
    var taxable = round2(gross - discount);
    var gst = round2(taxable * Math.min(gstPct, 100) / 100);
    return { gross: gross, discount: discount, gst: gst, total: round2(taxable + gst) };
  }

  function money(n) {
    return '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function field(row, suffix) {
    return row.querySelector('[name$="-' + suffix + '"]');
  }

  function recalc() {
    var sum = { gross: 0, discount: 0, gst: 0, total: 0 };
    rows.querySelectorAll('.item-row').forEach(function (row) {
      var line = calcLine(
        num(field(row, 'quantity')), num(field(row, 'unit_price')),
        num(field(row, 'discount_percent')), num(field(row, 'gst_percent'))
      );
      row.querySelector('.line-total').textContent = money(line.total);
      sum.gross += line.gross;
      sum.discount += line.discount;
      sum.gst += line.gst;
      sum.total += line.total;
    });
    document.getElementById('preview-subtotal').textContent = money(round2(sum.gross));
    document.getElementById('preview-discount').textContent = '−' + money(round2(sum.discount));
    document.getElementById('preview-gst').textContent = money(round2(sum.gst));
    document.getElementById('preview-total').textContent = money(round2(sum.total));
  }

  // ---- product picked: pull price + GST from the catalogue -----------------

  rows.addEventListener('change', function (e) {
    if (!e.target.matches('select[name$="-product"]')) return;
    var row = e.target.closest('tr');
    var opt = e.target.options[e.target.selectedIndex];
    if (opt && opt.value) {
      field(row, 'unit_price').value = opt.getAttribute('data-price') || 0;
      field(row, 'gst_percent').value = opt.getAttribute('data-gst') || 0;
      var qty = field(row, 'quantity');
      if (!parseFloat(qty.value)) qty.value = 1;
    }
    recalc();
  });

  rows.addEventListener('input', function (e) {
    if (e.target.matches('input')) recalc();
  });

  // ---- add / remove rows (no page reload) -----------------------------------

  // Keep form indices 0..n-1 contiguous and TOTAL_FORMS in step, so Django
  // sees exactly the rows on screen.
  function reindex() {
    var list = rows.querySelectorAll('.item-row');
    list.forEach(function (row, i) {
      row.querySelectorAll('[name], [id], [for], [aria-describedby]').forEach(function (el) {
        ['name', 'id', 'for', 'aria-describedby'].forEach(function (attr) {
          var v = el.getAttribute(attr);
          if (v) el.setAttribute(attr, v.replace(/items-(\d+|__prefix__)-/, 'items-' + i + '-'));
        });
      });
    });
    totalForms.value = list.length;
    updateAddState();
  }

  function updateAddState() {
    var max = parseInt(maxForms.value, 10) || 1000;
    addBtn.disabled = rows.querySelectorAll('.item-row').length >= max;
  }

  addBtn.addEventListener('click', function () {
    var holder = document.createElement('tbody');
    holder.innerHTML = template.trim();
    var row = holder.firstElementChild;
    rows.appendChild(row);
    reindex();
    recalc();
    var select = row.querySelector('select');
    if (select) select.focus();
  });

  rows.addEventListener('click', function (e) {
    if (!e.target.classList.contains('remove-item')) return;
    var row = e.target.closest('tr');
    if (rows.querySelectorAll('.item-row').length > 1) {
      row.remove();
      reindex();
    } else {
      // Last remaining row: clear it instead of leaving the invoice with no rows.
      row.querySelectorAll('input:not([type=hidden])').forEach(function (i) { i.value = ''; });
      field(row, 'quantity').value = 1;
      field(row, 'unit_price').value = 0;
      field(row, 'discount_percent').value = 0;
      field(row, 'gst_percent').value = 0;
      field(row, 'product').selectedIndex = 0;
      row.querySelectorAll('.field-error').forEach(function (n) { n.remove(); });
    }
    recalc();
  });

  // ---- customer picked: show their details ---------------------------------

  var customerSelect = document.getElementById('id_customer');
  var details = document.getElementById('customer-details');

  function showCustomer() {
    var opt = customerSelect.options[customerSelect.selectedIndex];
    var parts = [];
    if (opt && opt.value) {
      ['phone', 'email', 'address'].forEach(function (k) {
        var v = opt.getAttribute('data-' + k);
        if (v) parts.push(v);
      });
    }
    details.textContent = parts.join(' · ');   // textContent: never inject as HTML
    details.hidden = parts.length === 0;
  }

  if (customerSelect && details) {
    customerSelect.addEventListener('change', showCustomer);
    showCustomer();
  }

  reindex();
  recalc();
})();
