from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import redirect, render

from accounts.models import UserProfile

from .forms import ProductForm
from .models import Product


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


@login_required(login_url='distributor_login')
def product_list_view(request):
    products = Product.objects.select_related('distributor')
    if not _is_admin(request.user):
        products = products.filter(distributor=request.user)

    query = request.GET.get('q', '').strip()
    if query:
        products = products.filter(Q(name__icontains=query) | Q(category__icontains=query))

    paginator = Paginator(products, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'products/product_list.html', {
        'page_obj': page_obj,
        'query': query,
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def product_create_view(request):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')

    form = ProductForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        product = form.save(commit=False)
        product.distributor = request.user
        product.save()
        messages.success(request, f'{product.name} added to your catalog.')
        return redirect('product_list')

    return render(request, 'products/product_form.html', {'form': form})
