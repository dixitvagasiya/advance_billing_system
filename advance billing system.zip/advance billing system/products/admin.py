from django.contrib import admin

from .models import Product


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'distributor', 'category', 'price', 'stock', 'gst_rate')
    list_filter = ('category',)
    search_fields = ('name', 'category', 'distributor__username')
