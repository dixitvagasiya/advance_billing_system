from django import forms

from .models import Product


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'category', 'price', 'stock', 'gst_rate']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': 'field-input', 'placeholder': 'Product or SKU name', 'autofocus': True})
        self.fields['category'].widget.attrs.update({'class': 'field-input', 'placeholder': 'e.g. Electronics'})
        self.fields['price'].widget.attrs.update({'class': 'field-input', 'placeholder': '0.00', 'step': '0.01', 'min': '0.01'})
        self.fields['stock'].widget.attrs.update({'class': 'field-input', 'placeholder': '0', 'min': '0'})
        self.fields['gst_rate'].widget.attrs.update({'class': 'field-input', 'placeholder': '0', 'step': '0.01', 'min': '0', 'max': '100'})
        self.fields['category'].required = False

    def clean_price(self):
        price = self.cleaned_data['price']
        if price <= 0:
            raise forms.ValidationError('Price must be greater than 0.')
        return price

    def clean_stock(self):
        stock = self.cleaned_data['stock']
        if stock < 0:
            raise forms.ValidationError('Stock cannot be negative.')
        return stock
