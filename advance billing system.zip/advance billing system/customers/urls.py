from django.urls import path

from . import views

urlpatterns = [
    path('', views.customer_list_view, name='customer_list'),
    path('new/', views.customer_create_view, name='customer_create'),
    path('<int:pk>/edit/', views.customer_update_view, name='customer_update'),
    path('<int:pk>/delete/', views.customer_delete_view, name='customer_delete'),
]
