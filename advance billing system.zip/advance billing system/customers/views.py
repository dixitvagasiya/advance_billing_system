from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.models import UserProfile

from .forms import CustomerForm
from .models import Customer


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


def _owned_or_404(request, pk):
    """Distributors may only touch their own customers; admins are
    read-only here (list view), so this is only used by the
    create/update/delete views, which are distributor-only.
    """
    return get_object_or_404(Customer, pk=pk, distributor=request.user)


@login_required(login_url='distributor_login')
def customer_list_view(request):
    customers = Customer.objects.select_related('distributor')
    if not _is_admin(request.user):
        customers = customers.filter(distributor=request.user)

    query = request.GET.get('q', '').strip()
    if query:
        customers = customers.filter(
            Q(name__icontains=query) | Q(email__icontains=query) | Q(phone__icontains=query)
        )

    paginator = Paginator(customers, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'customers/customer_list.html', {
        'page_obj': page_obj,
        'query': query,
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def customer_create_view(request):
    if _is_admin(request.user):
        messages.info(request, 'Customers are managed by distributor accounts.')
        return redirect('customer_list')

    form = CustomerForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        customer = form.save(commit=False)
        customer.distributor = request.user
        customer.save()
        messages.success(request, f'{customer.name} added to your customers.')
        return redirect('customer_list')

    return render(request, 'customers/customer_form.html', {'form': form, 'is_edit': False})


@login_required(login_url='distributor_login')
def customer_update_view(request, pk):
    customer = _owned_or_404(request, pk)
    form = CustomerForm(request.POST or None, instance=customer)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, f'{customer.name} updated.')
        return redirect('customer_list')

    return render(request, 'customers/customer_form.html', {'form': form, 'is_edit': True, 'customer': customer})


@require_POST
@login_required(login_url='distributor_login')
def customer_delete_view(request, pk):
    customer = _owned_or_404(request, pk)
    name = customer.name
    customer.delete()
    messages.success(request, f'{name} was removed from your customers.')
    return redirect('customer_list')
