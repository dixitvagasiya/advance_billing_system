from django.contrib.auth.models import User
from django.db import models


class Customer(models.Model):
    """A distributor's own customer book. Kept separate from Invoice's
    free-text billing fields for now — invoices aren't linked to a
    Customer record yet, so existing invoices are unaffected.
    """

    distributor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='customers')
    name = models.CharField(max_length=150)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name
