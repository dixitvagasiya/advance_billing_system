from django import forms
from django.core.validators import RegexValidator

from .models import Customer

phone_validator = RegexValidator(
    regex=r'^\+?\d{7,15}$',
    message='Enter a valid phone number (7–15 digits, optional leading +).',
)


class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['name', 'email', 'phone', 'address', 'notes']
        widgets = {
            'address': forms.Textarea(attrs={'rows': 2}),
            'notes': forms.Textarea(attrs={'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': 'field-input', 'placeholder': 'Customer or business name', 'autofocus': True})
        self.fields['email'].widget.attrs.update({'class': 'field-input', 'placeholder': 'customer@example.com'})
        self.fields['phone'].widget.attrs.update({'class': 'field-input', 'placeholder': '+91 98765 43210'})
        self.fields['address'].widget.attrs.update({'class': 'field-input', 'placeholder': 'Billing address'})
        self.fields['notes'].widget.attrs.update({'class': 'field-input', 'placeholder': 'Optional'})
        self.fields['phone'].validators.append(phone_validator)
        self.fields['email'].required = False
        self.fields['phone'].required = False
        self.fields['address'].required = False
        self.fields['notes'].required = False
