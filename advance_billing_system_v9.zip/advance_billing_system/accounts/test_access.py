"""Route protection + login/logout flow."""
from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import get_resolver, reverse

from .access import PUBLIC_URL_NAMES
from .models import UserProfile

PW = 'Some-Pass-123!'


def make_user(email, role):
    u = User.objects.create_user(username=email, email=email, password=PW, first_name='T')
    UserProfile.objects.create(user=u, role=role)
    return u


class Base(TestCase):
    def setUp(self):
        self.admin = make_user('a@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com', UserProfile.ROLE_DISTRIBUTOR)

    def login_as(self, user):
        c = Client()
        c.force_login(user)
        return c


PROTECTED = [
    ('distributor_dashboard', []), ('distributor_profile', []), ('distributor_profile_update', []),
    ('admin_dashboard', []),
    ('invoice_list', []), ('invoice_create', []), ('invoice_detail', [1]), ('invoice_pdf', [1]), ('invoice_qr', [1]),
    ('customer_list', []), ('customer_create', []), ('customer_update', [1]),
    ('product_list', []), ('product_create', []), ('product_detail', [1]), ('product_update', [1]),
]


class AnonymousAccessTests(Base):
    def test_every_protected_page_redirects_to_login(self):
        for name, args in PROTECTED:
            resp = self.client.get(reverse(name, args=args))
            expected = reverse('admin_login' if name == 'admin_dashboard' else 'distributor_login')
            self.assertRedirects(resp, expected, fetch_redirect_response=False, msg_prefix=name)

    def test_state_changing_routes_refuse_anonymous(self):
        for name in ('customer_delete', 'product_delete'):
            resp = self.client.post(reverse(name, args=[1]))
            self.assertEqual(resp.status_code, 302, name)
            self.assertIn('login', resp.url)
        resp = self.client.post(reverse('logout'))
        self.assertEqual(resp.status_code, 302)

    def test_public_pages_stay_open(self):
        for name in ('distributor_login', 'admin_login', 'distributor_register', 'forgot_password',
                     'admin_forgot_password'):
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)

    def test_unknown_urls_are_a_plain_404_not_a_redirect(self):
        self.assertEqual(self.client.get('/no/such/page/').status_code, 404)

    def test_unlisted_api_paths_get_json_401(self):
        resp = self.client.get('/accounts/api/anything/')
        self.assertIn(resp.status_code, (401, 404))

    def test_customer_api_answers_401_json_not_a_redirect(self):
        resp = self.client.post('/customers/api/register/', '{}', content_type='application/json')
        self.assertEqual(resp.status_code, 401)

    def test_default_deny_covers_every_named_route(self):
        """Any route NOT on the public list must bounce an anonymous GET/POST."""
        names = set()

        def walk(patterns):
            for p in patterns:
                if hasattr(p, 'url_patterns'):
                    walk(p.url_patterns)
                elif getattr(p, 'name', None):
                    names.add(p.name)
        walk(get_resolver().url_patterns)
        checked = 0
        for name in sorted(names - PUBLIC_URL_NAMES):
            if name.startswith(('admin:', 'auth_')) or name in ('logout',):
                continue
            for pattern in ([], [1]):
                try:
                    url = reverse(name, args=pattern)
                except Exception:
                    continue
                resp = self.client.get(url)
                self.assertIn(resp.status_code, (302, 401), f'{name} is reachable anonymously')
                checked += 1
                break
        self.assertGreater(checked, 15)


class RoleGateTests(Base):
    def test_distributor_cannot_open_admin_dashboard(self):
        c = self.login_as(self.dist)
        resp = c.get(reverse('admin_dashboard'), follow=True)
        self.assertRedirects(resp, reverse('distributor_dashboard'))
        self.assertContains(resp, "don&#x27;t have access")

    def test_admin_cannot_open_distributor_only_pages(self):
        c = self.login_as(self.admin)
        for name in ('distributor_dashboard', 'distributor_profile', 'distributor_profile_update'):
            resp = c.get(reverse(name))
            self.assertRedirects(resp, reverse('admin_dashboard'), fetch_redirect_response=False, msg_prefix=name)

    def test_each_role_reaches_its_own_dashboard(self):
        self.assertEqual(self.login_as(self.admin).get(reverse('admin_dashboard')).status_code, 200)
        self.assertEqual(self.login_as(self.dist).get(reverse('distributor_dashboard')).status_code, 200)

    def test_signed_in_user_visiting_other_portals_login_goes_to_own_dashboard(self):
        resp = self.login_as(self.admin).get(reverse('distributor_login'))
        self.assertRedirects(resp, reverse('admin_dashboard'), fetch_redirect_response=False)
        resp = self.login_as(self.dist).get(reverse('admin_login'))
        self.assertRedirects(resp, reverse('distributor_dashboard'), fetch_redirect_response=False)

    def test_user_without_profile_is_treated_as_no_role(self):
        orphan = User.objects.create_user(username='o@x.com', email='o@x.com', password=PW)
        c = self.login_as(orphan)
        resp = c.get(reverse('admin_dashboard'))
        self.assertEqual(resp.status_code, 302)


class LoginLogoutFlowTests(Base):
    def test_distributor_login_then_logout(self):
        resp = self.client.post(reverse('distributor_login'), {'email': 'd@x.com', 'password': PW}, follow=True)
        self.assertRedirects(resp, reverse('distributor_dashboard'))
        self.assertIn('_auth_user_id', self.client.session)
        self.assertContains(resp, 'Log out')

        resp = self.client.post(reverse('logout'), follow=True)
        self.assertRedirects(resp, reverse('distributor_login'))
        self.assertNotIn('_auth_user_id', self.client.session)
        # protected pages are closed again
        self.assertEqual(self.client.get(reverse('invoice_list')).status_code, 302)

    def test_admin_login_then_logout_returns_to_admin_login(self):
        resp = self.client.post(reverse('admin_login'), {'email': 'a@x.com', 'password': PW}, follow=True)
        self.assertRedirects(resp, reverse('admin_dashboard'))
        resp = self.client.post(reverse('logout'), follow=True)
        self.assertRedirects(resp, reverse('admin_login'))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_wrong_password_and_unknown_user_rejected_identically(self):
        bad = self.client.post(reverse('distributor_login'), {'email': 'd@x.com', 'password': 'nope'})
        ghost = self.client.post(reverse('distributor_login'), {'email': 'ghost@x.com', 'password': 'nope'})
        for resp in (bad, ghost):
            self.assertEqual(resp.status_code, 200)
            self.assertContains(resp, 'Invalid credentials')
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_wrong_portal_rejected(self):
        resp = self.client.post(reverse('admin_login'), {'email': 'd@x.com', 'password': PW})
        self.assertContains(resp, 'Invalid credentials')
        resp = self.client.post(reverse('distributor_login'), {'email': 'a@x.com', 'password': PW})
        self.assertContains(resp, 'Invalid credentials')
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_email_login_is_case_insensitive_on_input(self):
        resp = self.client.post(reverse('distributor_login'), {'email': 'D@X.com', 'password': PW}, follow=True)
        self.assertRedirects(resp, reverse('distributor_dashboard'))

    def test_inactive_user_cannot_log_in(self):
        self.dist.is_active = False
        self.dist.save()
        self.client.post(reverse('distributor_login'), {'email': 'd@x.com', 'password': PW})
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_logout_rejects_get(self):
        c = self.login_as(self.dist)
        self.assertEqual(c.get(reverse('logout')).status_code, 405)
        self.assertIn('_auth_user_id', c.session)      # still signed in

    def test_logout_requires_csrf_token(self):
        c = Client(enforce_csrf_checks=True)
        c.force_login(self.dist)
        self.assertEqual(c.post(reverse('logout')).status_code, 403)
        self.assertIn('_auth_user_id', c.session)

    def test_session_cookie_is_new_after_login(self):
        self.client.get(reverse('distributor_login'))
        before = self.client.cookies.get('sessionid')
        self.client.post(reverse('distributor_login'), {'email': 'd@x.com', 'password': PW})
        after = self.client.cookies['sessionid'].value
        self.assertTrue(before is None or before.value != after)

    def test_back_button_after_logout_does_not_show_dashboard(self):
        self.client.post(reverse('distributor_login'), {'email': 'd@x.com', 'password': PW})
        self.client.post(reverse('logout'))
        resp = self.client.get(reverse('distributor_dashboard'))
        self.assertEqual(resp.status_code, 302)

    def test_nav_logout_is_a_post_form(self):
        c = self.login_as(self.dist)
        html = c.get(reverse('distributor_dashboard')).content.decode()
        self.assertIn(f'action="{reverse("logout")}"', html)
        self.assertIn('method="post"', html)
