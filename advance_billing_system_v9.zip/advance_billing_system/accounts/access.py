"""Route protection.

Two layers, so a forgotten decorator can never expose a page:

1. LoginRequiredMiddleware — DEFAULT-DENY. Every URL needs a signed-in user
   unless its URL name is in PUBLIC_URL_NAMES (login, registration, password
   recovery and the JSON endpoints that authenticate themselves). New views
   are therefore protected automatically.

2. role_required(...) — decorator for views that also need a particular role
   (e.g. the admin dashboard must not open for a distributor).
"""
from functools import wraps

from django.contrib import messages
from django.http import JsonResponse
from django.shortcuts import redirect
from django.urls import Resolver404, resolve, reverse

from .models import UserProfile

PUBLIC_URL_NAMES = frozenset({
    'admin_login', 'admin_register', 'admin_forgot_password', 'admin_verify_otp', 'admin_resend_otp',
    'distributor_login', 'distributor_register', 'forgot_password', 'verify_otp', 'resend_otp',
    # JSON endpoints: the first two are keyed by a secret / OTP; the customer API
    # answers 401 JSON itself (a redirect to an HTML login page is useless to API clients).
    'api_admin_register', 'api_admin_recovery_request', 'api_admin_recovery_reset',
    'api_customer_register',
})
PUBLIC_PATHS = frozenset({'/'})                 # root just redirects to the distributor login
PUBLIC_PREFIXES = ('/static/', '/admin/')       # /admin/ = Django's own console, has its own login


def role_of(user):
    profile = getattr(user, 'profile', None) if user.is_authenticated else None
    return profile.role if profile else None


def home_for(user):
    """Name of the dashboard URL that belongs to this user's role."""
    return 'admin_dashboard' if role_of(user) == UserProfile.ROLE_ADMIN else 'distributor_dashboard'


def login_url_for(path):
    """Admin-portal URLs bounce to the admin login, everything else to the distributor login."""
    return reverse('admin_login' if path.startswith('/accounts/admin-portal/') else 'distributor_login')


class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated or self._is_public(request):
            return self.get_response(request)
        if request.path.startswith('/accounts/api/') or '/api/' in request.path:
            return JsonResponse({'error': 'Authentication required.'}, status=401)
        return redirect(login_url_for(request.path))

    @staticmethod
    def _is_public(request):
        path = request.path
        if path in PUBLIC_PATHS or path.startswith(PUBLIC_PREFIXES):
            return True
        try:
            return resolve(path).url_name in PUBLIC_URL_NAMES
        except Resolver404:
            return True          # let Django render its normal 404


def role_required(*roles):
    """Allow only users whose profile role is in `roles`. Anonymous users go to
    the login page; signed-in users of the wrong role are sent to their own
    dashboard with a message."""
    def decorator(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect(login_url_for(request.path))
            if role_of(request.user) not in roles:
                messages.error(request, "You don't have access to that page.")
                return redirect(home_for(request.user))
            return view(request, *args, **kwargs)
        return wrapper
    return decorator
