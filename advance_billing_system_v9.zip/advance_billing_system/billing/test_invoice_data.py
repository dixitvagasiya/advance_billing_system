"""Invoice data really is in the database: id, customer name, total amount, date."""
from datetime import date
from decimal import Decimal
from io import StringIO

from django.contrib.auth.models import User
from django.core.management import call_command
from django.core.management.base import CommandError
from django.db import connection
from django.test import TestCase

from accounts.models import UserProfile
from products.models import Product

from .models import Invoice, InvoiceItem


class _Fixture(TestCase):
    def setUp(self):
        self.dist = User.objects.create_user(username='d@x.com', email='d@x.com', password='x')
        UserProfile.objects.create(user=self.dist, role=UserProfile.ROLE_DISTRIBUTOR)

    def make(self, **kw):
        d = dict(distributor=self.dist, customer_name='Acme Traders', issue_date=date(2026, 10, 1))
        d.update(kw)
        return Invoice.objects.create(**d)

    def item(self, inv, qty='2', price='100', disc='10', gst='18', desc='Widget'):
        return InvoiceItem.objects.create(invoice=inv, description=desc, quantity=Decimal(qty),
                                          unit_price=Decimal(price), discount_percent=Decimal(disc),
                                          gst_percent=Decimal(gst))


class InvoiceDataTests(_Fixture):
    def test_columns_exist_in_the_table(self):
        with connection.cursor() as cur:
            cols = {c.name for c in connection.introspection.get_table_description(cur, 'billing_invoice')}
        for col in ('id', 'invoice_number', 'customer_name', 'total_amount', 'issue_date', 'created_at'):
            self.assertIn(col, cols)

    def test_saved_row_has_id_customer_total_and_date(self):
        inv = self.make()
        self.item(inv)                               # 200 - 10% = 180; +18% GST = 212.40
        row = Invoice.objects.values('id', 'invoice_number', 'customer_name', 'total_amount', 'issue_date').get(pk=inv.pk)
        self.assertEqual(row['customer_name'], 'Acme Traders')
        self.assertTrue(row['invoice_number'].startswith('INV-'))
        self.assertEqual(row['issue_date'], date(2026, 10, 1))
        self.assertEqual(row['total_amount'], Decimal('212.40'))

    def test_stored_total_matches_computed_property(self):
        inv = self.make()
        self.item(inv); self.item(inv, qty='3', price='49.99', disc='0', gst='5', desc='B')
        fresh = Invoice.objects.prefetch_related('items').get(pk=inv.pk)
        self.assertEqual(fresh.total_amount, fresh.total)

    def test_total_follows_item_edit_and_delete(self):
        inv = self.make()
        a = self.item(inv)
        b = self.item(inv, qty='1', price='50', disc='0', gst='0', desc='B')
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('262.40'))
        a.quantity = Decimal('1'); a.save()
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('156.20'))   # 90 x 1.18 = 106.20, plus 50
        b.delete()
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('106.20'))

    def test_legacy_invoice_wide_tax_is_included(self):
        inv = self.make(tax_percent=Decimal('10'))
        self.item(inv, qty='1', price='100', disc='0', gst='0')
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('110.00'))
        inv.tax_percent = Decimal('0'); inv.save()
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('100.00'))

    def test_empty_invoice_total_is_zero_and_deleting_invoice_is_safe(self):
        inv = self.make()
        self.item(inv)
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount.__class__, Decimal)
        inv.delete()
        self.assertFalse(Invoice.objects.exists())

    def test_invoice_numbers_are_unique_and_sequential(self):
        a, b = self.make(), self.make()
        self.assertNotEqual(a.invoice_number, b.invoice_number)
        self.assertLess(a.invoice_number, b.invoice_number)

    def test_verify_command_passes_on_good_data(self):
        inv = self.make(); self.item(inv)
        out = StringIO()
        call_command('verify_invoices', stdout=out)
        self.assertIn('OK', out.getvalue())
        self.assertIn('Acme Traders', out.getvalue())

    def test_verify_command_detects_and_fixes_bad_total(self):
        inv = self.make(); self.item(inv)
        Invoice.objects.filter(pk=inv.pk).update(total_amount=Decimal('1.00'))
        with self.assertRaises(CommandError):
            call_command('verify_invoices', stdout=StringIO())
        call_command('verify_invoices', '--fix', stdout=StringIO())
        self.assertEqual(Invoice.objects.get(pk=inv.pk).total_amount, Decimal('212.40'))

    def test_verify_command_flags_missing_customer_name(self):
        inv = self.make(); self.item(inv)
        Invoice.objects.filter(pk=inv.pk).update(customer_name='')
        with self.assertRaises(CommandError):
            call_command('verify_invoices', stdout=StringIO())


class InvoiceQRStoredTests(_Fixture):
    """QR is generated when the invoice is saved and shown from the saved row."""

    def test_qr_is_generated_on_save_with_the_saved_values(self):
        inv = self.make()
        self.item(inv)
        row = Invoice.objects.get(pk=inv.pk)
        self.assertTrue(bytes(row.qr_png).startswith(b'\x89PNG'))
        for expected in (row.invoice_number, 'Acme Traders', 'INR 212.40', '2026-10-01', 'Items: 1'):
            self.assertIn(expected, row.qr_payload)

    def test_stored_image_is_exactly_the_stored_payload_rendered(self):
        from .qr import render_qr_png
        inv = self.make(); self.item(inv)
        row = Invoice.objects.get(pk=inv.pk)
        self.assertEqual(bytes(row.qr_png), render_qr_png(row.qr_payload))

    def test_qr_updates_when_invoice_or_items_change(self):
        inv = self.make()
        first = bytes(Invoice.objects.get(pk=inv.pk).qr_png)
        it = self.item(inv)
        second = Invoice.objects.get(pk=inv.pk)
        self.assertNotEqual(bytes(second.qr_png), first)
        self.assertIn('INR 212.40', second.qr_payload)
        it.unit_price = Decimal('200'); it.save()
        self.assertIn('INR 424.80', Invoice.objects.get(pk=inv.pk).qr_payload)
        inv.customer_name = 'Renamed Co'; inv.save()
        self.assertIn('Renamed Co', Invoice.objects.get(pk=inv.pk).qr_payload)
        it.delete()
        self.assertIn('Items: 0', Invoice.objects.get(pk=inv.pk).qr_payload)

    def test_stale_or_missing_qr_self_heals_when_served(self):
        from .qr import stored_qr_png
        inv = self.make(); self.item(inv)
        Invoice.objects.filter(pk=inv.pk).update(qr_png=b'', qr_payload='')
        png = stored_qr_png(Invoice.objects.prefetch_related('items').get(pk=inv.pk))
        self.assertTrue(png.startswith(b'\x89PNG'))
        self.assertIn('Acme Traders', Invoice.objects.get(pk=inv.pk).qr_payload)

    def test_verify_command_flags_and_fixes_missing_qr(self):
        inv = self.make(); self.item(inv)
        Invoice.objects.filter(pk=inv.pk).update(qr_png=b'')
        with self.assertRaises(CommandError):
            call_command('verify_invoices', stdout=StringIO())
        call_command('verify_invoices', '--fix', stdout=StringIO())
        self.assertTrue(bytes(Invoice.objects.get(pk=inv.pk).qr_png).startswith(b'\x89PNG'))


class InvoicePreviewQRTests(TestCase):
    def setUp(self):
        self.dist = User.objects.create_user(username='p@x.com', email='p@x.com', password='x')
        UserProfile.objects.create(user=self.dist, role=UserProfile.ROLE_DISTRIBUTOR)
        self.client.force_login(self.dist)
        self.inv = Invoice.objects.create(distributor=self.dist, customer_name='Preview Co', issue_date=date(2026, 10, 5))
        InvoiceItem.objects.create(invoice=self.inv, description='W', quantity=1, unit_price=Decimal('100'), gst_percent=Decimal('18'))

    def test_preview_embeds_the_stored_qr_inline(self):
        import base64, re
        from django.urls import reverse
        html = self.client.get(reverse('invoice_detail', args=[self.inv.pk])).content.decode()
        m = re.search(r'src="data:image/png;base64,([^"]+)"', html)
        self.assertIsNotNone(m)
        self.assertEqual(base64.b64decode(m.group(1)), bytes(Invoice.objects.get(pk=self.inv.pk).qr_png))
        self.assertIn('INR 118.00', html)             # payload text shown next to the code

    def test_preview_changes_after_the_invoice_changes(self):
        import re
        from django.urls import reverse
        url = reverse('invoice_detail', args=[self.inv.pk])
        before = re.search(r'base64,([^"]+)"', self.client.get(url).content.decode()).group(1)
        InvoiceItem.objects.create(invoice=self.inv, description='X', quantity=1, unit_price=Decimal('50'))
        after = re.search(r'base64,([^"]+)"', self.client.get(url).content.decode()).group(1)
        self.assertNotEqual(before, after)

    def test_qr_endpoint_serves_the_stored_image(self):
        from django.urls import reverse
        resp = self.client.get(reverse('invoice_qr', args=[self.inv.pk]))
        self.assertEqual(resp.content, bytes(Invoice.objects.get(pk=self.inv.pk).qr_png))
