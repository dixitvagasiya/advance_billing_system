"""Check that every invoice in the database has the essentials:
invoice id/number, customer name, total amount, date and stored QR code — and that the stored
total matches its line items.

    python manage.py verify_invoices          # report only (exit code 1 on problems)
    python manage.py verify_invoices --fix    # also recompute wrong stored totals
"""
from django.core.management.base import BaseCommand, CommandError

from billing.models import Invoice


class Command(BaseCommand):
    help = 'Verify invoice id, customer name, total amount, date and stored QR are present and consistent.'

    def add_arguments(self, parser):
        parser.add_argument('--fix', action='store_true', help='Recompute stored totals and regenerate QR codes that are out of date.')

    def handle(self, *args, **opts):
        problems = 0
        invoices = Invoice.objects.prefetch_related('items').order_by('pk')
        self.stdout.write(f'{"ID":>4}  {"Invoice #":<15}{"Customer":<24}{"Total":>12}  Date')
        for inv in invoices:
            issues = []
            if not inv.invoice_number:
                issues.append('missing invoice number')
            if not (inv.customer_name or '').strip():
                issues.append('missing customer name')
            if inv.issue_date is None:
                issues.append('missing date')
            expected = inv.compute_total()
            if inv.total_amount != expected:
                if opts['fix']:
                    inv.refresh_total_amount()
                else:
                    issues.append(f'stored total {inv.total_amount} != computed {expected}')
            from billing.qr import invoice_qr_payload
            if not inv.qr_png or inv.qr_payload != invoice_qr_payload(inv):
                if opts['fix']:
                    inv.refresh_qr()
                else:
                    issues.append('stored QR missing or out of date')
            problems += bool(issues)
            self.stdout.write(f'{inv.pk:>4}  {inv.invoice_number:<15}{inv.customer_name[:22]:<24}'
                              f'{inv.total_amount:>12}  {inv.issue_date}' + (f'   !! {"; ".join(issues)}' if issues else ''))
        count = invoices.count()
        if problems:
            raise CommandError(f'{problems} of {count} invoice(s) have problems.')
        self.stdout.write(self.style.SUCCESS(f'OK — {count} invoice(s) checked, all have id, customer name, total and date.'))
