"""QR codes for invoices (segno: pure Python, no dependencies)."""
import base64
from io import BytesIO

import segno

MAX_NAME_LEN = 40   # keep the payload short so the code stays small and easy to scan


def invoice_qr_payload(invoice):
    """Plain-text summary encoded in the QR. Plain text (not a URL) because
    invoice pages need a login, and any phone scanner can show text as-is.
    Always read from the database via the model, so it can't go stale."""
    name = invoice.customer_name.strip()
    if len(name) > MAX_NAME_LEN:
        name = name[:MAX_NAME_LEN - 1].rstrip() + '…'
    return '\n'.join([
        f'Invoice: {invoice.invoice_number}',
        f'Customer: {name}',
        f'Items: {invoice.item_count}',
        f'Total: INR {invoice.total:.2f}',
        f'Date: {invoice.issue_date.isoformat()}',
    ])


def render_qr_png(payload, scale=10):
    """PNG bytes for any text (dark on white, with quiet zone)."""
    qr = segno.make(payload, error='m', encoding='utf-8')
    buffer = BytesIO()
    qr.save(buffer, kind='png', scale=scale, border=3, dark='#14110a', light='#ffffff')
    return buffer.getvalue()


def invoice_qr_png(invoice, scale=10):
    """Freshly generated PNG for the invoice's current data (nothing stored)."""
    return render_qr_png(invoice_qr_payload(invoice), scale=scale)


def stored_qr_png(invoice):
    """The QR saved on the invoice row at save time.

    Self-healing: if the stored image is missing or no longer matches the
    invoice's data (e.g. the row was changed with a raw SQL/queryset update),
    it is regenerated and saved before being returned.
    """
    if invoice.qr_png and invoice.qr_payload == invoice_qr_payload(invoice):
        return bytes(invoice.qr_png)
    invoice.refresh_qr()
    return bytes(invoice.qr_png)


def _data_uri(png):
    return 'data:image/png;base64,' + base64.b64encode(png).decode('ascii')


def invoice_qr_data_uri(invoice):
    """The saved QR as a data: URI, for embedding straight into HTML / the PDF."""
    return _data_uri(stored_qr_png(invoice))
