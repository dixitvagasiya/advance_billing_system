from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.models import UserProfile

from .forms import ProductForm
from .models import Product


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


@login_required(login_url='distributor_login')
def product_list_view(request):
    products = Product.objects.select_related('distributor')
    if not _is_admin(request.user):
        products = products.filter(distributor=request.user)

    query = request.GET.get('q', '').strip()
    if query:
        products = products.filter(Q(name__icontains=query) | Q(category__icontains=query))

    paginator = Paginator(products, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'products/product_list.html', {
        'page_obj': page_obj,
        'query': query,
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def product_create_view(request):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')

    form = ProductForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        product = form.save(commit=False)
        product.distributor = request.user
        product.save()
        messages.success(request, f'{product.name} added to your catalog.')
        return redirect('product_list')

    return render(request, 'products/product_form.html', {'form': form, 'is_edit': False})


def _visible_or_404(request, pk):
    """Admins may read any product; distributors only their own (others 404)."""
    qs = Product.objects.select_related('distributor')
    if not _is_admin(request.user):
        qs = qs.filter(distributor=request.user)
    return get_object_or_404(qs, pk=pk)


def _owned_or_404(request, pk):
    return get_object_or_404(Product, pk=pk, distributor=request.user)


@login_required(login_url='distributor_login')
def product_detail_view(request, pk):
    product = _visible_or_404(request, pk)
    return render(request, 'products/product_detail.html', {
        'product': product,
        'is_admin': _is_admin(request.user),
        'gst_amount': (product.price * product.gst_rate / 100).quantize(Decimal('0.01')),
        'price_incl': (product.price * (100 + product.gst_rate) / 100).quantize(Decimal('0.01')),
    })


@login_required(login_url='distributor_login')
def product_update_view(request, pk):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')
    product = _owned_or_404(request, pk)
    form = ProductForm(request.POST or None, instance=product)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, f'{product.name} updated.')
        return redirect('product_list')
    return render(request, 'products/product_form.html', {'form': form, 'is_edit': True, 'product': product})


@require_POST
@login_required(login_url='distributor_login')
def product_delete_view(request, pk):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')
    product = _owned_or_404(request, pk)
    name = product.name
    product.delete()      # existing invoice lines keep their copied description/price (FK is SET_NULL)
    messages.success(request, f'{name} was removed from your catalog.')
    return redirect('product_list')
