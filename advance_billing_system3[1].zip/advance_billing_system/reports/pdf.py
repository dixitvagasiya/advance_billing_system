"""Reports -> PDF with xhtml2pdf (same engine and fonts as the invoice PDFs)."""
from io import BytesIO

from django.conf import settings
from django.template.loader import render_to_string
from xhtml2pdf import pisa

from billing.pdf import PDFGenerationError, _link_callback

from . import logic


def _prepare(section):
    """Turn a raw table spec into display-ready headers and rows."""
    kinds = section['kinds']
    headers = [{'label': label, 'num': kind in logic.NUMERIC_KINDS} for label, kind in zip(section['headers'], kinds)]
    rows = [[{'text': logic.format_cell(kind, value), 'num': kind in logic.NUMERIC_KINDS}
             for kind, value in zip(kinds, row)] for row in section['rows']]
    return {'title': section.get('title', ''), 'headers': headers, 'rows': rows, 'empty': section.get('empty', 'No data.')}


def render_report_pdf(*, title, subtitle, summary, sections, generated_on):
    """Return the report as PDF bytes.

    summary:  [(label, text)] headline figures shown above the tables
    sections: [{'title', 'headers', 'kinds', 'rows', 'empty'}]
    """
    html = render_to_string('reports/pdf_report.html', {
        'title': title, 'subtitle': subtitle, 'summary': summary,
        'sections': [_prepare(s) for s in sections],
        'generated_on': generated_on, 'brand': settings.INVOICE_BRANDING,
    })
    buffer = BytesIO()
    result = pisa.CreatePDF(src=html, dest=buffer, encoding='utf-8', link_callback=_link_callback)
    if result.err:
        raise PDFGenerationError(f'PDF rendering failed with {result.err} error(s).')
    return buffer.getvalue()
