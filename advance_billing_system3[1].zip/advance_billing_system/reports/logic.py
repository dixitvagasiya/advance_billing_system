"""Pure helpers for the reports (no Django imports, so they are trivially testable).

The status strings mirror billing.models.Invoice.STATUS_*; reports/tests.py
asserts they stay in sync.
"""
from datetime import date
from decimal import Decimal

PAID, UNPAID, OVERDUE = 'paid', 'unpaid', 'overdue'
ZERO = Decimal('0.00')

AGING_LABELS = ('Not yet due', '1–30 days', '31–60 days', '61+ days')
# An invoice someone marked 'overdue' by hand but that has no past due date
# can't be aged by days; it gets its own line rather than hiding in 'Not yet due'.
MARKED_OVERDUE = 'Marked overdue'


def effective_status(status, due_date, today):
    """What an invoice really is today.

    Stored status can lag behind reality (nothing flips 'unpaid' to 'overdue'
    automatically), so an unpaid invoice past its due date counts as overdue.
    """
    if status == PAID:
        return PAID
    if status == OVERDUE or (due_date is not None and due_date < today):
        return OVERDUE
    return UNPAID


def days_overdue(due_date, today):
    if due_date is None or due_date >= today:
        return 0
    return (today - due_date).days


def aging_bucket(days):
    """Index into AGING_LABELS for a number of days overdue."""
    if days <= 0:
        return 0
    if days <= 30:
        return 1
    if days <= 60:
        return 2
    return 3


def csv_cell(value):
    """Neutralise spreadsheet formula injection (=, +, -, @ at the start of text).

    Customer and product names are user-typed and end up in files that admins
    open in Excel, so text cells are prefixed with an apostrophe when risky.
    """
    if isinstance(value, Decimal):
        return f'{value:.2f}'
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, str) and value[:1] in ('=', '+', '-', '@', '\t', '\r'):
        return "'" + value
    return value


def bar_pct(value, maximum):
    """Whole-number percentage (0-100) for the inline bars."""
    if not maximum or value <= 0:
        return 0
    return max(1, min(100, int(round(value / maximum * 100))))


# ---------------------------------------------------------------------------
# Cell formatting for the PDF (CSV keeps raw values via csv_cell)
# ---------------------------------------------------------------------------
NUMERIC_KINDS = frozenset({'money', 'qty', 'int'})


def format_money(value):
    return f'\u20b9{Decimal(value):,.2f}'


def format_cell(kind, value):
    """Human-readable text for one table cell. `kind` is text/int/qty/money/date."""
    if value is None or value == '':
        return ''
    if kind == 'money':
        return format_money(value)
    if kind == 'qty':
        return format(Decimal(value).normalize(), 'f')
    if kind == 'date':
        return f'{value.day} {value:%b %Y}'
    return str(value)


def range_label(date_from, date_to):
    def fmt(d):
        return f'{d.day} {d:%b %Y}'
    if date_from and date_to:
        return f'Invoices issued {fmt(date_from)} \u2013 {fmt(date_to)}'
    if date_from:
        return f'Invoices issued from {fmt(date_from)}'
    if date_to:
        return f'Invoices issued up to {fmt(date_to)}'
    return 'All invoices, all time'
