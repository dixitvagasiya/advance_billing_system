from django.urls import path

from . import views

urlpatterns = [
    path('', views.overview_view, name='reports_overview'),
    path('invoices/', views.invoices_view, name='reports_invoices'),
    path('distributors/', views.distributors_view, name='reports_distributors'),
    path('products/', views.products_view, name='reports_products'),
    path('receivables/', views.receivables_view, name='reports_receivables'),
]
