import csv
import io
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.db import connection
from django.test import Client, SimpleTestCase, TestCase
from django.test.utils import CaptureQueriesContext
from unittest import mock

from django.template.loader import render_to_string
from django.urls import reverse
from django.utils import timezone

from accounts.models import UserProfile
from billing.models import Invoice, InvoiceItem
from customers.models import Customer
from products.models import Product

from billing.pdf import PDFGenerationError

from . import logic, services

PW = 'Some-Pass-123!'
REPORT_URLS = ('reports_overview', 'reports_invoices', 'reports_distributors', 'reports_products', 'reports_receivables')


def make_user(email, role=UserProfile.ROLE_DISTRIBUTOR, first='', last=''):
    user = User.objects.create_user(username=email, email=email, password=PW, first_name=first, last_name=last)
    UserProfile.objects.create(user=user, role=role)
    return user


def make_invoice(distributor, customer='Acme', items=(), status=Invoice.STATUS_UNPAID,
                 issue_date=None, due_date=None, product=None):
    """items: (description, qty, unit_price, discount_pct, gst_pct) tuples."""
    invoice = Invoice.objects.create(
        distributor=distributor, customer_name=customer, status=status,
        issue_date=issue_date or timezone.localdate(), due_date=due_date)
    for description, qty, price, disc, gst in items:
        InvoiceItem.objects.create(
            invoice=invoice, product=product, description=description, quantity=Decimal(qty),
            unit_price=Decimal(price), discount_percent=Decimal(disc), gst_percent=Decimal(gst))
    return invoice


def rows_of(response):
    text = response.content.decode('utf-8-sig')
    return list(csv.reader(io.StringIO(text)))


class LogicTests(SimpleTestCase):
    """The pure helpers, plus a guard that they stay in step with the model."""

    def test_status_constants_match_the_invoice_model(self):
        self.assertEqual((logic.PAID, logic.UNPAID, logic.OVERDUE),
                         (Invoice.STATUS_PAID, Invoice.STATUS_UNPAID, Invoice.STATUS_OVERDUE))

    def test_effective_status(self):
        today = date(2026, 10, 14)
        self.assertEqual(logic.effective_status('paid', date(2020, 1, 1), today), 'paid')   # paid is final
        self.assertEqual(logic.effective_status('unpaid', None, today), 'unpaid')
        self.assertEqual(logic.effective_status('unpaid', today, today), 'unpaid')          # due today is not late
        self.assertEqual(logic.effective_status('unpaid', today - timedelta(days=1), today), 'overdue')
        self.assertEqual(logic.effective_status('overdue', None, today), 'overdue')

    def test_aging_bucket_boundaries(self):
        self.assertEqual([logic.aging_bucket(d) for d in (0, 1, 30, 31, 60, 61, 400)], [0, 1, 1, 2, 2, 3, 3])

    def test_csv_cell_blocks_formula_injection(self):
        for risky in ('=SUM(A1)', '+1', '-1', '@cmd', '\tx'):
            self.assertEqual(logic.csv_cell(risky), "'" + risky)
        self.assertEqual(logic.csv_cell('Acme'), 'Acme')
        self.assertEqual(logic.csv_cell(Decimal('5')), '5.00')
        self.assertEqual(logic.csv_cell(date(2026, 1, 2)), '2026-01-02')

    def test_bar_pct(self):
        self.assertEqual((logic.bar_pct(0, 10), logic.bar_pct(10, 10), logic.bar_pct(5, 0)), (0, 100, 0))
        self.assertEqual(logic.bar_pct(1, 1000), 1)     # tiny but non-zero stays visible


class AccessTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com')

    def test_anonymous_is_sent_to_the_admin_login(self):
        for name in REPORT_URLS:
            resp = Client().get(reverse(name))
            self.assertEqual(resp.status_code, 302, name)
            self.assertIn(reverse('admin_login'), resp.url, name)

    def test_distributors_are_forbidden_everywhere(self):
        self.client.force_login(self.dist)
        for name in REPORT_URLS:
            self.assertEqual(self.client.get(reverse(name)).status_code, 403, name)
            self.assertEqual(self.client.get(reverse(name), {'export': 'csv'}).status_code, 403, name)

    def test_admin_can_open_every_report(self):
        self.client.force_login(self.admin)
        for name in REPORT_URLS:
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)

    def test_reports_are_read_only(self):
        self.client.force_login(self.admin)
        for name in REPORT_URLS:
            # POST is accepted by the view but changes nothing; no model is writable here
            before = (Invoice.objects.count(), Product.objects.count())
            self.client.post(reverse(name), {'x': 'y'})
            self.assertEqual(before, (Invoice.objects.count(), Product.objects.count()))

    def test_admin_dashboard_is_no_longer_open_to_distributors(self):
        self.client.force_login(self.dist)
        self.assertEqual(self.client.get(reverse('admin_dashboard')).status_code, 403)
        self.assertEqual(Client().get(reverse('admin_dashboard')).status_code, 302)

    def test_dashboard_links_to_every_report(self):
        self.client.force_login(self.admin)
        resp = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(resp.status_code, 200)
        for name in REPORT_URLS:
            self.assertContains(resp, reverse(name))

    def test_reports_nav_link_is_admin_only(self):
        self.client.force_login(self.admin)
        self.assertContains(self.client.get(reverse('admin_dashboard')), '>Reports</a>')
        d = Client(); d.force_login(self.dist)
        self.assertNotContains(d.get(reverse('distributor_dashboard')), '>Reports</a>')

    def test_nav_highlights_reports_not_products_on_the_products_report(self):
        self.client.force_login(self.admin)
        resp = self.client.get(reverse('reports_products'))
        self.assertContains(resp, 'aria-current="page">Reports</a>')
        self.assertContains(resp, '<a href="/products/" >Products</a>')   # not marked current


class OverviewTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.d1 = make_user('d1@x.com', first='Dev', last='One')
        self.d2 = make_user('d2@x.com')
        self.client.force_login(self.admin)
        self.today = timezone.localdate()

    def _four_invoices(self):
        # 2 x 100, 10% off, 18% GST -> gross 200.00, discount 20.00, GST 32.40, total 212.40
        make_invoice(self.d1, items=[('A', 2, '100', '10', '18')], status=Invoice.STATUS_PAID)
        make_invoice(self.d1, items=[('B', 1, '50', '0', '0')], due_date=self.today + timedelta(days=5))
        make_invoice(self.d2, items=[('C', 1, '30', '0', '0')], due_date=self.today - timedelta(days=1))
        make_invoice(self.d2, items=[('D', 1, '20', '0', '0')], status=Invoice.STATUS_OVERDUE)

    def test_headline_numbers_match_the_invoice_arithmetic(self):
        self._four_invoices()
        totals = self.client.get(reverse('reports_overview')).context['totals']
        self.assertEqual(totals.count, 4)
        self.assertEqual(totals.total, Decimal('312.40'))
        self.assertEqual(totals.paid, Decimal('212.40'))
        self.assertEqual(totals.outstanding, Decimal('100.00'))
        self.assertEqual(totals.overdue, Decimal('50.00'))          # past due date + marked overdue
        self.assertEqual(totals.tax, Decimal('32.40'))
        self.assertEqual(totals.discount, Decimal('20.00'))
        self.assertEqual((totals.paid_count, totals.unpaid_count, totals.overdue_count), (1, 1, 2))

    def test_paid_plus_outstanding_always_equals_total(self):
        self._four_invoices()
        t = self.client.get(reverse('reports_overview')).context['totals']
        self.assertEqual(t.paid + t.outstanding, t.total)

    def test_empty_database_renders_zeroes_not_errors(self):
        resp = self.client.get(reverse('reports_overview'))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.context['totals'].total, Decimal('0'))
        self.assertContains(resp, 'No invoices were issued in this period')

    def test_months_are_grouped_oldest_first_with_bars(self):
        make_invoice(self.d1, items=[('A', 1, '100', '0', '0')], issue_date=date(2026, 9, 10))
        make_invoice(self.d1, items=[('A', 1, '50', '0', '0')], issue_date=date(2026, 8, 5))
        make_invoice(self.d1, items=[('A', 1, '50', '0', '0')], issue_date=date(2026, 8, 30))
        months = self.client.get(reverse('reports_overview')).context['months']
        self.assertEqual([m['month'] for m in months], [date(2026, 8, 1), date(2026, 9, 1)])
        self.assertEqual([m['totals'].count for m in months], [2, 1])
        self.assertEqual([m['bar'] for m in months], [100, 100])      # both 100.00 — tie for the top

    def test_date_range_is_inclusive_at_both_ends(self):
        for offset in (-40, -30, -10, 0, 1):
            make_invoice(self.d1, items=[('A', 1, '10', '0', '0')], issue_date=self.today + timedelta(days=offset))
        resp = self.client.get(reverse('reports_overview'), {
            'date_from': (self.today - timedelta(days=30)).isoformat(), 'date_to': self.today.isoformat()})
        self.assertEqual(resp.context['totals'].count, 3)             # -30, -10, 0

    def test_one_sided_ranges_are_rejected_not_silently_accepted(self):
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0')], issue_date=date(2026, 1, 1))
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0')], issue_date=date(2026, 6, 1))
        url = reverse('reports_overview')
        resp = self.client.get(url, {'date_from': '2026-03-01'})
        self.assertIn('date_to', resp.context['form'].errors)
        self.assertContains(resp, 'Choose an end date.')
        self.assertTrue(resp.context['range_invalid'])
        self.assertEqual(resp.context['totals'].count, 2)             # falls back to all time, with the error shown
        resp = self.client.get(url, {'date_to': '2026-03-01'})
        self.assertContains(resp, 'Choose a start date.')

    def test_reversed_range_shows_an_error_and_falls_back_to_all_time(self):
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0')])
        resp = self.client.get(reverse('reports_overview'), {'date_from': '2026-10-10', 'date_to': '2026-10-01'})
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'end date cannot be before the start date')
        self.assertEqual(resp.context['totals'].count, 1)

    def test_garbage_dates_do_not_crash(self):
        for bad in ('garbage', '2026-13-45', '31/12/2026', "1'; DROP TABLE x;--"):
            resp = self.client.get(reverse('reports_overview'), {'date_from': bad})
            self.assertEqual(resp.status_code, 200, bad)
            self.assertIn('date_from', resp.context['form'].errors)

    def test_preset_links_and_filter_carry_over_to_other_tabs(self):
        resp = self.client.get(reverse('reports_overview'), {'date_from': '2026-10-01', 'date_to': '2026-10-14'})
        self.assertContains(resp, f'{reverse("reports_distributors")}?date_from=2026-10-01&amp;date_to=2026-10-14')
        self.assertContains(resp, 'This financial year')

    def test_financial_year_preset_starts_in_april(self):
        from .views import _financial_year_start
        self.assertEqual(_financial_year_start(date(2026, 10, 14)), date(2026, 4, 1))
        self.assertEqual(_financial_year_start(date(2027, 2, 3)), date(2026, 4, 1))
        self.assertEqual(_financial_year_start(date(2026, 4, 1)), date(2026, 4, 1))

    def test_query_count_does_not_grow_with_invoice_count(self):
        def count():
            with CaptureQueriesContext(connection) as ctx:
                self.client.get(reverse('reports_overview'))
            return len(ctx)
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0'), ('B', 1, '10', '0', '0')])
        few = count()
        for _ in range(8):
            make_invoice(self.d2, items=[('A', 1, '10', '0', '0'), ('B', 1, '10', '0', '0')])
        self.assertEqual(count(), few)

    def test_csv_export(self):
        self._four_invoices()
        resp = self.client.get(reverse('reports_overview'), {'export': 'csv'})
        self.assertEqual(resp['Content-Type'], 'text/csv; charset=utf-8')
        self.assertIn('attachment; filename="sales-by-month-', resp['Content-Disposition'])
        rows = rows_of(resp)
        self.assertEqual(rows[0][:3], ['Month', 'Invoices', 'Subtotal'])
        self.assertEqual(rows[1][1], '4')
        self.assertEqual(rows[1][5], '312.40')


class DistributorReportTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.big = make_user('big@x.com', first='Big', last='Biller')
        self.small = make_user('small@x.com', first='Small')
        self.idle = make_user('idle@x.com', first='Idle')
        self.client.force_login(self.admin)

    def test_ranked_by_billed_amount_and_idle_distributors_still_listed(self):
        make_invoice(self.small, items=[('A', 1, '10', '0', '0')])
        make_invoice(self.big, items=[('A', 1, '500', '0', '0')], status=Invoice.STATUS_PAID)
        make_invoice(self.big, items=[('A', 1, '100', '0', '0')], due_date=timezone.localdate() - timedelta(days=3))
        rows = self.client.get(reverse('reports_distributors')).context['rows']
        self.assertEqual([r['name'] for r in rows], ['Big Biller', 'Small', 'Idle'])
        big = rows[0]['totals']
        self.assertEqual((big.count, big.total, big.paid, big.outstanding, big.overdue),
                         (2, Decimal('600.00'), Decimal('500.00'), Decimal('100.00'), Decimal('100.00')))
        self.assertEqual(rows[2]['totals'].count, 0)

    def test_customer_and_product_counts(self):
        Customer.objects.create(distributor=self.big, name='C1')
        Customer.objects.create(distributor=self.big, name='C2')
        Product.objects.create(distributor=self.big, name='P1', price=Decimal('1'))
        rows = {r['name']: r for r in self.client.get(reverse('reports_distributors')).context['rows']}
        self.assertEqual((rows['Big Biller']['customers'], rows['Big Biller']['products']), (2, 1))
        self.assertEqual((rows['Small']['customers'], rows['Small']['products']), (0, 0))

    def test_admin_accounts_are_not_listed_as_distributors(self):
        names = [r['name'] for r in self.client.get(reverse('reports_distributors')).context['rows']]
        self.assertNotIn('admin@x.com', names)
        self.assertEqual(len(names), 3)

    def test_date_filter_applies(self):
        make_invoice(self.big, items=[('A', 1, '10', '0', '0')], issue_date=date(2026, 1, 1))
        rows = self.client.get(reverse('reports_distributors'), {'date_from': '2026-06-01', 'date_to': '2026-12-31'}).context['rows']
        self.assertEqual(rows[0]['totals'].count, 0)

    def test_csv_export(self):
        make_invoice(self.big, items=[('A', 1, '10', '0', '0')])
        rows = rows_of(self.client.get(reverse('reports_distributors'), {'export': 'csv'}))
        self.assertEqual(rows[0][0], 'Distributor')
        self.assertEqual(rows[1][:3], ['Big Biller', 'big@x.com', '1'])


class ProductReportTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com', first='Dee')
        self.client.force_login(self.admin)
        self.p = Product.objects.create(distributor=self.dist, name='Widget', price=Decimal('100'), stock=50)

    def test_units_and_net_sales_are_summed_per_product(self):
        make_invoice(self.dist, product=self.p, items=[('Widget', 2, '100', '0', '18')])
        make_invoice(self.dist, product=self.p, items=[('Widget', 3, '100', '10', '18')])
        sales = self.client.get(reverse('reports_products')).context['sales']
        self.assertEqual(len(sales), 1)
        row = sales[0]
        self.assertEqual(row['name'], 'Widget')
        self.assertEqual(row['units'], Decimal('5'))
        self.assertEqual(row['invoices'], 2)
        self.assertEqual(row['net'], Decimal('470.00'))             # 200 + (300 - 30)
        self.assertEqual(row['gst'], Decimal('84.60'))              # 36.00 + 48.60

    def test_lines_of_deleted_products_are_kept_and_grouped_by_description(self):
        make_invoice(self.dist, product=self.p, items=[('Widget', 1, '100', '0', '0')])
        make_invoice(self.dist, items=[('Old Thing', 1, '10', '0', '0')])
        make_invoice(self.dist, items=[(' old thing ', 2, '10', '0', '0')])
        sales = self.client.get(reverse('reports_products')).context['sales']
        by_name = {r['name'].lower(): r for r in sales}
        self.assertEqual(by_name['old thing']['units'], Decimal('3'))
        self.assertTrue(by_name['old thing']['removed'])
        self.assertFalse(by_name['widget']['removed'])
        self.assertEqual(sales[0]['name'], 'Widget')                # best seller first (100 > 30)

    def test_date_filter_applies_to_sales(self):
        make_invoice(self.dist, product=self.p, items=[('Widget', 1, '100', '0', '0')], issue_date=date(2026, 1, 1))
        resp = self.client.get(reverse('reports_products'), {'date_from': '2026-06-01', 'date_to': '2026-12-31'})
        self.assertEqual(resp.context['sales'], [])
        self.assertContains(resp, 'No products were billed in this period')

    def test_only_top_rows_are_shown_but_the_csv_has_all(self):
        for n in range(27):
            make_invoice(self.dist, items=[(f'Item {n:02d}', 1, str(100 + n), '0', '0')])
        resp = self.client.get(reverse('reports_products'))
        self.assertEqual(len(resp.context['sales']), 25)
        self.assertEqual(resp.context['sales_total'], 27)
        rows = rows_of(self.client.get(reverse('reports_products'), {'export': 'sales'}))
        self.assertEqual(len(rows), 1 + 27)

    def test_stock_alerts_default_threshold_and_ordering(self):
        for name, stock in (('Out', 0), ('Five', 5), ('Ten', 10), ('Eleven', 11)):
            Product.objects.create(distributor=self.dist, name=name, price=Decimal('1'), stock=stock)
        resp = self.client.get(reverse('reports_products'))
        self.assertEqual([p.name for p in resp.context['alerts']], ['Out', 'Five', 'Ten'])   # <= 10, emptiest first
        self.assertEqual(resp.context['out_of_stock'], 1)

    def test_custom_and_zero_thresholds(self):
        for name, stock in (('Out', 0), ('Five', 5), ('Ten', 10)):
            Product.objects.create(distributor=self.dist, name=name, price=Decimal('1'), stock=stock)
        url = reverse('reports_products')
        self.assertEqual([p.name for p in self.client.get(url, {'low_stock': '5'}).context['alerts']], ['Out', 'Five'])
        self.assertEqual([p.name for p in self.client.get(url, {'low_stock': '0'}).context['alerts']], ['Out'])

    def test_invalid_threshold_falls_back_to_default_with_an_error(self):
        Product.objects.create(distributor=self.dist, name='Five', price=Decimal('1'), stock=5)
        for bad in ('-1', 'abc', '1.5', '999999999'):
            resp = self.client.get(reverse('reports_products'), {'low_stock': bad})
            self.assertEqual(resp.status_code, 200, bad)
            self.assertEqual(resp.context['threshold'], services.DEFAULT_LOW_STOCK, bad)
            self.assertTrue(resp.context['stock_form'].errors, bad)

    def test_stock_csv(self):
        Product.objects.create(distributor=self.dist, name='Five', price=Decimal('9.5'), stock=5)
        rows = rows_of(self.client.get(reverse('reports_products'), {'export': 'stock'}))
        self.assertEqual(rows[0], ['Product', 'Category', 'Distributor', 'Stock', 'Price'])
        self.assertEqual(rows[1], ['Five', '', 'Dee', '5', '9.50'])

    def test_unknown_export_value_just_renders_the_page(self):
        resp = self.client.get(reverse('reports_products'), {'export': 'bogus'})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'].split(';')[0], 'text/html')


class ReceivablesTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com')
        self.client.force_login(self.admin)
        self.today = timezone.localdate()

    def _invoice(self, amount, due_offset=None, status=Invoice.STATUS_UNPAID, customer='Acme', issued=None):
        due = None if due_offset is None else self.today + timedelta(days=due_offset)
        return make_invoice(self.dist, customer=customer, items=[('X', 1, str(amount), '0', '0')],
                            status=status, due_date=due, issue_date=issued)

    def test_ageing_buckets(self):
        self._invoice(10, due_offset=5)                 # not yet due
        self._invoice(20, due_offset=-10)               # 1-30
        self._invoice(30, due_offset=-45)               # 31-60
        self._invoice(40, due_offset=-90)               # 61+
        self._invoice(50, status=Invoice.STATUS_OVERDUE)  # marked overdue, no due date
        self._invoice(999, due_offset=-90, status=Invoice.STATUS_PAID)   # paid: never owed
        resp = self.client.get(reverse('reports_receivables'))
        aging = resp.context['aging']
        self.assertEqual([a['count'] for a in aging], [1, 1, 1, 1, 1])
        self.assertEqual([a['amount'] for a in aging], [Decimal(n) for n in (10, 20, 30, 40, 50)])
        self.assertEqual(aging[4]['label'], 'Marked overdue')
        self.assertEqual(resp.context['owed_total'], Decimal('150.00'))

    def test_rows_are_ordered_most_overdue_first(self):
        self._invoice(10, due_offset=-5)
        self._invoice(10, due_offset=-50)
        self._invoice(10, due_offset=3)
        self.assertEqual([r['days'] for r in self.client.get(reverse('reports_receivables')).context['rows']], [50, 5, 0])

    def test_ignores_the_date_filter(self):
        self._invoice(10, due_offset=-400, issued=date(2025, 1, 1))
        resp = self.client.get(reverse('reports_receivables'), {'date_from': '2026-10-01'})
        self.assertEqual(len(resp.context['rows']), 1)

    def test_nothing_owed(self):
        self._invoice(10, status=Invoice.STATUS_PAID)
        self.assertContains(self.client.get(reverse('reports_receivables')), 'Nothing outstanding')

    def test_csv_neutralises_formula_injection_in_customer_names(self):
        self._invoice(10, due_offset=-1, customer='=HYPERLINK("http://evil","x")')
        rows = rows_of(self.client.get(reverse('reports_receivables'), {'export': 'csv'}))
        self.assertTrue(rows[1][1].startswith("'="), rows[1][1])
        self.assertEqual(rows[1][5], 'Overdue')
        self.assertEqual(rows[1][6], '1')

    def test_names_are_html_escaped(self):
        self._invoice(10, due_offset=-1, customer='<script>alert(1)</script>')
        resp = self.client.get(reverse('reports_receivables'))
        self.assertNotContains(resp, '<script>alert(1)</script>')
        self.assertContains(resp, '&lt;script&gt;alert(1)&lt;/script&gt;')


class FormattingTests(SimpleTestCase):
    def test_money_and_cells(self):
        self.assertEqual(logic.format_money(Decimal('1234.5')), '\u20b91,234.50')
        self.assertEqual(logic.format_cell('qty', Decimal('100.00')), '100')
        self.assertEqual(logic.format_cell('qty', Decimal('2.50')), '2.5')
        self.assertEqual(logic.format_cell('date', date(2026, 10, 5)), '5 Oct 2026')
        self.assertEqual(logic.format_cell('date', None), '')
        self.assertEqual(logic.format_cell('int', 0), '0')

    def test_range_label(self):
        self.assertEqual(logic.range_label(date(2026, 10, 1), date(2026, 10, 14)), 'Invoices issued 1 Oct 2026 \u2013 14 Oct 2026')
        self.assertEqual(logic.range_label(None, None), 'All invoices, all time')
        self.assertIn('from 1 Oct 2026', logic.range_label(date(2026, 10, 1), None))
        self.assertIn('up to 14 Oct 2026', logic.range_label(None, date(2026, 10, 14)))


class PDFExportTests(TestCase):
    """Every report can be downloaded as a PDF (rendered by xhtml2pdf)."""

    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com', first='Dee')
        self.client.force_login(self.admin)
        product = Product.objects.create(distributor=self.dist, name='Widget', price=Decimal('10'), stock=2)
        make_invoice(self.dist, customer='Acme \u20b9 & <Co>', product=product, status=Invoice.STATUS_PAID,
                     items=[('Widget', 2, '100', '10', '18')])
        make_invoice(self.dist, items=[('Widget', 1, '50', '0', '0')], due_date=timezone.localdate() - timedelta(days=3))

    def _assert_pdf(self, resp, prefix):
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        self.assertTrue(resp['Content-Disposition'].startswith(f'attachment; filename="{prefix}'), resp['Content-Disposition'])
        self.assertTrue(resp['Content-Disposition'].endswith('.pdf"'))
        self.assertTrue(resp.content.startswith(b'%PDF'))

    def test_each_report_downloads_as_a_pdf(self):
        today = timezone.localdate().isoformat()
        cases = (
            ('reports_overview', {}, 'sales-by-month-'),
            ('reports_distributors', {}, 'distributors-'),
            ('reports_products', {}, 'products-and-stock-'),
            ('reports_receivables', {}, 'receivables-'),
            ('reports_invoices', {'generate': '1', 'date_from': today, 'date_to': today}, 'invoices-'),
        )
        for name, params, prefix in cases:
            self._assert_pdf(self.client.get(reverse(name), dict(params, export='pdf')), prefix)

    def test_pdf_respects_the_date_range(self):
        resp = self.client.get(reverse('reports_overview'), {'export': 'pdf', 'date_from': '2020-01-01', 'date_to': '2020-01-31'})
        self._assert_pdf(resp, 'sales-by-month-')          # empty period still produces a valid PDF

    def test_pdf_is_admin_only(self):
        d = Client(); d.force_login(self.dist)
        for name in REPORT_URLS:
            self.assertEqual(d.get(reverse(name), {'export': 'pdf'}).status_code, 403, name)
        for name in REPORT_URLS:
            resp = Client().get(reverse(name), {'export': 'pdf'})
            self.assertEqual(resp.status_code, 302, name)

    def test_a_rendering_failure_is_a_clean_500_not_a_traceback(self):
        with mock.patch('reports.views.render_report_pdf', side_effect=PDFGenerationError('boom')):
            resp = self.client.get(reverse('reports_overview'), {'export': 'pdf'})
        self.assertEqual(resp.status_code, 500)
        self.assertNotIn(b'boom', resp.content)

    def test_pdf_buttons_are_on_the_pages(self):
        for name in REPORT_URLS:
            if name == 'reports_invoices':
                continue            # only offered once a report has been generated
            self.assertContains(self.client.get(reverse(name)), 'export=pdf', msg_prefix=name)

    def test_pdf_template_escapes_user_text_and_keeps_the_rupee_sign(self):
        from .pdf import _prepare
        section = _prepare({'title': 'T', 'headers': ['Customer', 'Total'], 'kinds': ['text', 'money'],
                            'rows': [['<script>x</script> & Co', Decimal('1234.5')]]})
        html = render_to_string('reports/pdf_report.html', {
            'title': 'Invoice report', 'subtitle': 'sub', 'summary': [('Invoices', '1')], 'sections': [section],
            'generated_on': date(2026, 10, 14), 'brand': {'name': 'B', 'dark': '#000', 'accent': '#111'}})
        self.assertNotIn('<script>x</script>', html)
        self.assertIn('&lt;script&gt;x&lt;/script&gt; &amp; Co', html)
        self.assertIn('\u20b91,234.50', html)
        self.assertIn('<pdf:pagenumber>', html)


class InvoiceReportFormTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.d1 = make_user('d1@x.com', first='Dev', last='One')
        self.d2 = make_user('d2@x.com', first='Two')
        self.client.force_login(self.admin)
        self.url = reverse('reports_invoices')
        self.today = timezone.localdate()

    def generate(self, **kw):
        params = {'generate': '1', 'date_from': '2026-10-01', 'date_to': '2026-10-31'}
        params.update(kw)
        return self.client.get(self.url, params)

    def _seed(self):
        # In range: paid 212.40, unpaid(not due) 50, unpaid past due 30 ; out of range: paid 999
        make_invoice(self.d1, issue_date=date(2026, 10, 5), status=Invoice.STATUS_PAID, items=[('A', 2, '100', '10', '18')])
        make_invoice(self.d1, issue_date=date(2026, 10, 6), due_date=self.today + timedelta(days=30), items=[('B', 1, '50', '0', '0')])
        make_invoice(self.d2, issue_date=date(2026, 10, 7), due_date=date(2020, 1, 8), items=[('C', 1, '30', '0', '0')])
        make_invoice(self.d2, issue_date=date(2026, 9, 30), status=Invoice.STATUS_PAID, items=[('Z', 1, '999', '0', '0')])

    def test_form_page_loads_with_a_sensible_default_range_and_no_results(self):
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(resp.context['generated'])
        self.assertEqual(resp.context['form'].initial['date_from'], self.today.replace(day=1))
        self.assertContains(resp, 'name="generate"')
        self.assertContains(resp, 'Generate report')
        self.assertContains(resp, f'value="{self.today.replace(day=1).isoformat()}"')

    def test_total_invoices_and_amount_collected_for_the_range(self):
        self._seed()
        resp = self.generate()
        totals = resp.context['totals']
        self.assertEqual(totals.count, 3)                       # the 30 Sep invoice is outside
        self.assertEqual(totals.paid, Decimal('212.40'))        # amount collected = paid invoices
        self.assertEqual(totals.total, Decimal('292.40'))
        self.assertEqual(totals.outstanding, Decimal('80.00'))
        self.assertContains(resp, 'Total invoices')
        self.assertContains(resp, 'Amount collected')
        self.assertContains(resp, '\u20b9212.40')
        self.assertEqual(len(resp.context['rows']), 3)

    def test_range_is_inclusive(self):
        make_invoice(self.d1, issue_date=date(2026, 10, 1), items=[('A', 1, '10', '0', '0')])
        make_invoice(self.d1, issue_date=date(2026, 10, 31), items=[('A', 1, '10', '0', '0')])
        self.assertEqual(self.generate().context['totals'].count, 2)

    def test_rows_are_newest_first(self):
        self._seed()
        issued = [f.invoice.issue_date for f in self.generate().context['rows']]
        self.assertEqual(issued, sorted(issued, reverse=True))

    def test_both_dates_are_required(self):
        for missing in ('date_from', 'date_to'):
            resp = self.generate(**{missing: ''})
            self.assertFalse(resp.context['generated'], missing)
            self.assertIn(missing, resp.context['form'].errors)
            self.assertContains(resp, 'Fix the highlighted fields')

    def test_reversed_and_malformed_dates_are_rejected(self):
        resp = self.generate(date_from='2026-10-31', date_to='2026-10-01')
        self.assertFalse(resp.context['generated'])
        self.assertContains(resp, 'end date cannot be before the start date')
        for bad in ('garbage', '2026-02-30', '01/10/2026', "'; DROP TABLE x;--"):
            resp = self.generate(date_from=bad)
            self.assertEqual(resp.status_code, 200, bad)
            self.assertFalse(resp.context['generated'], bad)

    def test_status_filter_uses_the_real_status(self):
        self._seed()
        statuses = lambda s: sorted(f.status for f in self.generate(status=s).context['rows'])   # noqa: E731
        self.assertEqual(statuses('paid'), ['paid'])
        self.assertEqual(statuses('unpaid'), ['unpaid'])
        self.assertEqual(statuses('overdue'), ['overdue'])          # the unpaid one past its due date
        self.assertEqual(len(statuses('')), 3)

    def test_unknown_status_is_rejected(self):
        resp = self.generate(status='bogus')
        self.assertFalse(resp.context['generated'])
        self.assertIn('status', resp.context['form'].errors)

    def test_distributor_filter(self):
        self._seed()
        resp = self.generate(distributor=self.d1.pk)
        self.assertEqual(resp.context['totals'].count, 2)
        self.assertEqual({f.invoice.distributor for f in resp.context['rows']}, {self.d1})
        self.assertContains(resp, 'Dev One')

    def test_distributor_filter_rejects_non_distributors_and_junk(self):
        for bad in (self.admin.pk, 99999, 'abc'):
            resp = self.generate(distributor=bad)
            self.assertFalse(resp.context['generated'], bad)
            self.assertIn('distributor', resp.context['form'].errors, bad)

    def test_empty_result(self):
        resp = self.generate()
        self.assertTrue(resp.context['generated'])
        self.assertEqual(resp.context['totals'].count, 0)
        self.assertContains(resp, 'No invoices match these filters')

    def test_on_screen_rows_are_capped_but_totals_and_exports_are_complete(self):
        for _ in range(5):
            make_invoice(self.d1, issue_date=date(2026, 10, 5), items=[('A', 1, '10', '0', '0')])
        with mock.patch('reports.views.INVOICE_ROWS_SHOWN', 2):
            resp = self.generate()
            self.assertEqual(len(resp.context['rows']), 2)
            self.assertEqual(resp.context['row_total'], 5)
            self.assertEqual(resp.context['totals'].count, 5)
            self.assertContains(resp, 'Showing the latest 2 of 5')
            self.assertEqual(len(rows_of(self.generate(export='csv'))), 1 + 5)

    def test_csv_export_matches_the_filters(self):
        self._seed()
        resp = self.generate(export='csv', status='paid')
        self.assertIn('invoices-2026-10-01-to-2026-10-31.csv', resp['Content-Disposition'])
        rows = rows_of(resp)
        self.assertEqual(rows[0][:3], ['Invoice', 'Customer', 'Distributor'])
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1][5], 'Paid')
        self.assertEqual(rows[1][8], '212.40')

    def test_pdf_export_and_download_links(self):
        self._seed()
        resp = self.generate(export='pdf')
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        self.assertIn('invoices-2026-10-01-to-2026-10-31.pdf', resp['Content-Disposition'])
        page = self.generate(status='paid')
        self.assertContains(page, 'export=pdf')
        self.assertContains(page, 'status=paid')       # the PDF link carries the filters

    def test_export_with_an_invalid_form_just_shows_the_form(self):
        for export in ('pdf', 'csv'):
            resp = self.generate(export=export, date_from='')
            self.assertEqual(resp['Content-Type'].split(';')[0], 'text/html')
            self.assertFalse(resp.context['generated'])
        resp = self.client.get(self.url, {'export': 'pdf'})          # never generated
        self.assertEqual(resp['Content-Type'].split(';')[0], 'text/html')

    def test_download_buttons_hidden_when_there_is_nothing_to_download(self):
        self.assertNotContains(self.generate(), 'export=pdf')

    def test_names_are_html_escaped(self):
        make_invoice(self.d1, customer='<img src=x onerror=alert(1)>', issue_date=date(2026, 10, 5),
                     items=[('A', 1, '10', '0', '0')])
        resp = self.generate()
        self.assertNotContains(resp, '<img src=x')
        self.assertContains(resp, '&lt;img src=x')

    def test_range_summary_also_appears_on_distributor_and_product_reports(self):
        make_invoice(self.d1, issue_date=date(2026, 10, 5), status=Invoice.STATUS_PAID, items=[('A', 1, '100', '0', '0')])
        make_invoice(self.d1, issue_date=date(2026, 8, 5), status=Invoice.STATUS_PAID, items=[('A', 1, '900', '0', '0')])
        for name in ('reports_distributors', 'reports_products'):
            resp = self.client.get(reverse(name), {'date_from': '2026-10-01', 'date_to': '2026-10-31'})
            self.assertEqual(resp.context['totals'].count, 1, name)
            self.assertEqual(resp.context['totals'].paid, Decimal('100.00'), name)
            self.assertContains(resp, 'Total invoices', msg_prefix=name)
            self.assertContains(resp, 'Amount collected', msg_prefix=name)


class DateValidationTests(TestCase):
    """Empty selections and impossible ranges are refused, on every report."""

    FILTERED = ('reports_overview', 'reports_distributors', 'reports_products')

    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com')
        self.client.force_login(self.admin)
        make_invoice(self.dist, items=[('A', 1, '10', '0', '0')])

    def test_no_date_parameters_still_means_all_time(self):
        for name in self.FILTERED:
            resp = self.client.get(reverse(name))
            self.assertFalse(resp.context['range_invalid'], name)

    def test_submitting_blank_dates_is_an_error(self):
        for name in self.FILTERED:
            resp = self.client.get(reverse(name), {'date_from': '', 'date_to': ''})
            self.assertEqual(resp.status_code, 200, name)
            self.assertTrue(resp.context['range_invalid'], name)
            self.assertContains(resp, 'Choose a start date.', msg_prefix=name)
            self.assertContains(resp, 'Choose an end date.', msg_prefix=name)

    def test_half_filled_range_is_an_error(self):
        for name in self.FILTERED:
            only_from = self.client.get(reverse(name), {'date_from': '2026-01-01', 'date_to': ''})
            self.assertContains(only_from, 'Choose an end date.', msg_prefix=name)
            only_to = self.client.get(reverse(name), {'date_from': '', 'date_to': '2026-01-01'})
            self.assertContains(only_to, 'Choose a start date.', msg_prefix=name)

    def test_reversed_range_is_an_error_everywhere(self):
        for name in self.FILTERED:
            resp = self.client.get(reverse(name), {'date_from': '2026-10-10', 'date_to': '2026-10-01'})
            self.assertTrue(resp.context['range_invalid'], name)
            self.assertContains(resp, 'end date cannot be before the start date', msg_prefix=name)

    def test_same_day_range_is_valid(self):
        for name in self.FILTERED:
            resp = self.client.get(reverse(name), {'date_from': '2026-10-10', 'date_to': '2026-10-10'})
            self.assertFalse(resp.context['range_invalid'], name)

    def test_absurd_years_are_rejected_but_the_limits_are_allowed(self):
        for bad in ('0026-10-01', '1999-12-31', '2101-01-01', '9999-12-31'):
            resp = self.client.get(reverse('reports_overview'), {'date_from': bad, 'date_to': '2026-10-01'})
            self.assertTrue(resp.context['range_invalid'], bad)
            self.assertContains(resp, 'Enter a date between 01 Jan 2000 and 31 Dec 2100', msg_prefix=bad)
        ok = self.client.get(reverse('reports_overview'), {'date_from': '2000-01-01', 'date_to': '2100-12-31'})
        self.assertFalse(ok.context['range_invalid'])

    def test_exports_are_refused_for_an_invalid_range(self):
        for name, export in (('reports_overview', 'csv'), ('reports_overview', 'pdf'),
                             ('reports_distributors', 'csv'), ('reports_distributors', 'pdf'),
                             ('reports_products', 'pdf'), ('reports_products', 'sales')):
            for params in ({'date_from': '', 'date_to': ''}, {'date_from': '2026-10-10', 'date_to': '2026-10-01'}):
                resp = self.client.get(reverse(name), dict(params, export=export))
                self.assertEqual(resp['Content-Type'].split(';')[0], 'text/html', (name, export, params))
                self.assertNotIn('attachment', resp.get('Content-Disposition', ''), (name, export, params))

    def test_invoice_report_rejects_empty_and_invalid_selection(self):
        url = reverse('reports_invoices')
        cases = (
            ({'date_from': '', 'date_to': ''}, ('date_from', 'date_to')),
            ({'date_from': '2026-10-01', 'date_to': ''}, ('date_to',)),
            ({'date_from': '2026-10-10', 'date_to': '2026-10-01'}, ('date_to',)),
            ({'date_from': '0026-10-01', 'date_to': '2026-10-01'}, ('date_from',)),
            ({'date_from': '2026-10-01', 'date_to': '2101-01-01'}, ('date_to',)),
        )
        for params, fields in cases:
            resp = self.client.get(url, dict(params, generate='1'))
            self.assertFalse(resp.context['generated'], params)
            for field in fields:
                self.assertIn(field, resp.context['form'].errors, (params, field))

    def test_pages_ship_the_browser_side_checks(self):
        for name in self.FILTERED + ('reports_invoices',):
            resp = self.client.get(reverse(name))
            self.assertContains(resp, 'data-date-range', msg_prefix=name)
            self.assertContains(resp, 'report_dates.js', msg_prefix=name)
