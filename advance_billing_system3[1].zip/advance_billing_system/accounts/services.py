"""Admin registration logic shared by the web form and the JSON API, so the
two can never disagree about who may register or what makes a valid account."""
import hmac

from collections import namedtuple

from django.conf import settings
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.models import User
from django.core.cache import cache
from django.db import transaction
from django.utils.http import url_has_allowed_host_and_scheme

from . import throttle
from .models import UserProfile


# ---- registration key ------------------------------------------------------

def key_is_configured():
    return bool(getattr(settings, 'ADMIN_REGISTRATION_KEY', ''))


def key_is_valid(supplied):
    """Constant-time comparison; False when registration is not configured."""
    configured = getattr(settings, 'ADMIN_REGISTRATION_KEY', '')
    if not configured or not supplied:
        return False
    return hmac.compare_digest(str(supplied).encode('utf-8'), configured.encode('utf-8'))


# ---- brute-force throttle (per client IP, via Django's cache) ---------------

def _fail_key(request):
    # REMOTE_ADDR on purpose: X-Forwarded-For is client-controlled unless a
    # trusted proxy sets it, so honouring it would let attackers dodge the limit.
    return f"admin-reg-fail:{request.META.get('REMOTE_ADDR', 'unknown')}"


def is_locked_out(request):
    limit = getattr(settings, 'ADMIN_REGISTRATION_MAX_FAILED_KEYS', 5)
    return cache.get(_fail_key(request), 0) >= limit


def record_failed_key(request):
    key = _fail_key(request)
    window = getattr(settings, 'ADMIN_REGISTRATION_LOCKOUT_SECONDS', 900)
    if not cache.add(key, 1, window):
        try:
            cache.incr(key)
        except ValueError:          # expired between add() and incr()
            cache.set(key, 1, window)


# ---- account creation -------------------------------------------------------

def create_admin_user(*, name, email, phone, password):
    """Create a User + UserProfile(role=admin) atomically.

    The account gets the project's Admin *role* only. It is NOT given Django's
    is_staff / is_superuser, so it cannot open the /admin/ database console.
    """
    first_name, _, last_name = name.strip().partition(' ')
    with transaction.atomic():
        user = User.objects.create_user(
            username=email, email=email, password=password,
            first_name=first_name, last_name=last_name,
        )
        UserProfile.objects.create(user=user, role=UserProfile.ROLE_ADMIN, phone=phone)
    return user


# ---- sign-in (shared by the web portals and the JSON API) ---------------------

LoginResult = namedtuple('LoginResult', 'user error')     # error: None | 'invalid' | 'locked'

INVALID_LOGIN_MESSAGE = 'Invalid credentials, or this account is not registered for this portal.'


def locked_message():
    minutes = throttle.lockout_minutes()
    return (f'Too many failed sign-in attempts. Please wait about {minutes} '
            f'minute{"s" if minutes != 1 else ""} and try again.')


def attempt_login(request, *, email, password, role, remember=False):
    """Sign `email` in to the `role` portal. One code path for every client.

    On success the user is stored in the session (the session key is rotated
    by Django's login()), and the session lifetime is set:

      remember=False  cookie dies with the browser; server record also expires
                      after SESSION_COOKIE_AGE of inactivity
      remember=True   lasts SESSION_REMEMBER_ME_AGE, refreshed on activity
    """
    email = (email or '').strip().lower()
    if throttle.is_locked(request, email):
        return LoginResult(None, 'locked')

    user = authenticate(request, email=email, password=password, role=role)
    if user is None:
        throttle.record_failure(request, email)
        return LoginResult(None, 'invalid')

    throttle.clear(request, email)
    auth_login(request, user)
    request.session.set_expiry(settings.SESSION_REMEMBER_ME_AGE if remember else 0)
    return LoginResult(user, None)


def home_url_name(user):
    """Where a signed-in user belongs."""
    profile = getattr(user, 'profile', None)
    return 'admin_dashboard' if profile is not None and profile.role == UserProfile.ROLE_ADMIN else 'distributor_dashboard'


def safe_next_url(request, candidate):
    """`candidate` if it is a same-site URL, else None (stops open redirects)."""
    if candidate and url_has_allowed_host_and_scheme(
            candidate, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        return candidate
    return None
