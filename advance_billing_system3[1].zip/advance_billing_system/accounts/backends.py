from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend

from .models import UserProfile

UserModel = get_user_model()


class PortalBackend(ModelBackend):
    """Sign-in for the two portals (Admin and Distributor).

    Called as  authenticate(request, email=..., password=..., role=...)  and
    succeeds only when ALL of these hold:

      * an account with that email exists (case-insensitive),
      * the password is right and the account is active,
      * the account's role matches the portal being used.

    Every failure returns None, and the caller shows ONE generic message, so a
    wrong password, an unknown email and "right password, wrong portal" are
    indistinguishable from outside.

    Calls without `role` return None here and fall through to Django's normal
    ModelBackend, which is what the built-in /admin/ console uses.
    """

    def authenticate(self, request, email=None, password=None, role=None, **kwargs):
        if email is None or password is None or role is None:
            return None
        if role not in (UserProfile.ROLE_ADMIN, UserProfile.ROLE_DISTRIBUTOR):
            return None

        email = email.strip().lower()
        user = (UserModel._default_manager
                .filter(email__iexact=email).select_related('profile').order_by('pk').first())
        if user is None:
            # Burn the same time as a real hash check so response time does not
            # reveal whether the email exists.
            UserModel().set_password(password)
            return None

        if not user.check_password(password) or not self.user_can_authenticate(user):
            return None

        profile = getattr(user, 'profile', None)
        if profile is None or profile.role != role:
            return None
        return user
