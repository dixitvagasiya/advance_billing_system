"""Session-based sign-in for the Admin and Distributor portals: backend, web
views, throttling, session settings and the JSON API."""
import json
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.sessions.models import Session
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from . import services, throttle
from .backends import PortalBackend
from .models import UserProfile

PW = 'Correct-Horse-9!battery'
ADMIN, DIST = UserProfile.ROLE_ADMIN, UserProfile.ROLE_DISTRIBUTOR
INVALID = services.INVALID_LOGIN_MESSAGE


def make_user(email, role, password=PW, first='', active=True, profile=True):
    user = User.objects.create_user(username=email, email=email, password=password,
                                    first_name=first, is_active=active)
    if profile:
        UserProfile.objects.create(user=user, role=role, phone='+919876543210')
    return user


class AuthTestCase(TestCase):
    def setUp(self):
        cache.clear()
        self.admin = make_user('admin@x.com', ADMIN, first='Asha')
        self.dist = make_user('dist@x.com', DIST, first='Dev')

    def tearDown(self):
        cache.clear()

    def login(self, portal, email, password=PW, client=None, **extra):
        client = client or self.client
        return client.post(reverse(f'{portal}_login'), dict({'email': email, 'password': password}, **extra))


class BackendTests(AuthTestCase):
    def auth(self, email, password=PW, role=None):
        return authenticate(None, email=email, password=password, role=role)

    def test_right_credentials_and_role(self):
        self.assertEqual(self.auth('admin@x.com', role=ADMIN), self.admin)
        self.assertEqual(self.auth('dist@x.com', role=DIST), self.dist)

    def test_the_wrong_portal_is_refused(self):
        self.assertIsNone(self.auth('admin@x.com', role=DIST))
        self.assertIsNone(self.auth('dist@x.com', role=ADMIN))

    def test_wrong_password_unknown_email_and_bad_role(self):
        self.assertIsNone(self.auth('admin@x.com', password='nope', role=ADMIN))
        self.assertIsNone(self.auth('ghost@x.com', role=ADMIN))
        self.assertIsNone(self.auth('admin@x.com', role='superuser'))

    def test_email_is_case_and_space_insensitive(self):
        self.assertEqual(self.auth('  ADMIN@X.com ', role=ADMIN), self.admin)

    def test_inactive_accounts_cannot_sign_in(self):
        make_user('off@x.com', DIST, active=False)
        self.assertIsNone(self.auth('off@x.com', role=DIST))

    def test_accounts_without_a_role_profile_cannot_use_a_portal(self):
        make_user('bare@x.com', DIST, profile=False)
        self.assertIsNone(self.auth('bare@x.com', role=DIST))

    def test_without_a_role_this_backend_steps_aside_for_the_django_console(self):
        self.assertIsNone(PortalBackend().authenticate(None, email='admin@x.com', password=PW))
        # ...and plain username/password still works through ModelBackend (used by /admin/ and client.login)
        self.assertEqual(authenticate(username='admin@x.com', password=PW), self.admin)

    def test_settings(self):
        self.assertEqual(settings.AUTHENTICATION_BACKENDS[0], 'accounts.backends.PortalBackend')
        self.assertTrue(settings.SESSION_COOKIE_HTTPONLY)
        self.assertEqual(settings.SESSION_COOKIE_SAMESITE, 'Lax')
        self.assertTrue(settings.SESSION_SAVE_EVERY_REQUEST)
        self.assertGreater(settings.SESSION_REMEMBER_ME_AGE, settings.SESSION_COOKIE_AGE)


class LoginPageTests(AuthTestCase):
    def test_pages_render_with_the_expected_controls(self):
        for portal, other in (('admin', 'distributor'), ('distributor', 'admin')):
            resp = self.client.get(reverse(f'{portal}_login'))
            self.assertEqual(resp.status_code, 200, portal)
            for needle in ('csrfmiddlewaretoken', 'name="remember_me"', 'data-pw-toggle', 'login.js',
                           'autocomplete="current-password"', 'autocomplete="username"',
                           f'data-portal="{portal}"', reverse(f'{other}_login')):
                self.assertContains(resp, needle, msg_prefix=portal)

    def test_each_portal_links_to_its_own_forgot_password_and_signup(self):
        admin = self.client.get(reverse('admin_login'))
        self.assertContains(admin, reverse('admin_forgot_password'))
        self.assertContains(admin, reverse('admin_register'))
        dist = self.client.get(reverse('distributor_login'))
        self.assertContains(dist, reverse('forgot_password'))
        self.assertContains(dist, reverse('distributor_register'))


class LoginFlowTests(AuthTestCase):
    def test_each_role_signs_in_to_its_own_portal(self):
        for portal, email, dashboard in (('admin', 'admin@x.com', 'admin_dashboard'),
                                         ('distributor', 'dist@x.com', 'distributor_dashboard')):
            client = Client()
            resp = self.login(portal, email, client=client)
            self.assertRedirects(resp, reverse(dashboard), fetch_redirect_response=False)
            self.assertIn('_auth_user_id', client.session)
            self.assertContains(client.get(reverse(dashboard)), 'Welcome back')

    def test_a_cross_portal_attempt_fails_with_the_same_message_as_a_wrong_password(self):
        wrong_portal = self.login('admin', 'dist@x.com')
        wrong_password = self.login('admin', 'admin@x.com', password='nope')
        unknown = self.login('admin', 'ghost@x.com')
        for resp in (wrong_portal, wrong_password, unknown):
            self.assertEqual(resp.status_code, 200)
            self.assertContains(resp, INVALID)
            self.assertNotIn('_auth_user_id', self.client.session)

    def test_the_email_is_kept_but_the_password_is_never_echoed(self):
        resp = self.login('distributor', 'dist@x.com', password='my-secret-guess')
        self.assertContains(resp, 'value="dist@x.com"')
        self.assertNotContains(resp, 'my-secret-guess')

    def test_email_is_case_insensitive_and_trimmed(self):
        resp = self.login('distributor', '  DIST@X.com  ')
        self.assertRedirects(resp, reverse('distributor_dashboard'), fetch_redirect_response=False)

    def test_blank_and_malformed_input_is_rejected_without_counting_as_an_attempt(self):
        resp = self.login('admin', '', password='')
        self.assertContains(resp, 'Enter your email address.')
        self.assertContains(resp, 'Enter your password.')
        self.assertContains(self.login('admin', 'not-an-email'), 'Enter a valid email address.')
        for _ in range(10):
            self.login('admin', '', password='')
        self.assertRedirects(self.login('admin', 'admin@x.com'), reverse('admin_dashboard'), fetch_redirect_response=False)

    def test_inactive_and_role_less_accounts_get_the_generic_error(self):
        make_user('off@x.com', DIST, active=False)
        make_user('bare@x.com', DIST, profile=False)
        for email in ('off@x.com', 'bare@x.com'):
            self.assertContains(self.login('distributor', email), INVALID)

    def test_signed_in_users_are_sent_to_their_own_dashboard_from_either_login_page(self):
        self.client.force_login(self.admin)
        self.assertRedirects(self.client.get(reverse('distributor_login')), reverse('admin_dashboard'), fetch_redirect_response=False)
        other = Client(); other.force_login(self.dist)
        self.assertRedirects(other.get(reverse('admin_login')), reverse('distributor_dashboard'), fetch_redirect_response=False)

    def test_login_required_pages_send_visitors_to_the_login_page_with_next(self):
        resp = self.client.get(reverse('invoice_list'))
        self.assertEqual(resp.status_code, 302)
        self.assertIn(reverse('distributor_login'), resp.url)
        self.assertIn('next=', resp.url)

    def test_session_key_is_rotated_on_sign_in(self):
        session = self.client.session
        session['anonymous'] = 'data'
        session.save()
        before = session.session_key
        self.login('distributor', 'dist@x.com')
        self.assertNotEqual(self.client.session.session_key, before)
        self.assertFalse(Session.objects.filter(session_key=before).exists())


class NextUrlTests(AuthTestCase):
    def test_a_safe_next_is_honoured_and_shown(self):
        page = self.client.get(reverse('distributor_login'), {'next': '/billing/'})
        self.assertContains(page, 'name="next" value="/billing/"')
        self.assertContains(page, 'Please sign in to continue.')
        resp = self.client.post(reverse('distributor_login'), {'email': 'dist@x.com', 'password': PW, 'next': '/billing/'})
        self.assertRedirects(resp, '/billing/', fetch_redirect_response=False)

    def test_unsafe_next_values_are_ignored(self):
        for bad in ('https://evil.example/', '//evil.example/', 'javascript:alert(1)', 'http://evil.example'):
            client = Client()
            page = client.get(reverse('distributor_login'), {'next': bad})
            self.assertNotContains(page, 'name="next"', msg_prefix=bad)
            resp = client.post(reverse('distributor_login'), {'email': 'dist@x.com', 'password': PW, 'next': bad})
            self.assertRedirects(resp, reverse('distributor_dashboard'), fetch_redirect_response=False, msg_prefix=bad)


class SessionTests(AuthTestCase):
    def test_without_remember_me_the_cookie_dies_with_the_browser(self):
        resp = self.login('distributor', 'dist@x.com')
        self.assertTrue(self.client.session.get_expire_at_browser_close())
        self.assertEqual(resp.cookies['sessionid']['max-age'], '')

    def test_remember_me_keeps_the_user_signed_in_for_longer(self):
        resp = self.login('distributor', 'dist@x.com', remember_me='on')
        self.assertFalse(self.client.session.get_expire_at_browser_close())
        self.assertEqual(self.client.session.get_expiry_age(), settings.SESSION_REMEMBER_ME_AGE)
        self.assertEqual(int(resp.cookies['sessionid']['max-age']), settings.SESSION_REMEMBER_ME_AGE)

    def test_the_session_cookie_is_httponly_and_samesite(self):
        cookie = self.login('distributor', 'dist@x.com').cookies['sessionid']
        self.assertTrue(cookie['httponly'])
        self.assertEqual(cookie['samesite'], 'Lax')

    @override_settings(SESSION_COOKIE_SECURE=True)
    def test_the_secure_flag_can_be_switched_on_for_https(self):
        self.assertTrue(self.login('distributor', 'dist@x.com').cookies['sessionid']['secure'])

    def test_an_expired_session_sends_the_user_back_to_sign_in(self):
        self.login('distributor', 'dist@x.com')
        self.assertEqual(self.client.get(reverse('invoice_list')).status_code, 200)
        Session.objects.update(expire_date=timezone.now() - timedelta(seconds=1))
        resp = self.client.get(reverse('invoice_list'))
        self.assertEqual(resp.status_code, 302)
        self.assertIn(reverse('distributor_login'), resp.url)

    def test_admin_only_pages_stay_closed_to_a_distributor_session(self):
        self.login('distributor', 'dist@x.com')
        self.assertEqual(self.client.get(reverse('reports_overview')).status_code, 403)


class LogoutTests(AuthTestCase):
    def test_post_signs_out_deletes_the_server_session_and_goes_to_the_right_portal(self):
        for portal, email in (('admin', 'admin@x.com'), ('distributor', 'dist@x.com')):
            client = Client()
            self.login(portal, email, client=client)
            key = client.session.session_key
            resp = client.post(reverse('logout'))
            self.assertRedirects(resp, reverse(f'{portal}_login'), fetch_redirect_response=False)
            self.assertNotIn('_auth_user_id', client.session)
            self.assertFalse(Session.objects.filter(session_key=key).exists())
            self.assertContains(client.get(reverse(f'{portal}_login')), 'You have been signed out.')

    def test_get_does_not_sign_out(self):
        self.login('distributor', 'dist@x.com')
        self.assertEqual(self.client.get(reverse('logout')).status_code, 405)
        self.assertIn('_auth_user_id', self.client.session)

    def test_csrf_protects_logout(self):
        strict = Client(enforce_csrf_checks=True)
        strict.force_login(self.dist)
        self.assertEqual(strict.post(reverse('logout')).status_code, 403)
        self.assertIn('_auth_user_id', strict.session)

    def test_the_nav_uses_a_post_form(self):
        self.login('distributor', 'dist@x.com')
        html = self.client.get(reverse('distributor_dashboard')).content.decode()
        self.assertIn(f'action="{reverse("logout")}"', html)
        self.assertIn('class="nav-logout"', html)

    def test_pages_are_closed_again_after_signing_out(self):
        self.login('distributor', 'dist@x.com')
        self.client.post(reverse('logout'))
        self.assertEqual(self.client.get(reverse('invoice_list')).status_code, 302)


class ThrottleTests(AuthTestCase):
    def fail(self, n, email='admin@x.com', portal='admin', **extra):
        for _ in range(n):
            self.login(portal, email, password='wrong', **extra)

    def test_five_wrong_passwords_lock_that_account_for_that_address(self):
        self.fail(5)
        resp = self.login('admin', 'admin@x.com')                        # even the RIGHT password is refused now
        self.assertEqual(resp.status_code, 429)
        self.assertContains(resp, 'Too many failed sign-in attempts', status_code=429)
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_four_failures_are_not_enough(self):
        self.fail(4)
        self.assertRedirects(self.login('admin', 'admin@x.com'), reverse('admin_dashboard'), fetch_redirect_response=False)

    def test_a_good_sign_in_resets_the_counter(self):
        self.fail(4)
        self.login('admin', 'admin@x.com', client=Client())
        self.fail(4)
        self.assertEqual(self.login('admin', 'admin@x.com').status_code, 302)

    def test_other_accounts_and_other_addresses_are_unaffected(self):
        self.fail(5)
        self.assertEqual(self.login('distributor', 'dist@x.com', client=Client()).status_code, 302)
        elsewhere = Client(REMOTE_ADDR='10.9.8.7')                         # the real owner, from another address
        self.assertEqual(self.login('admin', 'admin@x.com', client=elsewhere).status_code, 302)

    def test_both_portals_share_the_lock(self):
        self.fail(5)
        self.assertEqual(self.login('distributor', 'admin@x.com').status_code, 429)

    @override_settings(LOGIN_MAX_FAILURES_PER_IP=3)
    def test_one_address_spraying_many_accounts_is_stopped(self):
        for i in range(3):
            self.login('admin', f'user{i}@x.com', password='wrong')
        self.assertEqual(self.login('admin', 'admin@x.com').status_code, 429)

    def test_email_case_does_not_dodge_the_lock(self):
        for email in ('ADMIN@x.com', 'Admin@X.com', 'admin@x.com ', 'ADMIN@X.COM', 'admin@X.com'):
            self.login('admin', email, password='wrong')
        self.assertEqual(self.login('admin', 'admin@x.com').status_code, 429)

    def test_the_lockout_message_names_a_sensible_wait(self):
        self.assertEqual(throttle.lockout_minutes(), 15)
        self.assertIn('15 minutes', services.locked_message())


class ApiTests(AuthTestCase):
    def setUp(self):
        super().setUp()
        self.api = Client(enforce_csrf_checks=True)
        self.token = self.api.get(reverse('api_auth_csrf')).json()['csrfToken']

    def post(self, name, body=None, token=True, client=None, raw=None):
        client = client or self.api
        data = raw if raw is not None else json.dumps(body if body is not None else {})
        extra = {}
        if token:
            # Signing in rotates Django's CSRF secret, so always ask for the current token.
            extra['HTTP_X_CSRFTOKEN'] = client.get(reverse('api_auth_csrf')).json()['csrfToken']
        return client.post(reverse(name), data, content_type='application/json', **extra)

    def sign_in(self, email='admin@x.com', role=ADMIN, password=PW, **extra):
        return self.post('api_auth_login', dict({'email': email, 'password': password, 'role': role}, **extra))

    def test_csrf_endpoint_sets_the_cookie_and_returns_the_token(self):
        self.assertTrue(self.token)
        self.assertIn('csrftoken', self.api.cookies)

    def test_login_needs_the_csrf_token(self):
        resp = self.post('api_auth_login', {'email': 'admin@x.com', 'password': PW, 'role': ADMIN}, token=False)
        self.assertEqual(resp.status_code, 403)

    def test_successful_login_returns_the_user_and_starts_a_session(self):
        resp = self.sign_in()
        self.assertEqual(resp.status_code, 200)
        user = resp.json()['user']
        self.assertEqual((user['email'], user['role'], user['name']), ('admin@x.com', 'admin', 'Asha'))
        self.assertNotIn('password', json.dumps(user))
        self.assertIn('sessionid', resp.cookies)
        self.assertTrue(resp.cookies['sessionid']['httponly'])
        session = self.api.get(reverse('api_auth_session'))
        self.assertEqual(session.status_code, 200)
        self.assertEqual(session.json()['user']['id'], self.admin.pk)

    def test_both_roles_can_sign_in(self):
        self.assertEqual(self.sign_in('dist@x.com', DIST).json()['user']['role'], 'distributor')

    def test_failures_are_indistinguishable(self):
        bodies = [self.sign_in(password='nope'), self.sign_in('ghost@x.com'), self.sign_in('dist@x.com', ADMIN)]
        for resp in bodies:
            self.assertEqual(resp.status_code, 401)
            self.assertEqual(resp.json(), {'error': INVALID})

    def test_bad_requests(self):
        cases = (
            dict(raw='not json'), dict(raw='[1, 2]'),
            dict(body={'password': PW, 'role': ADMIN}),
            dict(body={'email': 'admin@x.com', 'role': ADMIN}),
            dict(body={'email': 'admin@x.com', 'password': PW}),
            dict(body={'email': 'admin@x.com', 'password': PW, 'role': 'root'}),
            dict(body={'email': 123, 'password': PW, 'role': ADMIN}),
            dict(body={'email': 'admin@x.com', 'password': ['x'], 'role': ADMIN}),
            dict(body={'email': 'a' * 300 + '@x.com', 'password': PW, 'role': ADMIN}),
        )
        for case in cases:
            resp = self.post('api_auth_login', **case)
            self.assertEqual(resp.status_code, 400, case)
            self.assertIn('error', resp.json(), case)

    def test_methods(self):
        self.assertEqual(self.api.get(reverse('api_auth_login')).status_code, 405)
        self.assertEqual(self.post('api_auth_session', {}).status_code, 405)
        self.assertEqual(self.api.get(reverse('api_auth_logout')).status_code, 405)

    def test_session_endpoint_when_signed_out(self):
        resp = Client().get(reverse('api_auth_session'))
        self.assertEqual((resp.status_code, resp.json()), (401, {'authenticated': False}))

    def test_remember_me_must_be_a_real_boolean(self):
        self.assertTrue(self.sign_in(remember_me=False).cookies['sessionid']['max-age'] == '')
        self.assertEqual(self.sign_in(remember_me='yes').cookies['sessionid']['max-age'], '')
        self.assertEqual(int(self.sign_in(remember_me=True).cookies['sessionid']['max-age']),
                         settings.SESSION_REMEMBER_ME_AGE)

    def test_logout_deletes_the_session(self):
        self.sign_in()
        key = self.api.cookies['sessionid'].value
        self.assertEqual(self.post('api_auth_logout').status_code, 200)
        self.assertFalse(Session.objects.filter(session_key=key).exists())
        self.assertEqual(self.api.get(reverse('api_auth_session')).status_code, 401)

    def test_logout_needs_the_csrf_token(self):
        self.sign_in()
        self.assertEqual(self.post('api_auth_logout', token=False).status_code, 403)

    def test_the_api_shares_the_brute_force_lock(self):
        for _ in range(5):
            self.sign_in(password='nope')
        resp = self.sign_in()
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(resp['Retry-After'], '900')
        self.assertIn('Too many failed', resp.json()['error'])
