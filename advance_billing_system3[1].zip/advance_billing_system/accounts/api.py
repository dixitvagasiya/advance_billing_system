"""JSON API for accounts.

POST /accounts/api/admin/register/
    Create an Admin-role account. Requires the server's registration key.

    Request  (Content-Type: application/json)
        {
          "name": "Priya Sharma",
          "email": "priya@company.com",
          "phone": "+919876543210",            // optional
          "password": "a-strong-password",
          "confirm_password": "a-strong-password",   // optional; checked if sent
          "registration_key": "<ADMIN_REGISTRATION_KEY>"
        }

    Responses
        201 {"id", "name", "email", "phone", "role": "admin"}
        400 {"errors": {"<field>": ["message", ...]}}   validation problems
            {"error": "..."}                            malformed body
        403 {"error": "..."}   wrong/missing key, or registration not enabled
        405 {"error": "..."}   any method other than POST
        429 {"error": "..."}   too many wrong keys from this address

POST /accounts/api/admin/password-recovery/request/
    Email a 6-digit OTP to an Admin account's address.
        Request   {"email": "priya@company.com"}
        202 {"detail": "If an admin account exists ..."}   ALWAYS the same answer, so it
            cannot be used to discover which emails are registered
        400 {"error"} bad body / missing or malformed email
        429 {"error"} too soon after the previous request (Retry-After header set)

POST /accounts/api/admin/password-recovery/reset/
    Verify the OTP and set a new password.
        Request   {"email": "...", "otp": "123456", "new_password": "...",
                   "confirm_password": "..."}      // confirm optional; checked if sent
        200 {"detail": "Password updated."}
        400 {"error": "Invalid or expired code."}                 wrong/expired/used code
            {"errors": {"new_password": ["..."]}}                 password rules
        A code is burned after 5 wrong guesses; request a new one.

Session sign-in (cookie + CSRF, unlike the endpoints above)
    GET  /accounts/api/auth/csrf/      200 {"csrfToken"}; also sets the csrftoken cookie.
    POST /accounts/api/auth/login/     Body {"email", "password", "role": "admin"|"distributor",
                                             "remember_me": false}
         200 {"user": {...}}  and a sessionid cookie.   400 bad body/field.
         401 {"error"} wrong credentials OR wrong portal (deliberately the same answer).
         429 {"error"} too many failed attempts.  Send the token in the X-CSRFToken header.
    GET  /accounts/api/auth/session/   200 {"authenticated": true, "user": {...}} or 401.
    POST /accounts/api/auth/logout/    200 {"detail"}; the server-side session is deleted.

Notes (registration / recovery endpoints)
    * No session or cookie is used or created, so CSRF does not apply and the
      endpoint is csrf_exempt. The caller is authorised solely by the key.
      It does not log the new admin in.
    * The key is checked before anything else, so an unauthorised caller
      learns nothing about existing accounts.
"""
import json

from django.conf import settings
from django.contrib.auth import logout as auth_logout
from django.db import IntegrityError
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie
from django.views.decorators.http import require_http_methods

from . import recovery, services
from .forms import AdminRegistrationForm, ForgotPasswordForm
from .models import UserProfile


def _error(message, status, **headers):
    response = JsonResponse({'error': message}, status=status)
    for name, value in headers.items():
        response[name.replace('_', '-')] = value
    return response


@csrf_exempt
def admin_register(request):
    if request.method != 'POST':
        return _error('Method not allowed. Use POST.', 405, Allow='POST')

    if not services.key_is_configured():
        return _error('Admin registration is not enabled on this server.', 403)

    if services.is_locked_out(request):
        return _error('Too many invalid registration keys. Try again later.', 429,
                      Retry_After=settings.ADMIN_REGISTRATION_LOCKOUT_SECONDS)

    try:
        data = json.loads(request.body or b'')
    except (ValueError, UnicodeDecodeError):
        return _error('Request body must be valid JSON.', 400)
    if not isinstance(data, dict):
        return _error('Request body must be a JSON object.', 400)

    form = AdminRegistrationForm(data, require_confirm=False)
    valid = form.is_valid()

    if form.key_failed:
        services.record_failed_key(request)
        return _error('Invalid registration key.', 403)

    if not valid:
        return JsonResponse({'errors': {field: list(errs) for field, errs in form.errors.items()}}, status=400)

    try:
        user = services.create_admin_user(
            name=form.cleaned_data['name'],
            email=form.cleaned_data['email'],
            phone=form.cleaned_data['phone'],
            password=form.cleaned_data['password'],
        )
    except IntegrityError:
        return JsonResponse({'errors': {'email': ['An account with this email already exists.']}}, status=400)

    return JsonResponse({
        'id': user.pk,
        'name': user.get_full_name(),
        'email': user.email,
        'phone': user.profile.phone,
        'role': user.profile.role,
    }, status=201)


# ---- admin password recovery ---------------------------------------------------

def _json_body(request):
    """Parsed JSON object, or an error response."""
    try:
        data = json.loads(request.body or b'')
    except (ValueError, UnicodeDecodeError):
        return None, _error('Request body must be valid JSON.', 400)
    if not isinstance(data, dict):
        return None, _error('Request body must be a JSON object.', 400)
    return data, None


@csrf_exempt
def admin_password_recovery_request(request):
    if request.method != 'POST':
        return _error('Method not allowed. Use POST.', 405, Allow='POST')
    data, err = _json_body(request)
    if err:
        return err

    form = ForgotPasswordForm({'email': data.get('email', '')})
    if not form.is_valid():
        return JsonResponse({'errors': {f: list(e) for f, e in form.errors.items()}}, status=400)

    try:
        recovery.request_otp(form.cleaned_data['email'], UserProfile.ROLE_ADMIN)
    except recovery.Throttled as exc:
        return _error('Too many code requests. Please wait before trying again.', 429,
                      Retry_After=exc.retry_after)
    return JsonResponse({'detail': 'If an admin account exists for that email, a 6-digit code has been sent.'},
                        status=202)


@csrf_exempt
def admin_password_recovery_reset(request):
    if request.method != 'POST':
        return _error('Method not allowed. Use POST.', 405, Allow='POST')
    data, err = _json_body(request)
    if err:
        return err

    email = str(data.get('email', '') or '')
    code = str(data.get('otp', '') or '').strip()
    new_password = data.get('new_password')
    confirm = data.get('confirm_password')

    errors = {}
    if not email:
        errors['email'] = ['This field is required.']
    if not (len(code) == 6 and code.isdigit()):
        errors['otp'] = ['Enter the 6-digit code.']
    if not isinstance(new_password, str) or not new_password:
        errors['new_password'] = ['This field is required.']
    elif len(new_password) < 8:
        errors['new_password'] = ['Ensure this value has at least 8 characters.']
    elif confirm is not None and confirm != new_password:
        errors['confirm_password'] = ['Passwords do not match.']
    if errors:
        return JsonResponse({'errors': errors}, status=400)

    status, problems = recovery.reset_password(email, UserProfile.ROLE_ADMIN, code, new_password)
    if status == recovery.OK:
        return JsonResponse({'detail': 'Password updated.'})
    if status == recovery.WEAK_PASSWORD:
        return JsonResponse({'errors': {'new_password': problems}}, status=400)
    return _error('Invalid or expired code.', 400)


# ---- session sign-in -----------------------------------------------------------
# These endpoints DO use a session cookie, so (unlike the key-protected ones
# above) CSRF protection stays on: clients fetch /auth/csrf/ first and echo the
# token back in the X-CSRFToken header.

def _user_json(user):
    profile = user.profile
    return {'id': user.pk, 'name': user.get_full_name() or user.username, 'email': user.email,
            'role': profile.role, 'phone': profile.phone}


@ensure_csrf_cookie
@require_http_methods(['GET'])
def auth_csrf(request):
    return JsonResponse({'csrfToken': get_token(request)})


@require_http_methods(['POST'])
def auth_login(request):
    data, err = _json_body(request)
    if err:
        return err
    email, password, role = data.get('email'), data.get('password'), data.get('role')
    if not isinstance(email, str) or not email.strip() or not isinstance(password, str) or not password:
        return _error('Email and password are required.', 400)
    if role not in (UserProfile.ROLE_ADMIN, UserProfile.ROLE_DISTRIBUTOR):
        return _error('role must be "admin" or "distributor".', 400)
    if len(email) > 254 or len(password) > 128:
        return _error('Email or password is too long.', 400)

    result = services.attempt_login(request, email=email, password=password, role=role,
                                    remember=data.get('remember_me') is True)
    if result.error == 'locked':
        return _error(services.locked_message(), 429, Retry_After=services.throttle.lockout_minutes() * 60)
    if result.user is None:
        return _error(services.INVALID_LOGIN_MESSAGE, 401)
    return JsonResponse({'user': _user_json(result.user)})


@require_http_methods(['GET'])
def auth_session(request):
    if not request.user.is_authenticated or not hasattr(request.user, 'profile'):
        return JsonResponse({'authenticated': False}, status=401)
    return JsonResponse({'authenticated': True, 'user': _user_json(request.user)})


@require_http_methods(['POST'])
def auth_logout_api(request):
    auth_logout(request)
    return JsonResponse({'detail': 'Signed out.'})
