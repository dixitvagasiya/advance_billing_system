"""Sign-in brute-force protection, kept in Django's cache.

Two counters, both reset by a successful sign-in or by waiting out the window:

  per (IP, email)  LOGIN_MAX_FAILURES (5)   a guessing attack on one account.
                   Scoped to the attacker's IP, so they cannot lock the real
                   owner out from somewhere else.
  per IP           LOGIN_MAX_FAILURES_PER_IP (30)   one address trying many accounts.

REMOTE_ADDR is used on purpose: X-Forwarded-For is client-controlled unless a
trusted proxy sets it, so honouring it would let attackers dodge the limit.
(Behind a reverse proxy, configure it to set REMOTE_ADDR properly.)
"""
import hashlib

from django.conf import settings
from django.core.cache import cache


def _ip(request):
    return request.META.get('REMOTE_ADDR', 'unknown')


def _keys(request, email):
    digest = hashlib.sha256((email or '').strip().lower().encode('utf-8')).hexdigest()[:32]
    ip = _ip(request)
    return f'login-fail:acct:{ip}:{digest}', f'login-fail:ip:{ip}'


def _window():
    return getattr(settings, 'LOGIN_LOCKOUT_SECONDS', 15 * 60)


def _limits():
    return (getattr(settings, 'LOGIN_MAX_FAILURES', 5),
            getattr(settings, 'LOGIN_MAX_FAILURES_PER_IP', 30))


def is_locked(request, email):
    account_key, ip_key = _keys(request, email)
    per_account, per_ip = _limits()
    return cache.get(account_key, 0) >= per_account or cache.get(ip_key, 0) >= per_ip


def record_failure(request, email):
    for key in _keys(request, email):
        if not cache.add(key, 1, _window()):
            try:
                cache.incr(key)
            except ValueError:              # expired between add() and incr()
                cache.set(key, 1, _window())


def clear(request, email):
    """After a good sign-in: forget this account's failures (the per-IP count ages out)."""
    cache.delete(_keys(request, email)[0])


def lockout_minutes():
    return max(1, _window() // 60)
