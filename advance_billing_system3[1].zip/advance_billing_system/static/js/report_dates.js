/* Report date filters: stop empty or reversed date ranges before the request is made.
 * The server enforces the same rules, so this only saves a round trip. */
(function () {
  'use strict';
  var MIN = '2000-01-01', MAX = '2100-12-31';       // keep in step with reports/forms.py

  document.querySelectorAll('form[data-date-range]').forEach(function (form) {
    var from = form.elements['date_from'];
    var to = form.elements['date_to'];
    if (!from || !to) return;

    [from, to].forEach(function (input) {
      input.min = MIN; input.max = MAX; input.required = true;
    });

    function link() {
      to.min = from.value || MIN;                   // the end cannot precede the start
      from.max = to.value || MAX;                   // ...and the start cannot follow the end
    }

    function showError(input, message) {
      var group = input.closest('.field-group');
      var box = group.querySelector('.js-hint');
      if (!message) { if (box) box.remove(); input.removeAttribute('aria-invalid'); return; }
      if (!box) {
        box = document.createElement('div');
        box.className = 'field-error js-hint';
        box.setAttribute('role', 'alert');
        group.appendChild(box);
      }
      box.textContent = message;
      input.setAttribute('aria-invalid', 'true');
    }

    function problem(input, label) {
      if (!input.value) return 'Choose ' + label + '.';
      if (input.value < MIN || input.value > MAX) return 'Enter a date between 01 Jan 2000 and 31 Dec 2100.';
      return '';
    }

    function check() {
      var fromMsg = problem(from, 'a start date');
      var toMsg = problem(to, 'an end date');
      if (!fromMsg && !toMsg && from.value > to.value) toMsg = 'The end date cannot be before the start date.';
      showError(from, fromMsg);
      showError(to, toMsg);
      return !(fromMsg || toMsg);
    }

    [from, to].forEach(function (input) {
      input.addEventListener('change', function () { link(); if (input.getAttribute('aria-invalid')) check(); });
    });
    link();

    form.addEventListener('submit', function (event) {
      if (!check()) {
        event.preventDefault();
        (from.getAttribute('aria-invalid') ? from : to).focus();
      }
    });
  });
})();
