/* Sign-in pages: show/hide password, Caps Lock hint, instant field checks and a
 * double-submit guard. The server validates everything again; this only saves a
 * round trip and makes the form friendlier. */
(function () {
  'use strict';
  var form = document.getElementById('login-form');
  if (!form) return;

  var email = form.elements['email'];
  var password = form.elements['password'];
  var submit = form.querySelector('button[type="submit"]');
  var toggle = form.querySelector('[data-pw-toggle]');
  var capsHint = form.querySelector('[data-caps-hint]');
  var idleLabel = submit.textContent;
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // ---- show / hide password
  toggle.addEventListener('click', function () {
    var show = password.type === 'password';
    password.type = show ? 'text' : 'password';
    toggle.textContent = show ? 'Hide' : 'Show';
    toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
    toggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    password.focus();
  });

  // ---- Caps Lock hint
  function caps(event) {
    if (event.getModifierState) capsHint.hidden = !event.getModifierState('CapsLock');
  }
  password.addEventListener('keydown', caps);
  password.addEventListener('keyup', caps);
  password.addEventListener('blur', function () { capsHint.hidden = true; });

  // ---- inline errors
  function setError(input, message) {
    var field = input.closest('.field');
    var box = field.querySelector('.js-error');
    if (!message) {
      if (box) box.remove();
      field.classList.remove('has-error');
      input.removeAttribute('aria-invalid');
      return;
    }
    if (!box) {
      box = document.createElement('p');
      box.className = 'js-error';
      box.setAttribute('role', 'alert');
      field.appendChild(box);
    }
    box.textContent = message;
    field.classList.add('has-error');
    input.setAttribute('aria-invalid', 'true');
  }

  function emailProblem() {
    var value = email.value.trim();
    if (!value) return 'Enter your email address.';
    return EMAIL_RE.test(value) ? '' : 'Enter a valid email address.';
  }
  function passwordProblem() { return password.value ? '' : 'Enter your password.'; }

  email.addEventListener('blur', function () { if (email.value) setError(email, emailProblem()); });
  email.addEventListener('input', function () { if (email.getAttribute('aria-invalid')) setError(email, emailProblem()); });
  password.addEventListener('input', function () { if (password.getAttribute('aria-invalid')) setError(password, passwordProblem()); });

  // ---- submit
  form.addEventListener('submit', function (event) {
    if (form.dataset.submitting === '1') { event.preventDefault(); return; }   // ignore double clicks

    var emailMsg = emailProblem();
    var passMsg = passwordProblem();
    setError(email, emailMsg);
    setError(password, passMsg);
    if (emailMsg || passMsg) {
      event.preventDefault();
      (emailMsg ? email : password).focus();
      return;
    }
    email.value = email.value.trim();
    form.dataset.submitting = '1';
    submit.disabled = true;
    submit.textContent = submit.dataset.loadingText || 'Signing in\u2026';
  });

  // Coming back via the browser's Back button must not leave the button stuck.
  window.addEventListener('pageshow', function () {
    form.dataset.submitting = '';
    submit.disabled = false;
    submit.textContent = idleLabel;
    password.value = '';
  });
})();
