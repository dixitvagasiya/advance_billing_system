/* Toast notifications: auto-dismiss + manual close.
 *
 * Toasts rendered by the server (Django messages) are picked up on load; pages can
 * also raise their own with  window.showToast('success' | 'error' | 'warning' | 'info', text).
 * Errors stay until closed, everything else fades out. Text is always set with
 * textContent, so message text can never inject markup. */
(function () {
  'use strict';
  var stack = document.getElementById('toast-stack');
  if (!stack) return;

  var ICONS = { success: '\u2713', error: '!', warning: '!', info: 'i' };
  var MAX_VISIBLE = 5;

  function dismiss(toast) {
    if (!toast || toast.classList.contains('toast-leaving')) return;
    toast.classList.add('toast-leaving');
    setTimeout(function () { toast.remove(); }, 300);
  }

  function arm(toast, i) {
    // stagger the entrance slightly when several arrive together
    toast.style.animationDelay = (i * 90) + 'ms';
    if (toast.classList.contains('toast-error')) return;
    var timer = setTimeout(function () { dismiss(toast); }, 6000 + i * 600);
    // pause the countdown while the pointer is over the toast
    toast.addEventListener('mouseenter', function () { clearTimeout(timer); });
    toast.addEventListener('mouseleave', function () {
      timer = setTimeout(function () { dismiss(toast); }, 2500);
    });
  }

  stack.querySelectorAll('.toast').forEach(arm);

  stack.addEventListener('click', function (e) {
    if (e.target.classList.contains('toast-close')) dismiss(e.target.closest('.toast'));
  });

  window.showToast = function (kind, text, index) {
    kind = ICONS[kind] ? kind : 'info';
    var toast = document.createElement('div');
    toast.className = 'toast toast-' + kind;
    toast.setAttribute('role', kind === 'error' ? 'alert' : 'status');

    var icon = document.createElement('span');
    icon.className = 'toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = ICONS[kind];

    var body = document.createElement('span');
    body.className = 'toast-text';
    body.textContent = String(text);

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'toast-close';
    close.setAttribute('aria-label', 'Dismiss notification');
    close.textContent = '\u00d7';

    toast.appendChild(icon); toast.appendChild(body); toast.appendChild(close);
    stack.appendChild(toast);
    arm(toast, index || 0);

    // keep the screen tidy if many arrive at once
    var all = stack.querySelectorAll('.toast:not(.toast-leaving)');
    for (var n = 0; n < all.length - MAX_VISIBLE; n++) dismiss(all[n]);
    return toast;
  };
})();
