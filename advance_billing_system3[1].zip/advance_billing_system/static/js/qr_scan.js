/* QR upload page: validates the chosen image, posts it to the decode endpoint, then shows
 * the parsed invoice and raises a toast for every outcome (success, warning or error).
 * Everything that came from the server or the QR code is inserted with textContent,
 * never innerHTML, so a hostile QR code cannot inject markup. */
(function () {
  'use strict';
  var root = document.getElementById('qr-scan');
  if (!root) return;

  var form = document.getElementById('qr-form');
  var input = document.getElementById('qr-image');
  var button = document.getElementById('qr-submit');
  var alertBox = document.getElementById('qr-alert');
  var results = document.getElementById('qr-results');
  var previewWrap = document.getElementById('qr-preview-wrap');
  var preview = document.getElementById('qr-preview');

  var MAX_BYTES = 5 * 1024 * 1024;
  var ALLOWED_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/bmp'];
  var ALLOWED_EXT = /\.(png|jpe?g|webp|gif|bmp)$/i;

  // ---- small DOM helpers ------------------------------------------------
  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }
  function money(value) {
    var n = Number(value);
    if (!isFinite(n)) return '\u20b9' + value;
    return '\u20b9' + n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function niceDate(iso) {
    var d = new Date(iso + 'T00:00:00');
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  }
  function definitionList(rows) {
    var dl = el('dl', 'qr-dl');
    rows.forEach(function (row) {
      if (row[1] === undefined || row[1] === null || row[1] === '') return;
      dl.appendChild(el('dt', null, row[0]));
      dl.appendChild(el('dd', null, row[1]));
    });
    return dl;
  }

  // ---- messages: one inline alert + one toast per outcome ---------------
  function inline(kind, text) {
    alertBox.className = 'qr-alert qr-alert-' + kind;
    alertBox.setAttribute('role', kind === 'error' ? 'alert' : 'status');
    alertBox.textContent = text || '';
    alertBox.hidden = !text;
  }
  function notify(kind, text) {
    if (window.showToast) window.showToast(kind, text);
  }
  function fail(text) { inline('error', text); notify('error', text); }

  // ---- checks before anything is uploaded --------------------------------
  function clientProblem(file) {
    if (!file) return 'Choose an image first.';
    if (file.size === 0) return 'That file is empty. Choose an image that contains a QR code.';
    var typeOk = !file.type || ALLOWED_TYPES.indexOf(file.type) !== -1;
    if (!typeOk || !ALLOWED_EXT.test(file.name)) return 'Upload a PNG, JPEG, WEBP, GIF or BMP image.';
    if (file.size > MAX_BYTES) return 'That image is larger than 5 MB.';
    return '';
  }

  // ---- rendering ---------------------------------------------------------
  function qrFields(parsed) {
    if (!parsed) return [];
    return [
      ['Invoice', parsed.number],
      ['Customer', parsed.customer],
      ['Items', parsed.items !== undefined ? String(parsed.items) : ''],
      ['Total', parsed.total !== undefined ? money(parsed.total) : ''],
      ['Date', parsed.date ? niceDate(parsed.date) : '']
    ];
  }

  function itemsTable(inv) {
    var wrap = el('div', 'item-table-wrap');
    var table = el('table', 'invoice-table');
    var head = el('tr');
    [['Item', ''], ['Qty', 'num'], ['Unit price', 'num'], ['Line total', 'num']].forEach(function (h) {
      head.appendChild(el('th', h[1], h[0]));
    });
    table.appendChild(el('thead')).appendChild(head);
    var body = el('tbody');
    inv.items.forEach(function (item) {
      var tr = el('tr');
      tr.appendChild(el('td', null, item.description));
      tr.appendChild(el('td', 'num', item.quantity));
      tr.appendChild(el('td', 'num', money(item.unit_price)));
      tr.appendChild(el('td', 'num', money(item.line_total)));
      body.appendChild(tr);
    });
    table.appendChild(body);
    wrap.appendChild(table);
    if (inv.items_truncated) wrap.appendChild(el('p', 'range-note', 'Only the first ' + inv.items.length + ' items are shown.'));
    return wrap;
  }

  function rawText(text) {
    var details = el('details', 'qr-raw');
    details.appendChild(el('summary', null, 'Raw QR text'));
    details.appendChild(el('pre', 'qr-payload', text));
    return details;
  }

  function problemList(problems) {
    var ul = el('ul', 'qr-problems');
    problems.forEach(function (p) { ul.appendChild(el('li', null, p)); });
    return ul;
  }

  function invoiceCard(code) {
    var inv = code.invoice;
    var card = el('section', 'card-panel qr-result');

    var head = el('div', 'qr-result-head');
    var title = el('div');
    title.appendChild(el('div', 'preview-label', 'Invoice'));
    title.appendChild(el('div', 'preview-name', inv.invoice_number));
    head.appendChild(title);
    head.appendChild(el('span', 'status-pill ' + inv.status, inv.status_label));
    card.appendChild(head);

    if (code.kind === 'invalid_invoice') {
      card.appendChild(el('div', 'qr-alert qr-alert-error', 'This QR code is not a well-formed invoice code, so only the invoice number was used to find the record.'));
      card.appendChild(problemList(code.problems));
    } else if (!inv.qr_is_current) {
      var changed = code.mismatched_fields.length ? ' Differs from the invoice: ' + code.mismatched_fields.join(', ') + '.' : '';
      card.appendChild(el('div', 'qr-alert qr-alert-warning', 'This invoice changed after the QR code was made. Trust the details on record, not the code.' + changed));
    }

    var columns = el('div', 'qr-columns');
    var left = el('div');
    left.appendChild(el('h4', 'qr-col-title', 'Read from the QR code'));
    left.appendChild(definitionList(qrFields(code.parsed)));
    var right = el('div');
    right.appendChild(el('h4', 'qr-col-title', 'On record'));
    right.appendChild(definitionList([
      ['Customer', inv.customer_name],
      ['Issued', niceDate(inv.issue_date)],
      ['Due', inv.due_date ? niceDate(inv.due_date) : ''],
      ['Distributor', inv.distributor],
      ['Items', String(inv.item_count)],
      ['Subtotal', money(inv.subtotal)],
      ['Discount', Number(inv.discount) ? money(inv.discount) : ''],
      ['GST', money(inv.tax)],
      ['Total', money(inv.total)]
    ]));
    columns.appendChild(left);
    columns.appendChild(right);
    card.appendChild(columns);

    if (inv.items.length) card.appendChild(itemsTable(inv));

    var open = el('a', 'btn-secondary', 'Open invoice');
    open.href = inv.url;
    var actions = el('div', 'form-actions');
    actions.appendChild(open);
    card.appendChild(actions);
    card.appendChild(rawText(code.text));
    return card;
  }

  function messageCard(label, level, text, code) {
    var card = el('section', 'card-panel qr-result');
    card.appendChild(el('div', 'preview-label', label));
    card.appendChild(el('div', 'qr-alert qr-alert-' + level, text));
    if (code.problems && code.problems.length) card.appendChild(problemList(code.problems));
    var known = qrFields(code.parsed);
    if (code.parsed && Object.keys(code.parsed).length) card.appendChild(definitionList(known));
    card.appendChild(rawText(code.text));
    return card;
  }

  function showCode(code) {
    if (code.kind === 'invoice') {
      var inv = code.invoice;
      if (inv.qr_is_current) {
        notify('success', 'Invoice ' + inv.invoice_number + ' found: ' + inv.customer_name + ', ' + money(inv.total) + '.');
      } else {
        notify('warning', 'Invoice ' + inv.invoice_number + ' found, but the QR code is out of date.');
      }
      return invoiceCard(code);
    }
    if (code.kind === 'invalid_invoice') {
      notify('error', 'Invalid invoice QR code: ' + (code.problems[0] || 'the data is malformed.'));
      return code.invoice
        ? invoiceCard(code)
        : messageCard('Invalid invoice QR code', 'error', 'This looks like an invoice QR code, but its data is malformed.', code);
    }
    if (code.kind === 'invoice_not_found') {
      var number = code.parsed && code.parsed.number ? code.parsed.number : 'this number';
      notify('warning', 'No invoice ' + number + ' is available to your account.');
      return messageCard('Invoice not found', 'warning', 'The QR code is valid, but no matching invoice is available to your account.', code);
    }
    notify('warning', 'QR code read, but it is not an invoice code.');
    return messageCard('Other QR code', 'info', 'This QR code does not contain an invoice. Its text is shown below.', code);
  }

  // ---- events ------------------------------------------------------------
  input.addEventListener('change', function () {
    results.textContent = '';
    inline('info', '');
    var file = input.files[0];
    if (!file) { previewWrap.hidden = true; return; }
    var problem = clientProblem(file);
    if (problem) { previewWrap.hidden = true; fail(problem); return; }
    preview.src = URL.createObjectURL(file);
    previewWrap.hidden = false;
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    results.textContent = '';
    inline('info', '');

    var file = input.files[0];
    var problem = clientProblem(file);
    if (problem) { fail(problem); return; }

    var body = new FormData();
    body.append('image', file);
    button.disabled = true;
    button.textContent = 'Reading\u2026';
    inline('info', 'Reading the QR code\u2026');

    fetch(root.dataset.endpoint, {
      method: 'POST',
      body: body,
      credentials: 'same-origin',
      headers: { 'X-CSRFToken': form.elements['csrfmiddlewaretoken'].value, 'Accept': 'application/json' }
    })
      .then(function (response) {
        return response.json().catch(function () { return {}; }).then(function (data) {
          return { ok: response.ok, status: response.status, data: data };
        });
      })
      .then(function (r) {
        if (!r.ok || !r.data.ok) {
          var fallback = r.status === 403 ? 'Your session has expired. Reload the page and try again.' : 'Something went wrong. Please try again.';
          fail(r.data.message || fallback);
          return;
        }
        var count = r.data.count;
        // the inline banner takes the colour of the worst outcome, like the toasts do
        var level = 'success';
        r.data.codes.forEach(function (code) {
          if (code.kind === 'invalid_invoice') level = 'error';
          else if (level !== 'error' && (code.kind !== 'invoice' || !code.invoice.qr_is_current)) level = 'warning';
        });
        inline(level, count === 1 ? 'Read 1 QR code.' : 'Read ' + count + ' QR codes.');
        if (r.data.skipped_empty) notify('warning', r.data.skipped_empty + ' empty QR code' + (r.data.skipped_empty === 1 ? ' was' : 's were') + ' ignored.');
        r.data.codes.forEach(function (code) { results.appendChild(showCode(code)); });
      })
      .catch(function () { fail('Could not reach the server. Check your connection and try again.'); })
      .then(function () { button.disabled = false; button.textContent = 'Read QR code'; });
  });
})();
