"""Parse the plain-text payload that billing.qr.invoice_qr_payload() produces.

    Invoice: INV-2026-0042
    Customer: Acme Traders
    Items: 3
    Total: INR 212.40
    Date: 2026-10-15

Anything scanned from a QR code is untrusted input, so parsing is strict and
reports *every* problem instead of guessing. No Django imports (easy to test).
"""
import re
from collections import namedtuple
from datetime import date
from decimal import Decimal, InvalidOperation

REQUIRED = ('Invoice', 'Customer', 'Items', 'Total', 'Date')

NUMBER_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_-]{0,19}$')
TOTAL_RE = re.compile(r'^INR\s+(\d{1,12}(?:\.\d{1,2})?)$')
MAX_CUSTOMER_LEN = 100
MAX_ITEMS = 100000

# is_invoice: the text claims to be an invoice QR (has an "Invoice:" line)
# fields:     {'number', 'customer', 'items', 'total', 'date'} with real types; only the valid ones
# problems:   human-readable reasons the payload is not a well-formed invoice QR
ParsedPayload = namedtuple('ParsedPayload', 'is_invoice fields problems')

_LINE_START = re.compile(r'^\s*Invoice\s*:', re.IGNORECASE | re.MULTILINE)


def parse_invoice_payload(text):
    text = (text or '').strip()
    if not _LINE_START.search(text):
        return ParsedPayload(False, {}, [])

    raw, problems = {}, []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        key, sep, value = line.partition(':')
        key = key.strip().title()
        if not sep:
            problems.append(f'Unexpected line: "{line[:40]}".')
        elif key not in REQUIRED:
            problems.append(f'Unknown field "{key[:30]}".')
        elif key in raw:
            problems.append(f'The "{key}" field appears more than once.')
        else:
            raw[key] = value.strip()

    fields = {}
    for key in REQUIRED:
        if key not in raw:
            problems.append(f'The "{key}" field is missing.')
        elif not raw[key]:
            problems.append(f'The "{key}" field is empty.')

    value = raw.get('Invoice')
    if value:
        if NUMBER_RE.match(value):
            fields['number'] = value
        else:
            problems.append('The invoice number is not in a valid format.')

    value = raw.get('Customer')
    if value:
        if len(value) <= MAX_CUSTOMER_LEN:
            fields['customer'] = value
        else:
            problems.append('The customer name is too long.')

    value = raw.get('Items')
    if value:
        if value.isdigit() and int(value) <= MAX_ITEMS:
            fields['items'] = int(value)
        else:
            problems.append('The item count must be a whole number.')

    value = raw.get('Total')
    if value:
        match = TOTAL_RE.match(value)
        if match:
            try:
                fields['total'] = Decimal(match.group(1)).quantize(Decimal('0.01'))
            except InvalidOperation:
                problems.append('The total is not a valid amount.')
        else:
            problems.append('The total must look like "INR 123.45".')

    value = raw.get('Date')
    if value:
        try:
            fields['date'] = date.fromisoformat(value)
        except ValueError:
            problems.append('The date must be a real date written YYYY-MM-DD.')

    return ParsedPayload(True, fields, problems)
