"""QR decoding: the decoder module on its own, then the upload endpoint."""
import io
from decimal import Decimal
from unittest import mock

import segno
from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, SimpleTestCase, TestCase
from django.urls import reverse
from PIL import Image

from accounts.models import UserProfile

from . import qr_decode
from .qr_parse import parse_invoice_payload
from .models import Invoice, InvoiceItem
from .qr import invoice_qr_payload, invoice_qr_png

PW = 'Some-Pass-123!'


def make_user(email, role=UserProfile.ROLE_DISTRIBUTOR):
    user = User.objects.create_user(username=email, email=email, password=PW)
    UserProfile.objects.create(user=user, role=role)
    return user


def make_invoice(owner, customer='Acme', amount='100'):
    invoice = Invoice.objects.create(distributor=owner, customer_name=customer)
    InvoiceItem.objects.create(invoice=invoice, description='Widget', quantity=Decimal('1'),
                               unit_price=Decimal(amount), gst_percent=Decimal('18'))
    return invoice


def qr_png(text, scale=10, border=3):
    buffer = io.BytesIO()
    segno.make(text, error='m', encoding='utf-8').save(buffer, kind='png', scale=scale, border=border)
    return buffer.getvalue()


def reencode(png_bytes, fmt, **kwargs):
    buffer = io.BytesIO()
    Image.open(io.BytesIO(png_bytes)).convert('RGB').save(buffer, fmt, **kwargs)
    return buffer.getvalue()


def blank_png(size=(300, 300)):
    buffer = io.BytesIO()
    Image.new('RGB', size, 'white').save(buffer, 'PNG')
    return buffer.getvalue()


def upload(data, name='qr.png', content_type='image/png', field='image'):
    return {field: SimpleUploadedFile(name, data, content_type=content_type)}


class DecoderTests(SimpleTestCase):
    """qr_decode.decode_qr, independent of Django views."""

    TEXT = 'Invoice: INV-2026-0042\nCustomer: Acme\nItems: 3\nTotal: INR 212.40\nDate: 2026-10-15'

    def test_reads_a_plain_png(self):
        self.assertEqual(qr_decode.decode_qr(qr_png(self.TEXT)), [self.TEXT])

    def test_reads_unicode_text(self):
        text = 'Invoice: INV-1\nCustomer: Zoë & Sons \u20b9'
        self.assertEqual(qr_decode.decode_qr(qr_png(text)), [text])

    def test_reads_a_code_with_no_quiet_zone(self):
        self.assertEqual(qr_decode.decode_qr(qr_png(self.TEXT, border=0)), [self.TEXT])

    def test_reads_other_formats_and_compression(self):
        png = qr_png(self.TEXT)
        for fmt, kwargs in (('JPEG', {'quality': 40}), ('WEBP', {'quality': 60}), ('GIF', {}), ('BMP', {})):
            self.assertEqual(qr_decode.decode_qr(reencode(png, fmt, **kwargs)), [self.TEXT], fmt)

    def test_reads_a_small_image(self):
        img = Image.open(io.BytesIO(qr_png(self.TEXT, scale=10))).convert('RGB')
        img = img.resize((img.width // 3, img.height // 3), Image.LANCZOS)
        buffer = io.BytesIO(); img.save(buffer, 'PNG')
        self.assertEqual(qr_decode.decode_qr(buffer.getvalue()), [self.TEXT])

    def test_reads_a_rotated_image_and_transparent_background(self):
        img = Image.open(io.BytesIO(qr_png(self.TEXT))).convert('RGBA')
        buffer = io.BytesIO(); img.rotate(90, expand=True).save(buffer, 'PNG')
        self.assertEqual(qr_decode.decode_qr(buffer.getvalue()), [self.TEXT])

    def test_reads_every_code_in_an_image(self):
        a = Image.open(io.BytesIO(qr_png('Invoice: INV-A'))).convert('RGB')
        b = Image.open(io.BytesIO(qr_png('https://example.com/b'))).convert('RGB')
        sheet = Image.new('RGB', (a.width + b.width, max(a.height, b.height)), 'white')
        sheet.paste(a, (0, 0)); sheet.paste(b, (a.width, 0))
        buffer = io.BytesIO(); sheet.save(buffer, 'PNG')
        self.assertEqual(sorted(qr_decode.decode_qr(buffer.getvalue())), ['Invoice: INV-A', 'https://example.com/b'])

    def test_image_without_a_code_returns_nothing(self):
        self.assertEqual(qr_decode.decode_qr(blank_png()), [])

    def test_detailed_result_distinguishes_the_outcomes(self):
        found = qr_decode.decode_qr_detailed(qr_png(self.TEXT))
        self.assertEqual((found.texts, found.detected, found.blank), ([self.TEXT], True, 0))
        nothing = qr_decode.decode_qr_detailed(blank_png())
        self.assertEqual((nothing.texts, nothing.detected, nothing.blank), ([], False, 0))

    def test_a_whitespace_only_code_is_reported_as_blank_not_as_data(self):
        result = qr_decode.decode_qr_detailed(qr_png(' '))
        self.assertEqual(result.texts, [])
        self.assertEqual(result.blank, 1)

    def assertRejected(self, data, code):
        with self.assertRaises(qr_decode.QRImageError) as ctx:
            qr_decode.decode_qr(data)
        self.assertEqual(ctx.exception.code, code)

    def test_rejects_bad_uploads(self):
        self.assertRejected(b'', 'empty_file')
        self.assertRejected(b'just some text', 'not_an_image')
        self.assertRejected(b'<svg xmlns="http://www.w3.org/2000/svg"/>', 'not_an_image')
        self.assertRejected(qr_png(self.TEXT)[:60], 'not_an_image')                 # truncated file
        tiff = io.BytesIO(); Image.new('L', (40, 40), 255).save(tiff, 'TIFF')
        self.assertRejected(tiff.getvalue(), 'unsupported_format')

    def test_rejects_oversized_files_and_pixel_bombs(self):
        with mock.patch.object(qr_decode, 'MAX_UPLOAD_BYTES', 100):
            self.assertRejected(qr_png(self.TEXT), 'too_large')
        self.assertRejected(blank_png((6000, 6000)), 'too_large')                   # 36 MP, tiny on disk


class DecodeEndpointTests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.other = make_user('d2@x.com')
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.url = reverse('qr_decode')
        self.client.force_login(self.dist)

    def post(self, data, **kw):
        return self.client.post(self.url, upload(data, **kw))

    # --- access -----------------------------------------------------------
    def test_anonymous_gets_401_json_not_a_redirect(self):
        resp = Client().post(self.url, upload(blank_png()))
        self.assertEqual(resp.status_code, 401)
        self.assertEqual(resp.json()['error'], 'not_authenticated')

    def test_only_post_is_allowed(self):
        self.assertEqual(self.client.get(self.url).status_code, 405)

    def test_csrf_is_enforced(self):
        strict = Client(enforce_csrf_checks=True)
        strict.force_login(self.dist)
        self.assertEqual(strict.post(self.url, upload(blank_png())).status_code, 403)

    # --- success ----------------------------------------------------------
    def test_decodes_an_invoice_qr_and_finds_the_invoice(self):
        invoice = make_invoice(self.dist)
        resp = self.post(invoice_qr_png(invoice))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'application/json')
        body = resp.json()
        self.assertTrue(body['ok'])
        self.assertEqual(body['count'], 1)
        code = body['codes'][0]
        self.assertEqual(code['text'], invoice_qr_payload(invoice))
        self.assertTrue(code['is_invoice_qr'])
        self.assertEqual(code['invoice']['id'], invoice.pk)
        self.assertEqual(code['invoice']['invoice_number'], invoice.invoice_number)
        self.assertEqual(code['invoice']['total'], f'{invoice.total:.2f}')
        self.assertEqual(code['invoice']['url'], reverse('invoice_detail', args=[invoice.pk]))
        self.assertTrue(code['invoice']['qr_is_current'])

    def test_a_phone_style_jpeg_still_decodes(self):
        invoice = make_invoice(self.dist)
        resp = self.post(reencode(invoice_qr_png(invoice), 'JPEG', quality=50), name='photo.jpg', content_type='image/jpeg')
        self.assertEqual(resp.json()['codes'][0]['invoice']['id'], invoice.pk)

    def test_a_stale_qr_is_flagged(self):
        invoice = make_invoice(self.dist, customer='Old Name')
        png = invoice_qr_png(invoice)
        invoice.customer_name = 'New Name'
        invoice.save()
        code = self.post(png).json()['codes'][0]
        self.assertEqual(code['invoice']['id'], invoice.pk)
        self.assertFalse(code['invoice']['qr_is_current'])
        self.assertEqual(code['invoice']['customer_name'], 'New Name')       # from the database, not the QR

    def test_other_qr_codes_are_returned_as_plain_text(self):
        code = self.post(qr_png('https://example.com/hello')).json()['codes'][0]
        self.assertEqual(code['text'], 'https://example.com/hello')
        self.assertFalse(code['is_invoice_qr'])
        self.assertIsNone(code['invoice'])

    # --- privacy ----------------------------------------------------------
    def test_a_distributor_cannot_look_up_someone_elses_invoice(self):
        theirs = make_invoice(self.other, customer='Secret Customer')
        resp = self.post(invoice_qr_png(theirs))
        self.assertEqual(resp.status_code, 200)
        code = resp.json()['codes'][0]
        self.assertTrue(code['is_invoice_qr'])
        self.assertIsNone(code['invoice'])

    def test_admin_can_look_up_any_invoice(self):
        theirs = make_invoice(self.other)
        self.client.force_login(self.admin)
        self.assertEqual(self.post(invoice_qr_png(theirs)).json()['codes'][0]['invoice']['id'], theirs.pk)

    def test_forged_invoice_numbers_find_nothing(self):
        for forged in ('Invoice: INV-9999-9999', 'Invoice: ' + 'X' * 40, "Invoice: ' OR 1=1 --"):
            code = self.post(qr_png(forged)).json()['codes'][0]
            self.assertIsNone(code['invoice'], forged)

    # --- bad input --------------------------------------------------------
    def assertError(self, resp, status, error):
        self.assertEqual(resp.status_code, status)
        body = resp.json()
        self.assertFalse(body['ok'])
        self.assertEqual(body['error'], error)
        self.assertTrue(body['message'])

    def test_missing_file(self):
        self.assertError(self.client.post(self.url, {}), 400, 'no_file')
        self.assertError(self.client.post(self.url, upload(blank_png(), field='file')), 400, 'no_file')

    def test_empty_file(self):
        self.assertError(self.post(b''), 400, 'empty_file')

    def test_not_an_image_even_with_an_image_extension(self):
        self.assertError(self.post(b'MZ\x90\x00 definitely an exe', name='evil.png'), 400, 'not_an_image')

    def test_unsupported_image_type(self):
        tiff = io.BytesIO(); Image.new('L', (40, 40), 255).save(tiff, 'TIFF')
        self.assertError(self.post(tiff.getvalue(), name='x.tiff', content_type='image/tiff'), 415, 'unsupported_format')

    def test_oversized_upload(self):
        with mock.patch('billing.views.MAX_UPLOAD_BYTES', 100):
            self.assertError(self.post(qr_png('hello')), 413, 'too_large')

    def test_pixel_bomb(self):
        self.assertError(self.post(blank_png((6000, 6000))), 413, 'too_large')

    def test_image_with_no_qr_code(self):
        self.assertError(self.post(blank_png()), 422, 'no_qr_found')

    def test_blank_qr_code(self):
        resp = self.post(qr_png(' '))
        self.assertError(resp, 422, 'empty_qr')
        self.assertIn('empty', resp.json()['message'])

    def test_qr_seen_but_unreadable(self):
        seen = qr_decode.QRResult([], True, 0)
        with mock.patch('billing.views.decode_qr_detailed', return_value=seen):
            resp = self.post(blank_png())
        self.assertError(resp, 422, 'unreadable_qr')
        self.assertIn('could not be read', resp.json()['message'])

    def test_empty_codes_next_to_good_ones_are_skipped_and_counted(self):
        invoice = make_invoice(self.dist)
        mixed = qr_decode.QRResult([invoice_qr_payload(invoice)], True, 2)
        with mock.patch('billing.views.decode_qr_detailed', return_value=mixed):
            body = self.post(blank_png()).json()
        self.assertEqual((body['count'], body['skipped_empty']), (1, 2))

    # --- parsed output --------------------------------------------------------
    def test_invoice_qr_is_parsed_and_enriched(self):
        invoice = make_invoice(self.dist, customer='Acme Traders', amount='100')
        InvoiceItem.objects.create(invoice=invoice, description='Gadget', quantity=Decimal('2.50'),
                                   unit_price=Decimal('10'), discount_percent=Decimal('10'), gst_percent=Decimal('5'))
        code = self.post(invoice_qr_png(invoice)).json()['codes'][0]
        self.assertEqual(code['kind'], 'invoice')
        self.assertEqual(code['problems'], [])
        self.assertEqual(code['parsed'], {'number': invoice.invoice_number, 'customer': 'Acme Traders', 'items': 2,
                                          'total': f'{invoice.total:.2f}', 'date': invoice.issue_date.isoformat()})
        inv = code['invoice']
        self.assertEqual(inv['status'], 'unpaid')
        self.assertEqual(inv['status_label'], 'Unpaid')
        self.assertEqual(inv['item_count'], 2)
        self.assertEqual([i['description'] for i in inv['items']], ['Widget', 'Gadget'])
        self.assertEqual(inv['items'][1]['quantity'], '2.5')              # no trailing zeros
        self.assertEqual((inv['subtotal'], inv['tax'], inv['total']),
                         (f'{invoice.subtotal:.2f}', f'{invoice.tax_amount:.2f}', f'{invoice.total:.2f}'))
        self.assertFalse(inv['items_truncated'])
        self.assertEqual(code['mismatched_fields'], [])
        self.assertNotIn('distributor', inv)                                # only admins get that

    def test_admin_also_sees_which_distributor_owns_the_invoice(self):
        invoice = make_invoice(self.other)
        self.client.force_login(self.admin)
        self.assertEqual(self.post(invoice_qr_png(invoice)).json()['codes'][0]['invoice']['distributor'], 'd2@x.com')

    def test_mismatched_fields_are_named(self):
        invoice = make_invoice(self.dist, customer='Old Name', amount='100')
        png = invoice_qr_png(invoice)
        invoice.customer_name = 'New Name'
        invoice.save()
        InvoiceItem.objects.create(invoice=invoice, description='Extra', quantity=Decimal('1'), unit_price=Decimal('50'))
        code = self.post(png).json()['codes'][0]
        self.assertEqual(code['kind'], 'invoice')
        self.assertEqual(sorted(code['mismatched_fields']), ['Customer', 'Items', 'Total'])
        self.assertFalse(code['invoice']['qr_is_current'])

    def test_a_valid_but_unknown_invoice(self):
        code = self.post(qr_png('Invoice: INV-9999-9999\nCustomer: Ghost\nItems: 1\nTotal: INR 5.00\nDate: 2026-01-01')).json()['codes'][0]
        self.assertEqual(code['kind'], 'invoice_not_found')
        self.assertTrue(code['is_invoice_qr'])
        self.assertIsNone(code['invoice'])
        self.assertEqual(code['parsed']['customer'], 'Ghost')

    def test_a_malformed_invoice_qr_lists_every_problem(self):
        code = self.post(qr_png('Invoice: INV-1\nTotal: USD 5\nDate: 2026-02-30')).json()['codes'][0]
        self.assertEqual(code['kind'], 'invalid_invoice')
        self.assertTrue(code['is_invoice_qr'])
        problems = ' '.join(code['problems'])
        for needle in ('"Customer" field is missing', '"Items" field is missing', 'INR 123.45', 'real date'):
            self.assertIn(needle, problems)
        self.assertEqual(code['parsed'], {'number': 'INV-1'})

    def test_a_malformed_qr_with_a_real_invoice_number_still_finds_the_invoice_but_stays_invalid(self):
        invoice = make_invoice(self.dist)
        code = self.post(qr_png(f'Invoice: {invoice.invoice_number}\nTotal: lots')).json()['codes'][0]
        self.assertEqual(code['kind'], 'invalid_invoice')
        self.assertEqual(code['invoice']['id'], invoice.pk)
        self.assertFalse(code['invoice']['qr_is_current'])

    def test_a_bare_invoice_label_is_invalid_not_a_crash(self):
        code = self.post(qr_png('Invoice:')).json()['codes'][0]
        self.assertEqual(code['kind'], 'invalid_invoice')
        self.assertIsNone(code['invoice'])

    # --- scan page --------------------------------------------------------
    def test_scan_page(self):
        resp = self.client.get(reverse('qr_scan'))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, f'data-endpoint="{self.url}"')
        self.assertContains(resp, 'csrfmiddlewaretoken')
        self.assertContains(resp, 'qr_scan.js')
        self.assertContains(resp, 'id="qr-alert"')
        self.assertContains(resp, 'id="toast-stack"')        # where success/error toasts appear
        self.assertContains(resp, 'toast.js')
        self.assertEqual(Client().get(reverse('qr_scan')).status_code, 302)

    def test_invoice_list_links_to_the_scan_page(self):
        self.assertContains(self.client.get(reverse('invoice_list')), reverse('qr_scan'))


class PayloadParserTests(SimpleTestCase):
    GOOD = 'Invoice: INV-2026-0042\nCustomer: Acme: Traders & Co\u2026\nItems: 3\nTotal: INR 212.40\nDate: 2026-10-15'

    def test_parses_a_valid_payload_into_real_types(self):
        from datetime import date
        parsed = parse_invoice_payload(self.GOOD)
        self.assertTrue(parsed.is_invoice)
        self.assertEqual(parsed.problems, [])
        self.assertEqual(parsed.fields, {'number': 'INV-2026-0042', 'customer': 'Acme: Traders & Co\u2026', 'items': 3,
                                         'total': Decimal('212.40'), 'date': date(2026, 10, 15)})

    def test_round_trips_what_the_app_generates(self):
        from datetime import date
        inv = Invoice(invoice_number='INV-2026-0001', customer_name='Zo\u00eb', issue_date=date(2026, 1, 2))
        with mock.patch.object(Invoice, 'item_count', 2, create=True), mock.patch.object(Invoice, 'total', Decimal('5'), create=True):
            parsed = parse_invoice_payload(invoice_qr_payload(inv))
        self.assertEqual(parsed.problems, [])
        self.assertEqual(parsed.fields['customer'], 'Zo\u00eb')

    def test_other_text_is_not_an_invoice(self):
        for text in ('', '   ', None, 'https://example.com', 'Hello', 'Customer: x\nTotal: INR 5'):
            parsed = parse_invoice_payload(text)
            self.assertFalse(parsed.is_invoice, text)
            self.assertEqual(parsed.problems, [], text)

    def test_every_kind_of_malformed_payload_is_reported(self):
        base = self.GOOD
        cases = {
            'missing fields': ('Invoice: INV-1', 'is missing'),
            'wrong currency': (base.replace('INR 212.40', 'USD 212.40'), 'INR 123.45'),
            'three decimals': (base.replace('212.40', '212.405'), 'INR 123.45'),
            'negative items': (base.replace('Items: 3', 'Items: -3'), 'whole number'),
            'impossible date': (base.replace('2026-10-15', '2026-02-30'), 'real date'),
            'wrong date format': (base.replace('2026-10-15', '15/10/2026'), 'real date'),
            'duplicate field': (base + '\nTotal: INR 1.00', 'more than once'),
            'unknown field': (base + '\nExtra: 1', 'Unknown field'),
            'stray line': (base + '\nnoise', 'Unexpected line'),
            'bad number': (base.replace('INV-2026-0042', 'bad number!'), 'invoice number'),
            'empty value': (base.replace('Items: 3', 'Items:'), 'is empty'),
            'huge name': (base.replace('Acme: Traders & Co\u2026', 'x' * 101), 'too long'),
        }
        for label, (text, needle) in cases.items():
            parsed = parse_invoice_payload(text)
            self.assertTrue(parsed.is_invoice, label)
            self.assertTrue(any(needle in p for p in parsed.problems), (label, parsed.problems))

    def test_field_names_are_case_insensitive(self):
        self.assertEqual(parse_invoice_payload(self.GOOD.lower().replace('inr', 'INR')).problems, [])
