from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse, JsonResponse
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from accounts.models import UserProfile
from products.models import Product

from .forms import InvoiceForm, InvoiceItemFormSet
from .models import Invoice
from .pdf import render_invoice_pdf
from .qr import invoice_qr_payload, invoice_qr_png
from .qr_decode import MAX_UPLOAD_BYTES, QRImageError, decode_qr_detailed
from .qr_parse import parse_invoice_payload


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


@login_required(login_url='distributor_login')
def invoice_list_view(request):
    """Admins see every invoice; distributors see only their own."""
    invoices = Invoice.objects.select_related('distributor').prefetch_related('items')

    if not _is_admin(request.user):
        invoices = invoices.filter(distributor=request.user)

    status = request.GET.get('status')
    if status in dict(Invoice.STATUS_CHOICES):
        invoices = invoices.filter(status=status)

    paginator = Paginator(invoices, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'billing/invoice_list.html', {
        'page_obj': page_obj,
        'active_status': status or '',
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def invoice_create_view(request):
    """Task: create invoices. Restricted to distributors — they raise
    their own bills; admins get an oversight view via invoice_list_view.
    """
    if _is_admin(request.user):
        messages.info(request, 'Invoices are raised by distributor accounts.')
        return redirect('invoice_list')

    blank_invoice = Invoice(distributor=request.user)
    form = InvoiceForm(request.POST or None, instance=blank_invoice, distributor=request.user)
    formset = InvoiceItemFormSet(
        request.POST or None, instance=blank_invoice,
        form_kwargs={'distributor': request.user},
    )

    if request.method == 'POST' and form.is_valid() and formset.is_valid():
        # One transaction: the invoice and all its items are saved together
        # or not at all (no half-saved invoice if an item insert fails).
        with transaction.atomic():
            invoice = form.save(commit=False)
            invoice.distributor = request.user
            invoice.save()
            formset.instance = invoice
            formset.save()
        count = invoice.items.count()
        messages.success(
            request,
            f'Invoice {invoice.invoice_number} created successfully with '
            f'{count} item{"s" if count != 1 else ""}.',
        )
        return redirect('invoice_detail', pk=invoice.pk)

    return render(request, 'billing/invoice_form.html', {
        'form': form,
        'formset': formset,
        'has_customers': form.fields['customer'].queryset.exists(),
        'has_products': Product.objects.filter(distributor=request.user).exists(),
    })


def _invoice_for_user(request, pk):
    """Fetch an invoice the signed-in user may see: admins see all,
    distributors only their own (anyone else gets a 404, not a 403, so
    invoice ids can't be probed)."""
    qs = Invoice.objects.select_related('customer', 'distributor__profile').prefetch_related('items')
    if not _is_admin(request.user):
        qs = qs.filter(distributor=request.user)
    return get_object_or_404(qs, pk=pk)


@login_required(login_url='distributor_login')
def invoice_detail_view(request, pk):
    invoice = _invoice_for_user(request, pk)
    return render(request, 'billing/invoice_detail.html', {
        'invoice': invoice,
        'is_admin': _is_admin(request.user),
        'qr_payload': invoice_qr_payload(invoice),
    })


@login_required(login_url='distributor_login')
def invoice_pdf_view(request, pk):
    """Branded PDF of one invoice. Opens in the browser by default;
    add ?download=1 to force a file download."""
    invoice = _invoice_for_user(request, pk)
    pdf = render_invoice_pdf(invoice)

    disposition = 'attachment' if request.GET.get('download') else 'inline'
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'{disposition}; filename="{invoice.invoice_number}.pdf"'
    return response


@login_required(login_url='distributor_login')
def invoice_qr_view(request, pk):
    """The invoice's QR code as a PNG (same access rules as the invoice).
    Add ?download=1 to save it as a file."""
    invoice = _invoice_for_user(request, pk)
    response = HttpResponse(invoice_qr_png(invoice), content_type='image/png')
    disposition = 'attachment' if request.GET.get('download') else 'inline'
    response['Content-Disposition'] = f'{disposition}; filename="{invoice.invoice_number}-qr.png"'
    return response


# ---------------------------------------------------------------------------
# QR decoding
# ---------------------------------------------------------------------------

_ERROR_STATUS = {'too_large': 413, 'unsupported_format': 415}
MAX_INVOICE_LINES_SHOWN = 50


def _json_error(status, code, message):
    return JsonResponse({'ok': False, 'error': code, 'message': message}, status=status)


def api_login_required(view):
    """Like login_required, but answers API clients with 401 JSON instead of a redirect."""
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return _json_error(401, 'not_authenticated', 'Sign in to decode QR codes.')
        return view(request, *args, **kwargs)
    return wrapper


def _serialise_parsed(fields):
    """JSON-friendly copy of the parsed QR fields (only those that were valid)."""
    out = {}
    for key, value in fields.items():
        out[key] = value.isoformat() if key == 'date' else (f'{value:.2f}' if key == 'total' else value)
    return out


def _plain_quantity(value):
    return format(value.normalize(), 'f')


def _invoice_summary(invoice, text, parsed_fields, is_admin):
    """The invoice as it is in the database, plus how the QR compares to it."""
    expected = parse_invoice_payload(invoice_qr_payload(invoice)).fields
    labels = {'customer': 'Customer', 'items': 'Items', 'total': 'Total', 'date': 'Date'}
    mismatched = [labels[key] for key in labels if key in parsed_fields and parsed_fields[key] != expected.get(key)]

    items = sorted(invoice.items.all(), key=lambda i: i.pk)       # lines in the order they were entered
    summary = {
        'id': invoice.pk,
        'invoice_number': invoice.invoice_number,
        'customer_name': invoice.customer_name,
        'status': invoice.status,
        'status_label': invoice.get_status_display(),
        'issue_date': invoice.issue_date.isoformat(),
        'due_date': invoice.due_date.isoformat() if invoice.due_date else None,
        'item_count': len(items),
        'subtotal': f'{invoice.subtotal:.2f}',
        'discount': f'{invoice.discount_total:.2f}',
        'tax': f'{invoice.tax_amount:.2f}',
        'total': f'{invoice.total:.2f}',
        'items': [{'description': i.description, 'quantity': _plain_quantity(i.quantity),
                   'unit_price': f'{i.unit_price:.2f}', 'line_total': f'{i.line_total:.2f}'}
                  for i in items[:MAX_INVOICE_LINES_SHOWN]],
        'items_truncated': len(items) > MAX_INVOICE_LINES_SHOWN,
        'url': reverse('invoice_detail', args=[invoice.pk]),
        # False when the invoice was edited after this QR code was printed.
        'qr_is_current': text == invoice_qr_payload(invoice),
    }
    if is_admin:
        summary['distributor'] = invoice.distributor.get_full_name() or invoice.distributor.username
    return summary, mismatched


def _describe_code(user, text):
    """Parse one decoded QR and say what it is.

    kind: 'invoice'            well-formed invoice QR, invoice found
          'invoice_not_found'  well-formed, but no such invoice is available to this user
          'invalid_invoice'    claims to be an invoice QR but is malformed (see `problems`)
          'other'              some other QR code (a URL, plain text, ...)

    The invoice is always read from the database, never trusted from the QR,
    and only among invoices this user may see (another distributor's invoice
    is reported exactly like a missing one).
    """
    parsed = parse_invoice_payload(text)
    result = {'text': text, 'kind': 'other', 'is_invoice_qr': parsed.is_invoice,
              'parsed': _serialise_parsed(parsed.fields) if parsed.is_invoice else None,
              'problems': parsed.problems, 'invoice': None, 'mismatched_fields': []}
    if not parsed.is_invoice:
        return result

    result['kind'] = 'invalid_invoice' if parsed.problems else 'invoice_not_found'
    number = parsed.fields.get('number')
    if not number:
        return result

    is_admin = _is_admin(user)
    invoices = Invoice.objects.select_related('distributor').prefetch_related('items')
    if not is_admin:
        invoices = invoices.filter(distributor=user)
    invoice = invoices.filter(invoice_number=number).first()
    if invoice is not None:
        result['invoice'], result['mismatched_fields'] = _invoice_summary(invoice, text, parsed.fields, is_admin)
        if not parsed.problems:
            result['kind'] = 'invoice'
    return result


@api_login_required
@require_POST
def qr_decode_view(request):
    """POST an image (multipart field "image"); get back every QR code in it, parsed.

    200 {ok, count, skipped_empty, codes: [{text, kind, parsed, problems, invoice, mismatched_fields}]}
    400 no file / empty file / not an image    413 too big    415 unsupported type
    422 the image is fine but holds no usable QR code:
        no_qr_found (none seen), unreadable_qr (seen but blurry/damaged), empty_qr (blank content)
    """
    upload = request.FILES.get('image')
    if upload is None:
        return _json_error(400, 'no_file', 'Attach an image in the "image" field.')
    if upload.size > MAX_UPLOAD_BYTES:
        return _json_error(413, 'too_large', f'The image is larger than {MAX_UPLOAD_BYTES // (1024 * 1024)} MB.')

    try:
        result = decode_qr_detailed(upload.read(MAX_UPLOAD_BYTES + 1))
    except QRImageError as exc:
        return _json_error(_ERROR_STATUS.get(exc.code, 400), exc.code, exc.message)

    if not result.texts:
        if result.blank:
            return _json_error(422, 'empty_qr', 'The QR code in this image is empty: it contains no data.')
        if result.detected:
            return _json_error(422, 'unreadable_qr',
                               'A QR code was found but could not be read. It may be blurry, damaged or too small.')
        return _json_error(422, 'no_qr_found',
                           'No QR code was found. Try a sharper, well-lit image with the whole code in view.')

    codes = [_describe_code(request.user, text) for text in result.texts]
    return JsonResponse({'ok': True, 'count': len(codes), 'skipped_empty': result.blank, 'codes': codes})


@login_required(login_url='distributor_login')
def qr_scan_view(request):
    """Small upload page that calls the decode endpoint."""
    return render(request, 'billing/qr_scan.html', {'max_mb': MAX_UPLOAD_BYTES // (1024 * 1024)})
