import re
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponse, JsonResponse
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from accounts.models import UserProfile
from products.models import Product

from .forms import InvoiceForm, InvoiceItemFormSet
from .models import Invoice
from .pdf import render_invoice_pdf
from .qr import invoice_qr_payload, invoice_qr_png
from .qr_decode import MAX_UPLOAD_BYTES, QRImageError, decode_qr


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


@login_required(login_url='distributor_login')
def invoice_list_view(request):
    """Admins see every invoice; distributors see only their own."""
    invoices = Invoice.objects.select_related('distributor').prefetch_related('items')

    if not _is_admin(request.user):
        invoices = invoices.filter(distributor=request.user)

    status = request.GET.get('status')
    if status in dict(Invoice.STATUS_CHOICES):
        invoices = invoices.filter(status=status)

    paginator = Paginator(invoices, 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'billing/invoice_list.html', {
        'page_obj': page_obj,
        'active_status': status or '',
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def invoice_create_view(request):
    """Task: create invoices. Restricted to distributors — they raise
    their own bills; admins get an oversight view via invoice_list_view.
    """
    if _is_admin(request.user):
        messages.info(request, 'Invoices are raised by distributor accounts.')
        return redirect('invoice_list')

    blank_invoice = Invoice(distributor=request.user)
    form = InvoiceForm(request.POST or None, instance=blank_invoice, distributor=request.user)
    formset = InvoiceItemFormSet(
        request.POST or None, instance=blank_invoice,
        form_kwargs={'distributor': request.user},
    )

    if request.method == 'POST' and form.is_valid() and formset.is_valid():
        # One transaction: the invoice and all its items are saved together
        # or not at all (no half-saved invoice if an item insert fails).
        with transaction.atomic():
            invoice = form.save(commit=False)
            invoice.distributor = request.user
            invoice.save()
            formset.instance = invoice
            formset.save()
        count = invoice.items.count()
        messages.success(
            request,
            f'Invoice {invoice.invoice_number} created successfully with '
            f'{count} item{"s" if count != 1 else ""}.',
        )
        return redirect('invoice_detail', pk=invoice.pk)

    return render(request, 'billing/invoice_form.html', {
        'form': form,
        'formset': formset,
        'has_customers': form.fields['customer'].queryset.exists(),
        'has_products': Product.objects.filter(distributor=request.user).exists(),
    })


def _invoice_for_user(request, pk):
    """Fetch an invoice the signed-in user may see: admins see all,
    distributors only their own (anyone else gets a 404, not a 403, so
    invoice ids can't be probed)."""
    qs = Invoice.objects.select_related('customer', 'distributor__profile').prefetch_related('items')
    if not _is_admin(request.user):
        qs = qs.filter(distributor=request.user)
    return get_object_or_404(qs, pk=pk)


@login_required(login_url='distributor_login')
def invoice_detail_view(request, pk):
    invoice = _invoice_for_user(request, pk)
    return render(request, 'billing/invoice_detail.html', {
        'invoice': invoice,
        'is_admin': _is_admin(request.user),
        'qr_payload': invoice_qr_payload(invoice),
    })


@login_required(login_url='distributor_login')
def invoice_pdf_view(request, pk):
    """Branded PDF of one invoice. Opens in the browser by default;
    add ?download=1 to force a file download."""
    invoice = _invoice_for_user(request, pk)
    pdf = render_invoice_pdf(invoice)

    disposition = 'attachment' if request.GET.get('download') else 'inline'
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'{disposition}; filename="{invoice.invoice_number}.pdf"'
    return response


@login_required(login_url='distributor_login')
def invoice_qr_view(request, pk):
    """The invoice's QR code as a PNG (same access rules as the invoice).
    Add ?download=1 to save it as a file."""
    invoice = _invoice_for_user(request, pk)
    response = HttpResponse(invoice_qr_png(invoice), content_type='image/png')
    disposition = 'attachment' if request.GET.get('download') else 'inline'
    response['Content-Disposition'] = f'{disposition}; filename="{invoice.invoice_number}-qr.png"'
    return response


# ---------------------------------------------------------------------------
# QR decoding
# ---------------------------------------------------------------------------

_INVOICE_LINE = re.compile(r'^Invoice:\s*(\S{1,20})\s*$', re.MULTILINE)
_ERROR_STATUS = {'too_large': 413, 'unsupported_format': 415}


def _json_error(status, code, message):
    return JsonResponse({'ok': False, 'error': code, 'message': message}, status=status)


def api_login_required(view):
    """Like login_required, but answers API clients with 401 JSON instead of a redirect."""
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return _json_error(401, 'not_authenticated', 'Sign in to decode QR codes.')
        return view(request, *args, **kwargs)
    return wrapper


def _describe_code(user, text):
    """What a decoded QR means. Looks the invoice up from the database, never
    trusting the QR's own claims, and only among invoices this user may see
    (an invoice from another distributor is reported as 'not found')."""
    result = {'text': text, 'is_invoice_qr': False, 'invoice': None}
    match = _INVOICE_LINE.search(text)
    if not match:
        return result
    result['is_invoice_qr'] = True

    invoices = Invoice.objects.select_related('distributor').prefetch_related('items')
    if not _is_admin(user):
        invoices = invoices.filter(distributor=user)
    invoice = invoices.filter(invoice_number=match.group(1)).first()
    if invoice is not None:
        result['invoice'] = {
            'id': invoice.pk,
            'invoice_number': invoice.invoice_number,
            'customer_name': invoice.customer_name,
            'status': invoice.status,
            'issue_date': invoice.issue_date.isoformat(),
            'total': f'{invoice.total:.2f}',
            'url': reverse('invoice_detail', args=[invoice.pk]),
            # False when the invoice was edited after this QR code was printed.
            'qr_is_current': text == invoice_qr_payload(invoice),
        }
    return result


@api_login_required
@require_POST
def qr_decode_view(request):
    """POST an image (multipart field "image"); get back the QR code text(s).

    200 {ok, count, codes: [{text, is_invoice_qr, invoice}]}
    400 no file / not an image    413 too big    415 unsupported type
    422 image is fine but contains no readable QR code
    """
    upload = request.FILES.get('image')
    if upload is None:
        return _json_error(400, 'no_file', 'Attach an image in the "image" field.')
    if upload.size > MAX_UPLOAD_BYTES:
        return _json_error(413, 'too_large', f'The image is larger than {MAX_UPLOAD_BYTES // (1024 * 1024)} MB.')

    try:
        texts = decode_qr(upload.read(MAX_UPLOAD_BYTES + 1))
    except QRImageError as exc:
        return _json_error(_ERROR_STATUS.get(exc.code, 400), exc.code, exc.message)

    if not texts:
        return _json_error(422, 'no_qr_found',
                           'No QR code was found. Try a sharper, well-lit image with the whole code in view.')

    codes = [_describe_code(request.user, text) for text in texts]
    return JsonResponse({'ok': True, 'count': len(codes), 'codes': codes})


@login_required(login_url='distributor_login')
def qr_scan_view(request):
    """Small upload page that calls the decode endpoint."""
    return render(request, 'billing/qr_scan.html', {'max_mb': MAX_UPLOAD_BYTES // (1024 * 1024)})
