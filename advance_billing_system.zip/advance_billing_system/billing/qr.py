"""QR codes for invoices (segno: pure Python, no dependencies)."""
import base64
from io import BytesIO

import segno

MAX_NAME_LEN = 40   # keep the payload short so the code stays small and easy to scan


def invoice_qr_payload(invoice):
    """Plain-text summary encoded in the QR. Plain text (not a URL) because
    invoice pages need a login, and any phone scanner can show text as-is.
    Always read from the database via the model, so it can't go stale."""
    name = invoice.customer_name.strip()
    if len(name) > MAX_NAME_LEN:
        name = name[:MAX_NAME_LEN - 1].rstrip() + '…'
    return '\n'.join([
        f'Invoice: {invoice.invoice_number}',
        f'Customer: {name}',
        f'Items: {invoice.item_count}',
        f'Total: INR {invoice.total:.2f}',
        f'Date: {invoice.issue_date.isoformat()}',
    ])


def invoice_qr_png(invoice, scale=10):
    """PNG bytes of the invoice's QR code (dark on white, with quiet zone)."""
    qr = segno.make(invoice_qr_payload(invoice), error='m', encoding='utf-8')
    buffer = BytesIO()
    qr.save(buffer, kind='png', scale=scale, border=3, dark='#14110a', light='#ffffff')
    return buffer.getvalue()


def invoice_qr_data_uri(invoice, scale=10):
    """The same PNG as a data: URI, for embedding straight into the PDF HTML."""
    encoded = base64.b64encode(invoice_qr_png(invoice, scale=scale)).decode('ascii')
    return f'data:image/png;base64,{encoded}'
