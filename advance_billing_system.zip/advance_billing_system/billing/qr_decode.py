"""Read QR codes from uploaded images.

OpenCV's QRCodeDetector is the primary decoder: it installs with plain
`pip install opencv-python-headless` and needs no system libraries. If the
optional `pyzbar` package (which needs the ZBar system library) is installed
it is used as a fallback for images OpenCV cannot read.

This module has no Django imports so it can be tested on its own.
"""
from io import BytesIO

import cv2
import numpy as np
from PIL import Image, ImageOps

try:                                    # optional second opinion
    from pyzbar.pyzbar import decode as _zbar_decode
except Exception:                       # ImportError, or the ZBar shared library is missing
    _zbar_decode = None

ALLOWED_FORMATS = {'PNG', 'JPEG', 'WEBP', 'GIF', 'BMP'}
MAX_UPLOAD_BYTES = 5 * 1024 * 1024      # 5 MB
MAX_PIXELS = 25_000_000                 # refuse "decompression bombs"
MAX_SIDE = 2000                         # larger images are scaled down before decoding
MAX_CODES = 10
MAX_TEXT_LEN = 4000


class QRImageError(Exception):
    """The upload cannot be used. `code` is a stable machine-readable reason."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


def load_image(data):
    """Validate the bytes really are a supported image and return a BGR array."""
    if not data:
        raise QRImageError('empty_file', 'The uploaded file is empty.')
    if len(data) > MAX_UPLOAD_BYTES:
        raise QRImageError('too_large', f'The image is larger than {MAX_UPLOAD_BYTES // (1024 * 1024)} MB.')

    try:
        probe = Image.open(BytesIO(data))
        fmt = probe.format
        width, height = probe.size          # header only: nothing is decoded yet
    except Exception:                       # UnidentifiedImageError, bombs, corrupt headers...
        raise QRImageError('not_an_image', 'That file is not a readable image.')
    if fmt not in ALLOWED_FORMATS:
        raise QRImageError('unsupported_format', 'Upload a PNG, JPEG, WEBP, GIF or BMP image.')
    if width * height > MAX_PIXELS:
        raise QRImageError('too_large', 'The image has too many pixels. Upload a smaller photo.')

    try:
        image = Image.open(BytesIO(data))
        image.load()
        image = ImageOps.exif_transpose(image)          # phone photos: honour rotation
        if image.mode in ('RGBA', 'LA', 'P'):
            image = image.convert('RGBA')
            background = Image.new('RGBA', image.size, (255, 255, 255, 255))   # transparency -> white
            image = Image.alpha_composite(background, image)
        image = image.convert('RGB')
    except Exception:                       # truncated or corrupt pixel data (OSError, EOFError, SyntaxError...)
        raise QRImageError('not_an_image', 'That image is damaged and could not be read.')

    return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)


def _variants(bgr):
    """Progressively more aggressive versions of the image to try."""
    height, width = bgr.shape[:2]
    longest = max(height, width)
    if longest > MAX_SIDE:
        scale = MAX_SIDE / longest
        bgr = cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        height, width = bgr.shape[:2]

    yield bgr
    # Tightly cropped codes have no quiet zone, which detectors need.
    pad = max(20, longest // 10)
    padded = cv2.copyMakeBorder(bgr, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=(255, 255, 255))
    yield padded

    gray = cv2.cvtColor(padded, cv2.COLOR_BGR2GRAY)
    if max(height, width) < 600:                       # small image: enlarge it
        yield cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    _, otsu = cv2.threshold(cv2.GaussianBlur(gray, (3, 3), 0), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    yield otsu
    yield cv2.bitwise_not(gray)                        # light-on-dark codes


def _opencv_decode(img):
    detector = cv2.QRCodeDetector()
    found = []
    try:
        ok, texts, _points, _ = detector.detectAndDecodeMulti(img)
        if ok:
            found.extend(t for t in texts if t)
    except cv2.error:
        pass
    if not found:
        try:
            text, _points, _ = detector.detectAndDecode(img)
            if text:
                found.append(text)
        except cv2.error:
            pass
    return found


def _zbar(img):
    if _zbar_decode is None:
        return []
    try:
        return [r.data.decode('utf-8', errors='replace') for r in _zbar_decode(img) if r.type == 'QRCODE']
    except Exception:
        return []


def decode_qr(data):
    """Return the text of every QR code found in the image bytes (possibly []).

    Raises QRImageError for uploads that are not usable images.
    """
    bgr = load_image(data)
    results = []
    for img in _variants(bgr):
        results = _opencv_decode(img) or _zbar(img)
        if results:
            break

    unique = []
    for text in results:
        text = text.strip()[:MAX_TEXT_LEN]
        if text and text not in unique:
            unique.append(text)
    return unique[:MAX_CODES]
