import datetime
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from accounts.models import UserProfile
from customers.models import Customer
from products.models import Product

from .models import Invoice, InvoiceItem


def make_distributor(username):
    user = User.objects.create_user(username=username, password='pass12345')
    UserProfile.objects.update_or_create(user=user, defaults={'role': UserProfile.ROLE_DISTRIBUTOR})
    return user


class InvoiceMathTests(TestCase):
    def test_line_and_invoice_totals(self):
        user = make_distributor('m@example.com')
        inv = Invoice.objects.create(distributor=user, customer_name='X')
        # 3 x 99.99 = 299.97; 10% off = 29.997 -> 30.00; taxable 269.97; 18% GST = 48.5946 -> 48.59
        a = InvoiceItem.objects.create(invoice=inv, description='A', quantity=Decimal('3'), unit_price=Decimal('99.99'),
                                       discount_percent=Decimal('10'), gst_percent=Decimal('18'))
        self.assertEqual(a.gross_amount, Decimal('299.97'))
        self.assertEqual(a.discount_amount, Decimal('30.00'))
        self.assertEqual(a.gst_amount, Decimal('48.59'))
        self.assertEqual(a.line_total, Decimal('318.56'))
        # 1 x 100, no discount, 5% GST
        InvoiceItem.objects.create(invoice=inv, description='B', quantity=Decimal('1'), unit_price=Decimal('100'),
                                   gst_percent=Decimal('5'))
        self.assertEqual(inv.subtotal, Decimal('399.97'))
        self.assertEqual(inv.discount_total, Decimal('30.00'))
        self.assertEqual(inv.tax_amount, Decimal('53.59'))
        self.assertEqual(inv.total, Decimal('423.56'))

    def test_legacy_invoice_wide_tax_still_applies(self):
        user = make_distributor('l@example.com')
        inv = Invoice.objects.create(distributor=user, customer_name='X', tax_percent=Decimal('10'))
        InvoiceItem.objects.create(invoice=inv, description='Old', quantity=Decimal('2'), unit_price=Decimal('50'))
        self.assertEqual(inv.total, Decimal('110.00'))


class InvoiceFixtures:
    """Shared setup: two distributors, one customer, two products."""

    def setUp(self):
        self.user = make_distributor('d1@example.com')
        self.other = make_distributor('d2@example.com')
        self.customer = Customer.objects.create(distributor=self.user, name='Acme', phone='9876543210', email='a@acme.com')
        self.p1 = Product.objects.create(distributor=self.user, name='Widget', price=Decimal('10.00'), stock=5, gst_rate=Decimal('18'))
        self.p2 = Product.objects.create(distributor=self.user, name='Gadget', price=Decimal('250.00'), stock=5, gst_rate=Decimal('12'))
        self.client.force_login(self.user)

    def _payload(self, rows, **overrides):
        data = {
            'customer': self.customer.pk, 'issue_date': '2026-10-05', 'due_date': '', 'notes': '',
            'items-TOTAL_FORMS': str(len(rows)), 'items-INITIAL_FORMS': '0',
            'items-MIN_NUM_FORMS': '1', 'items-MAX_NUM_FORMS': '1000',
        }
        for i, r in enumerate(rows):
            for k, v in r.items():
                data[f'items-{i}-{k}'] = v
        data.update(overrides)
        return data

    def _row(self, product, qty='1', price='10.00', disc='0', gst='0'):
        return {'product': product.pk, 'quantity': qty, 'unit_price': price, 'discount_percent': disc, 'gst_percent': gst}


class InvoiceFormTests(InvoiceFixtures, TestCase):
    def test_dropdowns_list_db_rows_with_data_attrs(self):
        Customer.objects.create(distributor=self.other, name='NotMine')
        resp = self.client.get(reverse('invoice_create'))
        self.assertContains(resp, 'Acme')
        self.assertNotContains(resp, 'NotMine')
        self.assertContains(resp, 'data-price="10.00"')
        self.assertContains(resp, 'data-gst="18.00"')
        self.assertContains(resp, 'data-phone="9876543210"')
        self.assertContains(resp, 'invoice_form.js')

    def test_blank_row_template_has_product_options(self):
        resp = self.client.get(reverse('invoice_create'))
        html = resp.content.decode()
        tpl = html[html.index('id="empty-row-template"'):]
        self.assertIn('items-__prefix__-product', tpl)
        self.assertIn('Gadget', tpl)

    def test_multiple_products_on_one_invoice(self):
        resp = self.client.post(reverse('invoice_create'), self._payload([
            self._row(self.p1, qty='3', price='10.00', disc='10', gst='18'),
            self._row(self.p2, qty='2', price='250.00', disc='0', gst='12'),
        ]))
        invoice = Invoice.objects.get()
        self.assertRedirects(resp, reverse('invoice_detail', args=[invoice.pk]))
        self.assertEqual(invoice.customer, self.customer)
        self.assertEqual(invoice.customer_name, 'Acme')
        self.assertEqual(invoice.items.count(), 2)
        first, second = invoice.items.order_by('pk')
        self.assertEqual((first.product, first.description), (self.p1, 'Widget'))
        # 3x10=30, -10% = 27.00, +18% = 4.86 -> 31.86
        self.assertEqual(first.line_total, Decimal('31.86'))
        # 2x250=500, +12% = 60 -> 560
        self.assertEqual(second.line_total, Decimal('560.00'))
        self.assertEqual(invoice.total, Decimal('591.86'))

    def test_detail_page_shows_discount_and_gst(self):
        self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1, qty='3', disc='10', gst='18')]))
        invoice = Invoice.objects.get()
        resp = self.client.get(reverse('invoice_detail', args=[invoice.pk]))
        self.assertContains(resp, '10%')
        self.assertContains(resp, '18%')
        self.assertContains(resp, '−₹3.00')

    def test_requires_at_least_one_product(self):
        resp = self.client.post(reverse('invoice_create'), self._payload([
            {'product': '', 'quantity': '1', 'unit_price': '0', 'discount_percent': '0', 'gst_percent': '0'},
        ]))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Add at least one product to the invoice.')
        self.assertEqual(Invoice.objects.count(), 0)

    def test_validation(self):
        for bad in ({'disc': '101'}, {'gst': '-1'}, {'qty': '0'}, {'price': '-5'}):
            resp = self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1, **bad)]))
            self.assertEqual(resp.status_code, 200, bad)
            self.assertEqual(Invoice.objects.count(), 0, bad)

    def test_customer_required_and_scoped(self):
        theirs = Customer.objects.create(distributor=self.other, name='Theirs')
        for cust in ('', theirs.pk):
            resp = self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1)], customer=cust))
            self.assertEqual(resp.status_code, 200)
        self.assertEqual(Invoice.objects.count(), 0)

    def test_cannot_bill_another_distributors_product(self):
        theirs = Product.objects.create(distributor=self.other, name='X', price=Decimal('1'), stock=1)
        resp = self.client.post(reverse('invoice_create'), self._payload([self._row(theirs)]))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(Invoice.objects.count(), 0)

    def test_non_contiguous_rows_after_client_side_removal_are_not_an_issue(self):
        # The JS re-indexes, but even a gap (row 1 missing) must not break the formset.
        data = self._payload([self._row(self.p1), self._row(self.p2)])
        resp = self.client.post(reverse('invoice_create'), data)
        self.assertEqual(Invoice.objects.get().items.count(), 2)

    def test_deleting_customer_or_product_keeps_invoice(self):
        self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1, qty='2', gst='18')]))
        self.customer.delete()
        self.p1.delete()
        invoice = Invoice.objects.get()
        self.assertIsNone(invoice.customer)
        self.assertEqual(invoice.customer_name, 'Acme')
        item = invoice.items.get()
        self.assertIsNone(item.product)
        self.assertEqual((item.description, item.line_total), ('Widget', Decimal('23.60')))


class InvoiceSaveAndToastTests(InvoiceFixtures, TestCase):
    """Feature: save invoice + items together and show a success toast."""

    def test_success_toast_shown_after_creating(self):
        resp = self.client.post(reverse('invoice_create'), self._payload([
            self._row(self.p1, qty='2', gst='18'), self._row(self.p2, qty='1', gst='12'),
        ]), follow=True)
        invoice = Invoice.objects.get()
        self.assertRedirects(resp, reverse('invoice_detail', args=[invoice.pk]))
        self.assertContains(resp, 'toast-success')
        self.assertContains(resp, f'Invoice {invoice.invoice_number} created successfully with 2 items.')
        self.assertContains(resp, 'toast.js')
        # shown once only: a refresh must not repeat it
        again = self.client.get(reverse('invoice_detail', args=[invoice.pk]))
        self.assertNotContains(again, 'toast-success')

    def test_singular_item_wording(self):
        resp = self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1)]), follow=True)
        self.assertContains(resp, 'with 1 item.')

    def test_no_toast_when_validation_fails(self):
        resp = self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1, qty='0')]), follow=True)
        self.assertNotContains(resp, 'created successfully')

    def test_invoice_and_items_saved_atomically(self):
        from unittest import mock
        with mock.patch('billing.forms.BaseInvoiceItemFormSet.save', side_effect=RuntimeError('boom')):
            with self.assertRaises(RuntimeError):
                self.client.post(reverse('invoice_create'), self._payload([self._row(self.p1)]))
        self.assertEqual(Invoice.objects.count(), 0)      # no orphan invoice without items
        self.assertEqual(InvoiceItem.objects.count(), 0)


class InvoicePDFTests(TestCase):
    def setUp(self):
        self.owner = make_distributor('owner@example.com')
        self.owner.first_name, self.owner.last_name = 'Ravi', 'Patel'
        self.owner.save()
        self.other = make_distributor('other@example.com')
        self.invoice = Invoice.objects.create(
            distributor=self.owner, customer_name='Smith & Sons <Traders>', notes='Pay in 15 days',
        )
        InvoiceItem.objects.create(invoice=self.invoice, description='Widget', quantity=Decimal('3'),
                                   unit_price=Decimal('99.99'), discount_percent=Decimal('10'), gst_percent=Decimal('18'))
        self.url = reverse('invoice_pdf', args=[self.invoice.pk])
        self.client.force_login(self.owner)

    def _text(self, resp):
        from io import BytesIO
        from pypdf import PdfReader
        return '\n'.join(page.extract_text() for page in PdfReader(BytesIO(resp.content)).pages)

    def test_returns_a_pdf_inline_by_default(self):
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        self.assertTrue(resp.content.startswith(b'%PDF'))
        self.assertEqual(resp['Content-Disposition'], f'inline; filename="{self.invoice.invoice_number}.pdf"')

    def test_download_flag_forces_attachment(self):
        resp = self.client.get(self.url + '?download=1')
        self.assertEqual(resp['Content-Disposition'], f'attachment; filename="{self.invoice.invoice_number}.pdf"')

    def test_pdf_contains_invoice_data_and_branding(self):
        text = self._text(self.client.get(self.url))
        for expected in (self.invoice.invoice_number, 'Smith & Sons', '<Traders>', 'Widget', 'Advance Billing System',
                         'Ravi Patel', 'Pay in 15 days', '318.56'):
            self.assertIn(expected, text)
        self.assertIn('₹', text)

    def test_pdf_embeds_logo_and_qr(self):
        from io import BytesIO
        from pypdf import PdfReader
        page = PdfReader(BytesIO(self.client.get(self.url).content)).pages[0]
        self.assertEqual(len(page.images), 2)          # logo + QR code
        self.assertIn('Scan for invoice summary', page.extract_text())

    def test_branding_comes_from_settings(self):
        from django.test import override_settings
        from django.conf import settings
        brand = {**settings.INVOICE_BRANDING, 'name': 'Patel Traders', 'gstin': '24ABCDE1234F1Z5', 'footer_note': 'Come again!'}
        with override_settings(INVOICE_BRANDING=brand):
            text = self._text(self.client.get(self.url))
        self.assertIn('Patel Traders', text)
        self.assertIn('24ABCDE1234F1Z5', text)
        self.assertIn('Come again!', text)

    def test_multi_page_invoice(self):
        for i in range(60):
            InvoiceItem.objects.create(invoice=self.invoice, description=f'Bulk item {i}', quantity=Decimal('1'), unit_price=Decimal('10'))
        from io import BytesIO
        from pypdf import PdfReader
        resp = self.client.get(self.url)
        self.assertGreater(len(PdfReader(BytesIO(resp.content)).pages), 1)

    def test_other_distributor_gets_404(self):
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(self.url).status_code, 404)

    def test_admin_can_export_any_invoice(self):
        admin = User.objects.create_user('boss@example.com', password='pass12345')
        UserProfile.objects.update_or_create(user=admin, defaults={'role': UserProfile.ROLE_ADMIN})
        self.client.force_login(admin)
        self.assertEqual(self.client.get(self.url).status_code, 200)

    def test_login_required(self):
        self.client.logout()
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 302)
        self.assertIn('login', resp['Location'])

    def test_download_button_on_invoice_page_actually_downloads_a_pdf(self):
        """Follow the real href from the page's 'Download PDF' button."""
        import re
        page = self.client.get(reverse('invoice_detail', args=[self.invoice.pk])).content.decode()
        match = re.search(r'<a href="([^"]+)"[^>]*>\s*Download PDF\s*</a>', page)
        self.assertIsNotNone(match, 'Download PDF button not found on the invoice page')
        resp = self.client.get(match.group(1).replace('&amp;', '&'))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        self.assertTrue(resp['Content-Disposition'].startswith('attachment;'))
        self.assertTrue(resp.content.startswith(b'%PDF'))

    def test_detail_page_links_to_pdf(self):
        resp = self.client.get(reverse('invoice_detail', args=[self.invoice.pk]))
        self.assertContains(resp, self.url + '?download=1')
        self.assertContains(resp, 'Download PDF')


def make_invoice(user, name='Acme', items=(('Widget', '3', '100'),), **kwargs):
    inv = Invoice.objects.create(distributor=user, customer_name=name, **kwargs)
    for desc, qty, price in items:
        InvoiceItem.objects.create(invoice=inv, description=desc, quantity=Decimal(qty), unit_price=Decimal(price))
    return inv


class InvoiceQRTests(TestCase):
    def setUp(self):
        self.user = make_distributor('qr@example.com')
        self.other = make_distributor('qr2@example.com')
        self.invoice = make_invoice(self.user, 'Acme Traders', (('Widget', '3', '100'), ('Gadget', '2', '50')))
        self.client.force_login(self.user)

    def test_payload_uses_invoice_data(self):
        from .qr import invoice_qr_payload
        payload = invoice_qr_payload(self.invoice)
        self.assertIn(f'Invoice: {self.invoice.invoice_number}', payload)
        self.assertIn('Customer: Acme Traders', payload)
        self.assertIn('Items: 2', payload)
        self.assertIn('Total: INR 400.00', payload)
        self.assertIn(f'Date: {self.invoice.issue_date.isoformat()}', payload)

    def test_payload_follows_the_database(self):
        from .qr import invoice_qr_payload
        InvoiceItem.objects.create(invoice=self.invoice, description='Extra', quantity=Decimal('1'), unit_price=Decimal('25'))
        fresh = Invoice.objects.get(pk=self.invoice.pk)
        payload = invoice_qr_payload(fresh)
        self.assertIn('Items: 3', payload)
        self.assertIn('Total: INR 425.00', payload)

    def test_long_customer_name_is_shortened(self):
        from .qr import invoice_qr_payload
        inv = make_invoice(self.user, 'X' * 150)
        line = [l for l in invoice_qr_payload(inv).split('\n') if l.startswith('Customer: ')][0]
        self.assertLessEqual(len(line), len('Customer: ') + 40)
        self.assertTrue(line.endswith('…'))

    def test_non_latin_name_does_not_break_qr(self):
        from .qr import invoice_qr_png
        inv = make_invoice(self.user, 'પટેલ ટ્રેડર્સ')
        self.assertTrue(invoice_qr_png(inv).startswith(b'\x89PNG'))

    def test_qr_endpoint_returns_png(self):
        resp = self.client.get(reverse('invoice_qr', args=[self.invoice.pk]))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'image/png')
        self.assertTrue(resp.content.startswith(b'\x89PNG'))
        self.assertTrue(resp['Content-Disposition'].startswith('inline'))

    def test_qr_download(self):
        resp = self.client.get(reverse('invoice_qr', args=[self.invoice.pk]) + '?download=1')
        self.assertEqual(resp['Content-Disposition'], f'attachment; filename="{self.invoice.invoice_number}-qr.png"')

    def test_qr_access_control(self):
        url = reverse('invoice_qr', args=[self.invoice.pk])
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(url).status_code, 404)
        self.client.logout()
        self.assertEqual(self.client.get(url).status_code, 302)

    def test_detail_page_shows_qr_and_payload(self):
        resp = self.client.get(reverse('invoice_detail', args=[self.invoice.pk]))
        self.assertContains(resp, reverse('invoice_qr', args=[self.invoice.pk]))
        self.assertContains(resp, 'Total: INR 400.00')

    def test_pdf_qr_changes_with_invoice_data(self):
        from io import BytesIO
        from pypdf import PdfReader
        other = make_invoice(self.user, 'Different Co', (('Thing', '1', '999'),))
        def images(inv):
            # Image order inside a PDF is not guaranteed, so compare all of them (sorted).
            pdf = self.client.get(reverse('invoice_pdf', args=[inv.pk])).content
            return sorted(img.data for img in PdfReader(BytesIO(pdf)).pages[0].images)
        a, b = images(self.invoice), images(other)
        self.assertEqual(len(a), len(b))
        # The logo is identical in both; the QR is not, so exactly one image differs.
        self.assertEqual(len(set(a) ^ set(b)) // 2, 1)


class InvoiceListTableTests(TestCase):
    def setUp(self):
        self.user = make_distributor('list@example.com')
        self.other = make_distributor('list2@example.com')
        self.client.force_login(self.user)
        self.url = reverse('invoice_list')

    def test_row_shows_customer_total_date_and_product_summary(self):
        inv = make_invoice(self.user, 'Acme Traders', (('Widget', '3', '100'), ('Gadget', '2.5', '50'),
                                                       ('Gizmo', '1', '10'), ('Doohickey', '1', '5')),
                           issue_date=datetime.date(2026, 3, 9))
        resp = self.client.get(self.url)
        self.assertContains(resp, 'Acme Traders')
        self.assertContains(resp, '09 Mar 2026')
        self.assertContains(resp, 'Widget ×3, Gadget ×2.5, Gizmo ×1, +1 more')
        self.assertContains(resp, f'₹{inv.total:.2f}')            # 300 + 125 + 10 + 5 = 440.00
        self.assertContains(resp, inv.invoice_number)
        self.assertEqual(inv.item_count, 4)

    def test_invoice_without_items_shows_dash(self):
        Invoice.objects.create(distributor=self.user, customer_name='Empty Co')
        self.assertContains(self.client.get(self.url), 'Empty Co')

    def test_only_own_invoices_listed(self):
        make_invoice(self.user, 'Mine Ltd')
        make_invoice(self.other, 'Theirs Ltd')
        resp = self.client.get(self.url)
        self.assertContains(resp, 'Mine Ltd')
        self.assertNotContains(resp, 'Theirs Ltd')

    def test_pagination(self):
        for i in range(20):
            make_invoice(self.user, f'Customer {i:02d}')
        page1 = self.client.get(self.url)
        self.assertEqual(len(page1.context['page_obj'].object_list), 15)
        self.assertContains(page1, 'Page 1 of 2')
        page2 = self.client.get(self.url + '?page=2')
        self.assertEqual(len(page2.context['page_obj'].object_list), 5)
        self.assertContains(page2, 'Page 2 of 2')
        self.assertContains(page2, 'Previous')
        self.assertContains(page1, '20 total')

    def test_query_count_does_not_grow_with_rows(self):
        from django.db import connection
        from django.test.utils import CaptureQueriesContext
        for i in range(2):
            make_invoice(self.user, f'A{i}', (('W', '1', '10'), ('G', '1', '10')))
        with CaptureQueriesContext(connection) as few:
            self.client.get(self.url)
        for i in range(13):
            make_invoice(self.user, f'B{i}', (('W', '1', '10'), ('G', '1', '10'), ('H', '2', '5')))
        with CaptureQueriesContext(connection) as many:
            self.client.get(self.url)
        self.assertEqual(len(few), len(many))                       # no N+1

    def test_row_links_to_pdf_and_qr(self):
        inv = make_invoice(self.user)
        resp = self.client.get(self.url)
        self.assertContains(resp, reverse('invoice_pdf', args=[inv.pk]))
        self.assertContains(resp, reverse('invoice_qr', args=[inv.pk]))
