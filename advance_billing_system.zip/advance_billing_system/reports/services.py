"""Report calculations.

Invoice totals are *computed* properties in this project (never stored), and
each line is rounded step by step. To make the reports agree to the paisa with
the invoice pages and PDFs, they reuse those same properties instead of
re-deriving totals with SQL aggregates. Items are prefetched, so each report
costs a fixed number of queries regardless of how many invoices there are.
"""
from collections import namedtuple
from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.db.models import Count

from accounts.models import UserProfile
from billing.models import Invoice, InvoiceItem
from products.models import Product

from . import logic
from .logic import ZERO

DEFAULT_LOW_STOCK = 10

Figure = namedtuple('Figure', 'invoice subtotal discount tax total status')


class Totals:
    """Running totals for a group of invoices."""

    def __init__(self):
        self.count = 0
        self.subtotal = self.discount = self.tax = self.total = ZERO
        self.paid = self.outstanding = self.overdue = ZERO
        self.paid_count = self.unpaid_count = self.overdue_count = 0

    def add(self, fig):
        self.count += 1
        self.subtotal += fig.subtotal
        self.discount += fig.discount
        self.tax += fig.tax
        self.total += fig.total
        if fig.status == logic.PAID:
            self.paid += fig.total
            self.paid_count += 1
        else:
            self.outstanding += fig.total
            if fig.status == logic.OVERDUE:
                self.overdue += fig.total
                self.overdue_count += 1
            else:
                self.unpaid_count += 1


def collect(date_from=None, date_to=None, today=None):
    """Every invoice issued in [date_from, date_to] (either bound optional)."""
    from django.utils import timezone
    today = today or timezone.localdate()
    qs = Invoice.objects.select_related('distributor').prefetch_related('items')
    if date_from:
        qs = qs.filter(issue_date__gte=date_from)
    if date_to:
        qs = qs.filter(issue_date__lte=date_to)
    return [
        Figure(inv, inv.subtotal, inv.discount_total, inv.tax_amount, inv.total,
               logic.effective_status(inv.status, inv.due_date, today))
        for inv in qs
    ]


def summarise(figures):
    totals = Totals()
    for fig in figures:
        totals.add(fig)
    return totals


def monthly(figures):
    """[(first_of_month, Totals)] oldest first, with a bar percentage on each."""
    buckets = {}
    for fig in figures:
        key = (fig.invoice.issue_date.year, fig.invoice.issue_date.month)
        buckets.setdefault(key, Totals()).add(fig)
    rows = [(date(y, m, 1), buckets[(y, m)]) for (y, m) in sorted(buckets)]
    top = max((t.total for _, t in rows), default=ZERO)
    return [{'month': month, 'totals': t, 'bar': logic.bar_pct(t.total, top)} for month, t in rows]


def display_name(user):
    return user.get_full_name() or user.username


def by_distributor(figures):
    """One row per distributor (including idle ones), biggest biller first."""
    people = (
        User.objects.filter(profile__role=UserProfile.ROLE_DISTRIBUTOR)
        .annotate(customer_n=Count('customers', distinct=True), product_n=Count('products', distinct=True))
    )
    rows = {u.pk: {'user': u, 'name': display_name(u), 'totals': Totals(),
                   'customers': u.customer_n, 'products': u.product_n} for u in people}
    for fig in figures:
        owner = fig.invoice.distributor
        row = rows.setdefault(owner.pk, {'user': owner, 'name': display_name(owner), 'totals': Totals(),
                                         'customers': 0, 'products': 0})
        row['totals'].add(fig)
    return sorted(rows.values(), key=lambda r: (-r['totals'].total, r['name'].lower()))


def product_sales(date_from=None, date_to=None):
    """Units and net sales per product, best sellers first.

    Lines are grouped by product; lines whose product was later deleted are
    grouped by their billed description instead, so history is never lost.
    """
    items = InvoiceItem.objects.select_related('product', 'invoice')
    if date_from:
        items = items.filter(invoice__issue_date__gte=date_from)
    if date_to:
        items = items.filter(invoice__issue_date__lte=date_to)

    groups = {}
    for item in items:
        if item.product_id:
            key, name, removed = ('p', item.product_id), item.product.name, False
        else:
            key, name, removed = ('d', item.description.strip().lower()), item.description.strip(), True
        g = groups.setdefault(key, {'name': name, 'removed': removed, 'units': Decimal('0'),
                                    'net': ZERO, 'gst': ZERO, 'invoice_ids': set()})
        g['units'] += item.quantity
        g['net'] += item.taxable_amount
        g['gst'] += item.gst_amount
        g['invoice_ids'].add(item.invoice_id)

    rows = []
    for g in groups.values():
        g['invoices'] = len(g.pop('invoice_ids'))
        rows.append(g)
    rows.sort(key=lambda r: (-r['net'], r['name'].lower()))
    return rows


def stock_alerts(threshold):
    """Products at or below `threshold` units (0 = only out-of-stock), emptiest first."""
    return list(
        Product.objects.filter(stock__lte=threshold)
        .select_related('distributor').order_by('stock', 'name')
    )


def receivables(today=None):
    """Everything still owed as of today, with ageing. Ignores the date filter on purpose."""
    from django.utils import timezone
    today = today or timezone.localdate()
    rows = []
    labels = logic.AGING_LABELS + (logic.MARKED_OVERDUE,)
    aging = [{'label': label, 'count': 0, 'amount': ZERO} for label in labels]
    for fig in collect(today=today):
        if fig.status == logic.PAID:
            continue
        days = logic.days_overdue(fig.invoice.due_date, today)
        bucket = logic.aging_bucket(days)
        if fig.status == logic.OVERDUE and days == 0:
            bucket = len(labels) - 1
        aging[bucket]['count'] += 1
        aging[bucket]['amount'] += fig.total
        rows.append({'invoice': fig.invoice, 'total': fig.total, 'status': fig.status,
                     'days': days, 'bucket': labels[bucket]})
    rows.sort(key=lambda r: (-r['days'], r['invoice'].invoice_number))
    return rows, aging
