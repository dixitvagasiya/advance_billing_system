import csv
import io
from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth.models import User
from django.db import connection
from django.test import Client, SimpleTestCase, TestCase
from django.test.utils import CaptureQueriesContext
from django.urls import reverse
from django.utils import timezone

from accounts.models import UserProfile
from billing.models import Invoice, InvoiceItem
from customers.models import Customer
from products.models import Product

from . import logic, services

PW = 'Some-Pass-123!'
REPORT_URLS = ('reports_overview', 'reports_distributors', 'reports_products', 'reports_receivables')


def make_user(email, role=UserProfile.ROLE_DISTRIBUTOR, first='', last=''):
    user = User.objects.create_user(username=email, email=email, password=PW, first_name=first, last_name=last)
    UserProfile.objects.create(user=user, role=role)
    return user


def make_invoice(distributor, customer='Acme', items=(), status=Invoice.STATUS_UNPAID,
                 issue_date=None, due_date=None, product=None):
    """items: (description, qty, unit_price, discount_pct, gst_pct) tuples."""
    invoice = Invoice.objects.create(
        distributor=distributor, customer_name=customer, status=status,
        issue_date=issue_date or timezone.localdate(), due_date=due_date)
    for description, qty, price, disc, gst in items:
        InvoiceItem.objects.create(
            invoice=invoice, product=product, description=description, quantity=Decimal(qty),
            unit_price=Decimal(price), discount_percent=Decimal(disc), gst_percent=Decimal(gst))
    return invoice


def rows_of(response):
    text = response.content.decode('utf-8-sig')
    return list(csv.reader(io.StringIO(text)))


class LogicTests(SimpleTestCase):
    """The pure helpers, plus a guard that they stay in step with the model."""

    def test_status_constants_match_the_invoice_model(self):
        self.assertEqual((logic.PAID, logic.UNPAID, logic.OVERDUE),
                         (Invoice.STATUS_PAID, Invoice.STATUS_UNPAID, Invoice.STATUS_OVERDUE))

    def test_effective_status(self):
        today = date(2026, 10, 14)
        self.assertEqual(logic.effective_status('paid', date(2020, 1, 1), today), 'paid')   # paid is final
        self.assertEqual(logic.effective_status('unpaid', None, today), 'unpaid')
        self.assertEqual(logic.effective_status('unpaid', today, today), 'unpaid')          # due today is not late
        self.assertEqual(logic.effective_status('unpaid', today - timedelta(days=1), today), 'overdue')
        self.assertEqual(logic.effective_status('overdue', None, today), 'overdue')

    def test_aging_bucket_boundaries(self):
        self.assertEqual([logic.aging_bucket(d) for d in (0, 1, 30, 31, 60, 61, 400)], [0, 1, 1, 2, 2, 3, 3])

    def test_csv_cell_blocks_formula_injection(self):
        for risky in ('=SUM(A1)', '+1', '-1', '@cmd', '\tx'):
            self.assertEqual(logic.csv_cell(risky), "'" + risky)
        self.assertEqual(logic.csv_cell('Acme'), 'Acme')
        self.assertEqual(logic.csv_cell(Decimal('5')), '5.00')
        self.assertEqual(logic.csv_cell(date(2026, 1, 2)), '2026-01-02')

    def test_bar_pct(self):
        self.assertEqual((logic.bar_pct(0, 10), logic.bar_pct(10, 10), logic.bar_pct(5, 0)), (0, 100, 0))
        self.assertEqual(logic.bar_pct(1, 1000), 1)     # tiny but non-zero stays visible


class AccessTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com')

    def test_anonymous_is_sent_to_the_admin_login(self):
        for name in REPORT_URLS:
            resp = Client().get(reverse(name))
            self.assertEqual(resp.status_code, 302, name)
            self.assertIn(reverse('admin_login'), resp.url, name)

    def test_distributors_are_forbidden_everywhere(self):
        self.client.force_login(self.dist)
        for name in REPORT_URLS:
            self.assertEqual(self.client.get(reverse(name)).status_code, 403, name)
            self.assertEqual(self.client.get(reverse(name), {'export': 'csv'}).status_code, 403, name)

    def test_admin_can_open_every_report(self):
        self.client.force_login(self.admin)
        for name in REPORT_URLS:
            self.assertEqual(self.client.get(reverse(name)).status_code, 200, name)

    def test_reports_are_read_only(self):
        self.client.force_login(self.admin)
        for name in REPORT_URLS:
            # POST is accepted by the view but changes nothing; no model is writable here
            before = (Invoice.objects.count(), Product.objects.count())
            self.client.post(reverse(name), {'x': 'y'})
            self.assertEqual(before, (Invoice.objects.count(), Product.objects.count()))

    def test_admin_dashboard_is_no_longer_open_to_distributors(self):
        self.client.force_login(self.dist)
        self.assertEqual(self.client.get(reverse('admin_dashboard')).status_code, 403)
        self.assertEqual(Client().get(reverse('admin_dashboard')).status_code, 302)

    def test_dashboard_links_to_every_report(self):
        self.client.force_login(self.admin)
        resp = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(resp.status_code, 200)
        for name in REPORT_URLS:
            self.assertContains(resp, reverse(name))

    def test_reports_nav_link_is_admin_only(self):
        self.client.force_login(self.admin)
        self.assertContains(self.client.get(reverse('admin_dashboard')), '>Reports</a>')
        d = Client(); d.force_login(self.dist)
        self.assertNotContains(d.get(reverse('distributor_dashboard')), '>Reports</a>')

    def test_nav_highlights_reports_not_products_on_the_products_report(self):
        self.client.force_login(self.admin)
        resp = self.client.get(reverse('reports_products'))
        self.assertContains(resp, 'aria-current="page">Reports</a>')
        self.assertContains(resp, '<a href="/products/" >Products</a>')   # not marked current


class OverviewTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.d1 = make_user('d1@x.com', first='Dev', last='One')
        self.d2 = make_user('d2@x.com')
        self.client.force_login(self.admin)
        self.today = timezone.localdate()

    def _four_invoices(self):
        # 2 x 100, 10% off, 18% GST -> gross 200.00, discount 20.00, GST 32.40, total 212.40
        make_invoice(self.d1, items=[('A', 2, '100', '10', '18')], status=Invoice.STATUS_PAID)
        make_invoice(self.d1, items=[('B', 1, '50', '0', '0')], due_date=self.today + timedelta(days=5))
        make_invoice(self.d2, items=[('C', 1, '30', '0', '0')], due_date=self.today - timedelta(days=1))
        make_invoice(self.d2, items=[('D', 1, '20', '0', '0')], status=Invoice.STATUS_OVERDUE)

    def test_headline_numbers_match_the_invoice_arithmetic(self):
        self._four_invoices()
        totals = self.client.get(reverse('reports_overview')).context['totals']
        self.assertEqual(totals.count, 4)
        self.assertEqual(totals.total, Decimal('312.40'))
        self.assertEqual(totals.paid, Decimal('212.40'))
        self.assertEqual(totals.outstanding, Decimal('100.00'))
        self.assertEqual(totals.overdue, Decimal('50.00'))          # past due date + marked overdue
        self.assertEqual(totals.tax, Decimal('32.40'))
        self.assertEqual(totals.discount, Decimal('20.00'))
        self.assertEqual((totals.paid_count, totals.unpaid_count, totals.overdue_count), (1, 1, 2))

    def test_paid_plus_outstanding_always_equals_total(self):
        self._four_invoices()
        t = self.client.get(reverse('reports_overview')).context['totals']
        self.assertEqual(t.paid + t.outstanding, t.total)

    def test_empty_database_renders_zeroes_not_errors(self):
        resp = self.client.get(reverse('reports_overview'))
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.context['totals'].total, Decimal('0'))
        self.assertContains(resp, 'No invoices were issued in this period')

    def test_months_are_grouped_oldest_first_with_bars(self):
        make_invoice(self.d1, items=[('A', 1, '100', '0', '0')], issue_date=date(2026, 9, 10))
        make_invoice(self.d1, items=[('A', 1, '50', '0', '0')], issue_date=date(2026, 8, 5))
        make_invoice(self.d1, items=[('A', 1, '50', '0', '0')], issue_date=date(2026, 8, 30))
        months = self.client.get(reverse('reports_overview')).context['months']
        self.assertEqual([m['month'] for m in months], [date(2026, 8, 1), date(2026, 9, 1)])
        self.assertEqual([m['totals'].count for m in months], [2, 1])
        self.assertEqual([m['bar'] for m in months], [100, 100])      # both 100.00 — tie for the top

    def test_date_range_is_inclusive_at_both_ends(self):
        for offset in (-40, -30, -10, 0, 1):
            make_invoice(self.d1, items=[('A', 1, '10', '0', '0')], issue_date=self.today + timedelta(days=offset))
        resp = self.client.get(reverse('reports_overview'), {
            'date_from': (self.today - timedelta(days=30)).isoformat(), 'date_to': self.today.isoformat()})
        self.assertEqual(resp.context['totals'].count, 3)             # -30, -10, 0

    def test_open_ended_ranges(self):
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0')], issue_date=date(2026, 1, 1))
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0')], issue_date=date(2026, 6, 1))
        url = reverse('reports_overview')
        self.assertEqual(self.client.get(url, {'date_from': '2026-03-01'}).context['totals'].count, 1)
        self.assertEqual(self.client.get(url, {'date_to': '2026-03-01'}).context['totals'].count, 1)

    def test_reversed_range_shows_an_error_and_falls_back_to_all_time(self):
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0')])
        resp = self.client.get(reverse('reports_overview'), {'date_from': '2026-10-10', 'date_to': '2026-10-01'})
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'end date cannot be before the start date')
        self.assertEqual(resp.context['totals'].count, 1)

    def test_garbage_dates_do_not_crash(self):
        for bad in ('garbage', '2026-13-45', '31/12/2026', "1'; DROP TABLE x;--"):
            resp = self.client.get(reverse('reports_overview'), {'date_from': bad})
            self.assertEqual(resp.status_code, 200, bad)
            self.assertIn('date_from', resp.context['form'].errors)

    def test_preset_links_and_filter_carry_over_to_other_tabs(self):
        resp = self.client.get(reverse('reports_overview'), {'date_from': '2026-10-01', 'date_to': '2026-10-14'})
        self.assertContains(resp, f'{reverse("reports_distributors")}?date_from=2026-10-01&amp;date_to=2026-10-14')
        self.assertContains(resp, 'This financial year')

    def test_financial_year_preset_starts_in_april(self):
        from .views import _financial_year_start
        self.assertEqual(_financial_year_start(date(2026, 10, 14)), date(2026, 4, 1))
        self.assertEqual(_financial_year_start(date(2027, 2, 3)), date(2026, 4, 1))
        self.assertEqual(_financial_year_start(date(2026, 4, 1)), date(2026, 4, 1))

    def test_query_count_does_not_grow_with_invoice_count(self):
        def count():
            with CaptureQueriesContext(connection) as ctx:
                self.client.get(reverse('reports_overview'))
            return len(ctx)
        make_invoice(self.d1, items=[('A', 1, '10', '0', '0'), ('B', 1, '10', '0', '0')])
        few = count()
        for _ in range(8):
            make_invoice(self.d2, items=[('A', 1, '10', '0', '0'), ('B', 1, '10', '0', '0')])
        self.assertEqual(count(), few)

    def test_csv_export(self):
        self._four_invoices()
        resp = self.client.get(reverse('reports_overview'), {'export': 'csv'})
        self.assertEqual(resp['Content-Type'], 'text/csv; charset=utf-8')
        self.assertIn('attachment; filename="sales-by-month-', resp['Content-Disposition'])
        rows = rows_of(resp)
        self.assertEqual(rows[0][:3], ['Month', 'Invoices', 'Subtotal'])
        self.assertEqual(rows[1][1], '4')
        self.assertEqual(rows[1][5], '312.40')


class DistributorReportTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.big = make_user('big@x.com', first='Big', last='Biller')
        self.small = make_user('small@x.com', first='Small')
        self.idle = make_user('idle@x.com', first='Idle')
        self.client.force_login(self.admin)

    def test_ranked_by_billed_amount_and_idle_distributors_still_listed(self):
        make_invoice(self.small, items=[('A', 1, '10', '0', '0')])
        make_invoice(self.big, items=[('A', 1, '500', '0', '0')], status=Invoice.STATUS_PAID)
        make_invoice(self.big, items=[('A', 1, '100', '0', '0')], due_date=timezone.localdate() - timedelta(days=3))
        rows = self.client.get(reverse('reports_distributors')).context['rows']
        self.assertEqual([r['name'] for r in rows], ['Big Biller', 'Small', 'Idle'])
        big = rows[0]['totals']
        self.assertEqual((big.count, big.total, big.paid, big.outstanding, big.overdue),
                         (2, Decimal('600.00'), Decimal('500.00'), Decimal('100.00'), Decimal('100.00')))
        self.assertEqual(rows[2]['totals'].count, 0)

    def test_customer_and_product_counts(self):
        Customer.objects.create(distributor=self.big, name='C1')
        Customer.objects.create(distributor=self.big, name='C2')
        Product.objects.create(distributor=self.big, name='P1', price=Decimal('1'))
        rows = {r['name']: r for r in self.client.get(reverse('reports_distributors')).context['rows']}
        self.assertEqual((rows['Big Biller']['customers'], rows['Big Biller']['products']), (2, 1))
        self.assertEqual((rows['Small']['customers'], rows['Small']['products']), (0, 0))

    def test_admin_accounts_are_not_listed_as_distributors(self):
        names = [r['name'] for r in self.client.get(reverse('reports_distributors')).context['rows']]
        self.assertNotIn('admin@x.com', names)
        self.assertEqual(len(names), 3)

    def test_date_filter_applies(self):
        make_invoice(self.big, items=[('A', 1, '10', '0', '0')], issue_date=date(2026, 1, 1))
        rows = self.client.get(reverse('reports_distributors'), {'date_from': '2026-06-01'}).context['rows']
        self.assertEqual(rows[0]['totals'].count, 0)

    def test_csv_export(self):
        make_invoice(self.big, items=[('A', 1, '10', '0', '0')])
        rows = rows_of(self.client.get(reverse('reports_distributors'), {'export': 'csv'}))
        self.assertEqual(rows[0][0], 'Distributor')
        self.assertEqual(rows[1][:3], ['Big Biller', 'big@x.com', '1'])


class ProductReportTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com', first='Dee')
        self.client.force_login(self.admin)
        self.p = Product.objects.create(distributor=self.dist, name='Widget', price=Decimal('100'), stock=50)

    def test_units_and_net_sales_are_summed_per_product(self):
        make_invoice(self.dist, product=self.p, items=[('Widget', 2, '100', '0', '18')])
        make_invoice(self.dist, product=self.p, items=[('Widget', 3, '100', '10', '18')])
        sales = self.client.get(reverse('reports_products')).context['sales']
        self.assertEqual(len(sales), 1)
        row = sales[0]
        self.assertEqual(row['name'], 'Widget')
        self.assertEqual(row['units'], Decimal('5'))
        self.assertEqual(row['invoices'], 2)
        self.assertEqual(row['net'], Decimal('470.00'))             # 200 + (300 - 30)
        self.assertEqual(row['gst'], Decimal('84.60'))              # 36.00 + 48.60

    def test_lines_of_deleted_products_are_kept_and_grouped_by_description(self):
        make_invoice(self.dist, product=self.p, items=[('Widget', 1, '100', '0', '0')])
        make_invoice(self.dist, items=[('Old Thing', 1, '10', '0', '0')])
        make_invoice(self.dist, items=[(' old thing ', 2, '10', '0', '0')])
        sales = self.client.get(reverse('reports_products')).context['sales']
        by_name = {r['name'].lower(): r for r in sales}
        self.assertEqual(by_name['old thing']['units'], Decimal('3'))
        self.assertTrue(by_name['old thing']['removed'])
        self.assertFalse(by_name['widget']['removed'])
        self.assertEqual(sales[0]['name'], 'Widget')                # best seller first (100 > 30)

    def test_date_filter_applies_to_sales(self):
        make_invoice(self.dist, product=self.p, items=[('Widget', 1, '100', '0', '0')], issue_date=date(2026, 1, 1))
        resp = self.client.get(reverse('reports_products'), {'date_from': '2026-06-01'})
        self.assertEqual(resp.context['sales'], [])
        self.assertContains(resp, 'No products were billed in this period')

    def test_only_top_rows_are_shown_but_the_csv_has_all(self):
        for n in range(27):
            make_invoice(self.dist, items=[(f'Item {n:02d}', 1, str(100 + n), '0', '0')])
        resp = self.client.get(reverse('reports_products'))
        self.assertEqual(len(resp.context['sales']), 25)
        self.assertEqual(resp.context['sales_total'], 27)
        rows = rows_of(self.client.get(reverse('reports_products'), {'export': 'sales'}))
        self.assertEqual(len(rows), 1 + 27)

    def test_stock_alerts_default_threshold_and_ordering(self):
        for name, stock in (('Out', 0), ('Five', 5), ('Ten', 10), ('Eleven', 11)):
            Product.objects.create(distributor=self.dist, name=name, price=Decimal('1'), stock=stock)
        resp = self.client.get(reverse('reports_products'))
        self.assertEqual([p.name for p in resp.context['alerts']], ['Out', 'Five', 'Ten'])   # <= 10, emptiest first
        self.assertEqual(resp.context['out_of_stock'], 1)

    def test_custom_and_zero_thresholds(self):
        for name, stock in (('Out', 0), ('Five', 5), ('Ten', 10)):
            Product.objects.create(distributor=self.dist, name=name, price=Decimal('1'), stock=stock)
        url = reverse('reports_products')
        self.assertEqual([p.name for p in self.client.get(url, {'low_stock': '5'}).context['alerts']], ['Out', 'Five'])
        self.assertEqual([p.name for p in self.client.get(url, {'low_stock': '0'}).context['alerts']], ['Out'])

    def test_invalid_threshold_falls_back_to_default_with_an_error(self):
        Product.objects.create(distributor=self.dist, name='Five', price=Decimal('1'), stock=5)
        for bad in ('-1', 'abc', '1.5', '999999999'):
            resp = self.client.get(reverse('reports_products'), {'low_stock': bad})
            self.assertEqual(resp.status_code, 200, bad)
            self.assertEqual(resp.context['threshold'], services.DEFAULT_LOW_STOCK, bad)
            self.assertTrue(resp.context['stock_form'].errors, bad)

    def test_stock_csv(self):
        Product.objects.create(distributor=self.dist, name='Five', price=Decimal('9.5'), stock=5)
        rows = rows_of(self.client.get(reverse('reports_products'), {'export': 'stock'}))
        self.assertEqual(rows[0], ['Product', 'Category', 'Distributor', 'Stock', 'Price'])
        self.assertEqual(rows[1], ['Five', '', 'Dee', '5', '9.50'])

    def test_unknown_export_value_just_renders_the_page(self):
        resp = self.client.get(reverse('reports_products'), {'export': 'bogus'})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'].split(';')[0], 'text/html')


class ReceivablesTests(TestCase):
    def setUp(self):
        self.admin = make_user('admin@x.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('d@x.com')
        self.client.force_login(self.admin)
        self.today = timezone.localdate()

    def _invoice(self, amount, due_offset=None, status=Invoice.STATUS_UNPAID, customer='Acme', issued=None):
        due = None if due_offset is None else self.today + timedelta(days=due_offset)
        return make_invoice(self.dist, customer=customer, items=[('X', 1, str(amount), '0', '0')],
                            status=status, due_date=due, issue_date=issued)

    def test_ageing_buckets(self):
        self._invoice(10, due_offset=5)                 # not yet due
        self._invoice(20, due_offset=-10)               # 1-30
        self._invoice(30, due_offset=-45)               # 31-60
        self._invoice(40, due_offset=-90)               # 61+
        self._invoice(50, status=Invoice.STATUS_OVERDUE)  # marked overdue, no due date
        self._invoice(999, due_offset=-90, status=Invoice.STATUS_PAID)   # paid: never owed
        resp = self.client.get(reverse('reports_receivables'))
        aging = resp.context['aging']
        self.assertEqual([a['count'] for a in aging], [1, 1, 1, 1, 1])
        self.assertEqual([a['amount'] for a in aging], [Decimal(n) for n in (10, 20, 30, 40, 50)])
        self.assertEqual(aging[4]['label'], 'Marked overdue')
        self.assertEqual(resp.context['owed_total'], Decimal('150.00'))

    def test_rows_are_ordered_most_overdue_first(self):
        self._invoice(10, due_offset=-5)
        self._invoice(10, due_offset=-50)
        self._invoice(10, due_offset=3)
        self.assertEqual([r['days'] for r in self.client.get(reverse('reports_receivables')).context['rows']], [50, 5, 0])

    def test_ignores_the_date_filter(self):
        self._invoice(10, due_offset=-400, issued=date(2025, 1, 1))
        resp = self.client.get(reverse('reports_receivables'), {'date_from': '2026-10-01'})
        self.assertEqual(len(resp.context['rows']), 1)

    def test_nothing_owed(self):
        self._invoice(10, status=Invoice.STATUS_PAID)
        self.assertContains(self.client.get(reverse('reports_receivables')), 'Nothing outstanding')

    def test_csv_neutralises_formula_injection_in_customer_names(self):
        self._invoice(10, due_offset=-1, customer='=HYPERLINK("http://evil","x")')
        rows = rows_of(self.client.get(reverse('reports_receivables'), {'export': 'csv'}))
        self.assertTrue(rows[1][1].startswith("'="), rows[1][1])
        self.assertEqual(rows[1][5], 'Overdue')
        self.assertEqual(rows[1][6], '1')

    def test_names_are_html_escaped(self):
        self._invoice(10, due_offset=-1, customer='<script>alert(1)</script>')
        resp = self.client.get(reverse('reports_receivables'))
        self.assertNotContains(resp, '<script>alert(1)</script>')
        self.assertContains(resp, '&lt;script&gt;alert(1)&lt;/script&gt;')
