import csv
from datetime import date, timedelta
from urllib.parse import urlencode

from django.http import HttpResponse
from django.shortcuts import render
from django.utils import timezone

from accounts.decorators import admin_required

from . import logic, services
from .forms import DateRangeForm, StockThresholdForm

TOP_PRODUCTS_SHOWN = 25


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _csv_response(filename, header, rows):
    response = HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    response.write('\ufeff')            # BOM so Excel reads UTF-8 (₹, accents) correctly
    writer = csv.writer(response)
    writer.writerow(header)
    for row in rows:
        writer.writerow([logic.csv_cell(cell) for cell in row])
    return response


def _financial_year_start(today):
    return date(today.year if today.month >= 4 else today.year - 1, 4, 1)


def _range_context(request, today):
    """Validate the ?date_from / ?date_to filter shared by the reports.

    Returns (date_from, date_to, context). An invalid range is reported on the
    form and the report falls back to 'all time' rather than guessing.
    """
    form = DateRangeForm(request.GET)
    date_from = date_to = None
    if form.is_valid():
        date_from, date_to = form.cleaned_data['date_from'], form.cleaned_data['date_to']

    def link(start, end):
        return urlencode({'date_from': start.isoformat(), 'date_to': end.isoformat()})

    candidates = [
        ('This month', today.replace(day=1), today),
        ('Last 30 days', today - timedelta(days=29), today),
        ('This financial year', _financial_year_start(today), today),
        ('This year', date(today.year, 1, 1), today),
    ]
    presets = [{'label': label, 'qs': link(start, end),
                'active': (start, end) == (date_from, date_to)} for label, start, end in candidates]

    params = {}
    if date_from:
        params['date_from'] = date_from.isoformat()
    if date_to:
        params['date_to'] = date_to.isoformat()

    return date_from, date_to, {
        'form': form, 'presets': presets, 'qs': urlencode(params),
        'date_from': date_from, 'date_to': date_to,
        'filtered': bool(params),
    }


def _stamp(today):
    return today.isoformat()


# ---------------------------------------------------------------------------
# Reports (all admin-only)
# ---------------------------------------------------------------------------

@admin_required
def overview_view(request):
    """Sales overview: headline numbers plus a month-by-month breakdown."""
    today = timezone.localdate()
    date_from, date_to, ctx = _range_context(request, today)
    figures = services.collect(date_from, date_to, today)
    months = services.monthly(figures)

    if request.GET.get('export') == 'csv':
        rows = [[m['month'].strftime('%b %Y'), m['totals'].count, m['totals'].subtotal, m['totals'].discount,
                 m['totals'].tax, m['totals'].total, m['totals'].paid, m['totals'].outstanding]
                for m in months]
        return _csv_response(f'sales-by-month-{_stamp(today)}.csv',
                             ['Month', 'Invoices', 'Subtotal', 'Discount', 'GST', 'Total billed',
                              'Collected', 'Outstanding'], rows)

    ctx.update({'section': 'overview', 'totals': services.summarise(figures), 'months': months})
    return render(request, 'reports/overview.html', ctx)


@admin_required
def distributors_view(request):
    today = timezone.localdate()
    date_from, date_to, ctx = _range_context(request, today)
    rows = services.by_distributor(services.collect(date_from, date_to, today))

    if request.GET.get('export') == 'csv':
        out = [[r['name'], r['user'].email or r['user'].username, r['totals'].count, r['totals'].total,
                r['totals'].paid, r['totals'].outstanding, r['totals'].overdue, r['customers'], r['products']]
               for r in rows]
        return _csv_response(f'distributors-{_stamp(today)}.csv',
                             ['Distributor', 'Email', 'Invoices', 'Total billed', 'Collected',
                              'Outstanding', 'Overdue', 'Customers', 'Products'], out)

    ctx.update({'section': 'distributors', 'rows': rows})
    return render(request, 'reports/distributors.html', ctx)


@admin_required
def products_view(request):
    """Best sellers in the period + current stock alerts."""
    today = timezone.localdate()
    date_from, date_to, ctx = _range_context(request, today)

    stock_form = StockThresholdForm(request.GET)
    threshold = services.DEFAULT_LOW_STOCK
    if stock_form.is_valid() and stock_form.cleaned_data['low_stock'] is not None:
        threshold = stock_form.cleaned_data['low_stock']

    export = request.GET.get('export')
    if export == 'sales':
        rows = [[r['name'], 'No (removed)' if r['removed'] else 'Yes', r['units'], r['invoices'], r['net'], r['gst']]
                for r in services.product_sales(date_from, date_to)]
        return _csv_response(f'product-sales-{_stamp(today)}.csv',
                             ['Product', 'In catalog', 'Units sold', 'Invoices', 'Net sales', 'GST'], rows)
    if export == 'stock':
        rows = [[p.name, p.category, services.display_name(p.distributor), p.stock, p.price]
                for p in services.stock_alerts(threshold)]
        return _csv_response(f'low-stock-{_stamp(today)}.csv',
                             ['Product', 'Category', 'Distributor', 'Stock', 'Price'], rows)

    sales = services.product_sales(date_from, date_to)
    alerts = services.stock_alerts(threshold)
    ctx.update({
        'section': 'products',
        'sales': sales[:TOP_PRODUCTS_SHOWN], 'sales_total': len(sales),
        'alerts': alerts, 'threshold': threshold, 'stock_form': stock_form,
        'out_of_stock': sum(1 for p in alerts if p.stock == 0),
    })
    return render(request, 'reports/products.html', ctx)


@admin_required
def receivables_view(request):
    """Money still owed as of today, aged by days past due. Not date-filtered."""
    today = timezone.localdate()
    rows, aging = services.receivables(today)

    if request.GET.get('export') == 'csv':
        out = [[r['invoice'].invoice_number, r['invoice'].customer_name, services.display_name(r['invoice'].distributor),
                r['invoice'].issue_date, r['invoice'].due_date or '', r['status'].title(), r['days'], r['bucket'], r['total']]
               for r in rows]
        return _csv_response(f'receivables-{_stamp(today)}.csv',
                             ['Invoice', 'Customer', 'Distributor', 'Issued', 'Due', 'Status',
                              'Days overdue', 'Ageing', 'Amount'], out)

    return render(request, 'reports/receivables.html', {
        'section': 'receivables', 'rows': rows, 'aging': aging,
        'owed_total': sum((r['total'] for r in rows), logic.ZERO),
        'today': today,
    })
