from django import forms


class DateRangeForm(forms.Form):
    """Optional issue-date range (inclusive) shared by every report."""

    date_from = forms.DateField(
        required=False, input_formats=['%Y-%m-%d'], label='From',
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'field-input'}),
    )
    date_to = forms.DateField(
        required=False, input_formats=['%Y-%m-%d'], label='To',
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'field-input'}),
    )

    def clean(self):
        cleaned = super().clean()
        start, end = cleaned.get('date_from'), cleaned.get('date_to')
        if start and end and start > end:
            self.add_error('date_to', 'The end date cannot be before the start date.')
        return cleaned


class StockThresholdForm(forms.Form):
    """'Low stock' cut-off for the inventory section of the product report."""

    low_stock = forms.IntegerField(
        required=False, min_value=0, max_value=100000, label='Low stock at or below',
        widget=forms.NumberInput(attrs={'class': 'field-input', 'min': '0'}),
    )
