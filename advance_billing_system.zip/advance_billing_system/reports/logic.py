"""Pure helpers for the reports (no Django imports, so they are trivially testable).

The status strings mirror billing.models.Invoice.STATUS_*; reports/tests.py
asserts they stay in sync.
"""
from datetime import date
from decimal import Decimal

PAID, UNPAID, OVERDUE = 'paid', 'unpaid', 'overdue'
ZERO = Decimal('0.00')

AGING_LABELS = ('Not yet due', '1–30 days', '31–60 days', '61+ days')
# An invoice someone marked 'overdue' by hand but that has no past due date
# can't be aged by days; it gets its own line rather than hiding in 'Not yet due'.
MARKED_OVERDUE = 'Marked overdue'


def effective_status(status, due_date, today):
    """What an invoice really is today.

    Stored status can lag behind reality (nothing flips 'unpaid' to 'overdue'
    automatically), so an unpaid invoice past its due date counts as overdue.
    """
    if status == PAID:
        return PAID
    if status == OVERDUE or (due_date is not None and due_date < today):
        return OVERDUE
    return UNPAID


def days_overdue(due_date, today):
    if due_date is None or due_date >= today:
        return 0
    return (today - due_date).days


def aging_bucket(days):
    """Index into AGING_LABELS for a number of days overdue."""
    if days <= 0:
        return 0
    if days <= 30:
        return 1
    if days <= 60:
        return 2
    return 3


def csv_cell(value):
    """Neutralise spreadsheet formula injection (=, +, -, @ at the start of text).

    Customer and product names are user-typed and end up in files that admins
    open in Excel, so text cells are prefixed with an apostrophe when risky.
    """
    if isinstance(value, Decimal):
        return f'{value:.2f}'
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, str) and value[:1] in ('=', '+', '-', '@', '\t', '\r'):
        return "'" + value
    return value


def bar_pct(value, maximum):
    """Whole-number percentage (0-100) for the inline bars."""
    if not maximum or value <= 0:
        return 0
    return max(1, min(100, int(round(value / maximum * 100))))
