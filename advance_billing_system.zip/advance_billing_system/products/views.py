from decimal import Decimal
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.models import UserProfile

from .forms import ProductForm
from .models import Product


def _is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


UNCATEGORISED = '__none__'

SORT_OPTIONS = (
    ('name', 'Name A–Z', ('name', 'pk')),
    ('name_desc', 'Name Z–A', ('-name', 'pk')),
    ('price', 'Price: low to high', ('price', 'name')),
    ('price_desc', 'Price: high to low', ('-price', 'name')),
    ('stock', 'Stock: low to high', ('stock', 'name')),
    ('stock_desc', 'Stock: high to low', ('-stock', 'name')),
    ('newest', 'Newest first', ('-created_at', '-pk')),
)
SORT_ORDERING = {key: ordering for key, _label, ordering in SORT_OPTIONS}

STOCK_FILTERS = (
    ('', 'All stock levels'),
    ('available', 'In stock'),
    ('low', 'Low stock'),
    ('out', 'Out of stock'),
)


def _catalog_stats(base):
    """Headline numbers for the strip above the list (whole catalog, not the filtered view)."""
    low_limit = Product.LOW_STOCK_THRESHOLD
    rows = list(base.values_list('price', 'stock', 'category'))
    return {
        'total': len(rows),
        'out': sum(1 for _p, stock, _c in rows if stock == 0),
        'low': sum(1 for _p, stock, _c in rows if 0 < stock <= low_limit),
        'value': sum((price * stock for price, stock, _c in rows), Decimal('0')),
        'categories': sorted({c for _p, _s, c in rows if c}, key=str.lower),
        'has_uncategorised': any(not c for _p, _s, c in rows),
        'low_limit': low_limit,
    }


@login_required(login_url='distributor_login')
def product_list_view(request):
    base = Product.objects.select_related('distributor')
    if not _is_admin(request.user):
        base = base.filter(distributor=request.user)

    stats = _catalog_stats(base)
    products = base

    # Every filter is checked against a whitelist; anything unrecognised is
    # ignored (never an error page, never passed to the ORM unchecked).
    query = request.GET.get('q', '').strip()[:100]
    if query:
        products = products.filter(Q(name__icontains=query) | Q(category__icontains=query))

    category = request.GET.get('category', '')
    if category == UNCATEGORISED and stats['has_uncategorised']:
        products = products.filter(category='')
    elif category in stats['categories']:
        products = products.filter(category=category)
    else:
        category = ''

    stock_filter = request.GET.get('stock', '')
    low_limit = Product.LOW_STOCK_THRESHOLD
    if stock_filter == 'available':
        products = products.filter(stock__gt=0)
    elif stock_filter == 'low':
        products = products.filter(stock__gt=0, stock__lte=low_limit)
    elif stock_filter == 'out':
        products = products.filter(stock=0)
    else:
        stock_filter = ''

    sort = request.GET.get('sort', 'name')
    if sort not in SORT_ORDERING:
        sort = 'name'
    products = products.order_by(*SORT_ORDERING[sort])

    view_mode = 'grid' if request.GET.get('view') == 'grid' else 'table'

    # Query string that carries the active filters through pagination links.
    carried = {'q': query, 'category': category, 'stock': stock_filter,
               'sort': sort if sort != 'name' else '', 'view': 'grid' if view_mode == 'grid' else ''}
    carried = {k: v for k, v in carried.items() if v}

    paginator = Paginator(products, 12 if view_mode == 'grid' else 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'products/product_list.html', {
        'page_obj': page_obj,
        'query': query,
        'category': category,
        'stock_filter': stock_filter,
        'sort': sort,
        'view_mode': view_mode,
        'stats': stats,
        'sort_options': [(key, label) for key, label, _o in SORT_OPTIONS],
        'stock_filters': STOCK_FILTERS,
        'uncategorised_value': UNCATEGORISED,
        'filters_active': bool(query or category or stock_filter),
        'filter_qs': urlencode(carried),
        'view_qs': urlencode({k: v for k, v in carried.items() if k != 'view'}),
        'is_admin': _is_admin(request.user),
    })


@login_required(login_url='distributor_login')
def product_create_view(request):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')

    form = ProductForm(request.POST or None, distributor=request.user)
    if request.method == 'POST' and form.is_valid():
        product = form.save(commit=False)
        product.distributor = request.user
        product.save()
        messages.success(request, f'{product.name} added to your catalog.')
        return redirect('product_list')

    return render(request, 'products/product_form.html', {'form': form, 'is_edit': False})


def _visible_or_404(request, pk):
    """Admins may read any product; distributors only their own (others 404)."""
    qs = Product.objects.select_related('distributor')
    if not _is_admin(request.user):
        qs = qs.filter(distributor=request.user)
    return get_object_or_404(qs, pk=pk)


def _owned_or_404(request, pk):
    return get_object_or_404(Product, pk=pk, distributor=request.user)


@login_required(login_url='distributor_login')
def product_detail_view(request, pk):
    product = _visible_or_404(request, pk)
    lines = list(product.invoice_items.select_related('invoice').order_by('-invoice__created_at', '-pk'))
    return render(request, 'products/product_detail.html', {
        'product': product,
        'is_admin': _is_admin(request.user),
        'gst_amount': (product.price * product.gst_rate / 100).quantize(Decimal('0.01')),
        'price_incl': (product.price * (100 + product.gst_rate) / 100).quantize(Decimal('0.01')),
        'units_sold': sum((line.quantity for line in lines), Decimal('0')),
        'net_sales': sum((line.taxable_amount for line in lines), Decimal('0')),
        'invoice_count': len({line.invoice_id for line in lines}),
        'recent_lines': lines[:5],
    })


@login_required(login_url='distributor_login')
def product_update_view(request, pk):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')
    product = _owned_or_404(request, pk)
    form = ProductForm(request.POST or None, instance=product, distributor=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, f'{product.name} updated.')
        return redirect('product_list')
    return render(request, 'products/product_form.html', {'form': form, 'is_edit': True, 'product': product})


@require_POST
@login_required(login_url='distributor_login')
def product_delete_view(request, pk):
    if _is_admin(request.user):
        messages.info(request, 'Products are managed by distributor accounts.')
        return redirect('product_list')
    product = _owned_or_404(request, pk)
    name = product.name
    product.delete()      # existing invoice lines keep their copied description/price (FK is SET_NULL)
    messages.success(request, f'{name} was removed from your catalog.')
    return redirect('product_list')
