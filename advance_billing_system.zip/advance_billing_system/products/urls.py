from django.urls import path

from . import views

urlpatterns = [
    path('', views.product_list_view, name='product_list'),
    path('new/', views.product_create_view, name='product_create'),
    path('<int:pk>/', views.product_detail_view, name='product_detail'),
    path('<int:pk>/edit/', views.product_update_view, name='product_update'),
    path('<int:pk>/delete/', views.product_delete_view, name='product_delete'),
]
