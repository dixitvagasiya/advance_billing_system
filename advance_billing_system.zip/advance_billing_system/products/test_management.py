"""Validation + front-end behaviour for the product management module."""
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import Client, SimpleTestCase, TestCase
from django.urls import reverse
from django.utils import timezone

from accounts.models import UserProfile
from billing.models import Invoice, InvoiceItem

from .forms import ProductForm
from .models import Product

PW = 'Some-Pass-123!'


def make_user(email, role=UserProfile.ROLE_DISTRIBUTOR):
    user = User.objects.create_user(username=email, email=email, password=PW)
    UserProfile.objects.create(user=user, role=role)
    return user


def post_data(**kw):
    data = {'name': 'Widget', 'category': 'Hardware', 'price': '99.50', 'stock': '10', 'gst_rate': '18'}
    data.update(kw)
    return data


def make_product(owner, name, category='', price='10', stock=20, gst='0'):
    return Product.objects.create(distributor=owner, name=name, category=category,
                                  price=Decimal(price), stock=stock, gst_rate=Decimal(gst))


class StockStatusTests(SimpleTestCase):
    def test_boundaries(self):
        status = lambda n: Product(stock=n).stock_status      # noqa: E731
        self.assertEqual([status(0), status(1), status(10), status(11)], ['out', 'low', 'low', 'ok'])


class ProductValidationTests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.other = make_user('d2@x.com')
        self.client.force_login(self.dist)
        self.mine = make_product(self.dist, 'Blue Pen', category='Stationery')

    def _post(self, **kw):
        return self.client.post(reverse('product_create'), post_data(**kw))

    def test_duplicate_name_is_rejected_case_and_space_insensitively(self):
        for dupe in ('Blue Pen', 'blue pen', '  BLUE   PEN  '):
            resp = self._post(name=dupe)
            self.assertEqual(resp.status_code, 200, dupe)
            self.assertContains(resp, 'You already have a product with this name')
        self.assertEqual(Product.objects.filter(distributor=self.dist).count(), 1)

    def test_same_name_is_fine_for_a_different_distributor(self):
        make_product(self.other, 'Red Pen')
        resp = self._post(name='Red Pen')
        self.assertRedirects(resp, reverse('product_list'))

    def test_editing_a_product_does_not_clash_with_itself(self):
        resp = self.client.post(reverse('product_update', args=[self.mine.pk]), post_data(name='blue pen', category='Stationery'))
        self.assertRedirects(resp, reverse('product_list'))
        self.mine.refresh_from_db()
        self.assertEqual(self.mine.name, 'blue pen')

    def test_renaming_onto_another_of_your_products_is_rejected(self):
        make_product(self.dist, 'Gel Pen')
        resp = self.client.post(reverse('product_update', args=[self.mine.pk]), post_data(name='Gel Pen'))
        self.assertContains(resp, 'You already have a product with this name')

    def test_name_whitespace_is_collapsed_and_blank_is_rejected(self):
        self._post(name='  Fancy    Stapler ')
        self.assertTrue(Product.objects.filter(name='Fancy Stapler').exists())
        for blank in ('', '   '):
            self.assertEqual(self._post(name=blank).status_code, 200)
        self.assertFalse(Product.objects.filter(name='').exists())

    def test_name_and_category_length_limits(self):
        self.assertEqual(self._post(name='x' * 151).status_code, 200)
        self.assertEqual(self._post(name='Long Cat', category='c' * 101).status_code, 200)
        self.assertFalse(Product.objects.filter(name__in=('x' * 151, 'Long Cat')).exists())

    def test_category_reuses_existing_spelling(self):
        self._post(name='Gel Pen', category='  stationery ')
        self.assertEqual(Product.objects.get(name='Gel Pen').category, 'Stationery')
        self._post(name='Brand New', category='  Brand   New  Cat ')
        self.assertEqual(Product.objects.get(name='Brand New').category, 'Brand New Cat')

    def test_category_is_optional(self):
        self._post(name='Plain', category='')
        self.assertEqual(Product.objects.get(name='Plain').category, '')

    def test_price_rules(self):
        for bad in ('0', '0.00', '-5', 'abc', '', '12.345', '1' * 13):
            self.assertEqual(self._post(name=f'P{bad}', price=bad).status_code, 200, bad)
        self.assertEqual(Product.objects.filter(distributor=self.dist).count(), 1)
        self.assertRedirects(self._post(name='Cheap', price='0.01'), reverse('product_list'))

    def test_stock_rules(self):
        for bad in ('-1', '1.5', 'abc', ''):
            self.assertEqual(self._post(name=f'S{bad}', stock=bad).status_code, 200, bad)
        self.assertRedirects(self._post(name='Zero', stock='0'), reverse('product_list'))
        self.assertEqual(Product.objects.get(name='Zero').stock, 0)

    def test_gst_rules(self):
        for bad in ('-0.01', '100.01', 'abc', '18.555'):
            self.assertEqual(self._post(name=f'G{bad}', gst_rate=bad).status_code, 200, bad)
        for ok in ('0', '100'):
            self.assertRedirects(self._post(name=f'G{ok}', gst_rate=ok), reverse('product_list'))

    def test_errors_are_shown_next_to_the_field_and_input_is_kept(self):
        resp = self._post(name='Keep Me', price='-3')
        self.assertContains(resp, 'Price must be greater than 0')
        self.assertContains(resp, 'value="Keep Me"')

    def test_ownership_cannot_be_forged_through_the_form(self):
        self._post(name='Mine Now', distributor=self.other.pk)
        self.assertEqual(Product.objects.get(name='Mine Now').distributor, self.dist)

    def test_form_without_a_distributor_still_validates_fields(self):
        form = ProductForm(data=post_data(price='0'))
        self.assertFalse(form.is_valid())
        self.assertIn('price', form.errors)
        self.assertEqual(form.category_choices, [])


class ProductListUITests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.other = make_user('d2@x.com')
        self.admin = make_user('a@x.com', UserProfile.ROLE_ADMIN)
        self.client.force_login(self.dist)
        self.url = reverse('product_list')
        make_product(self.dist, 'Alpha', 'Tools', '300', stock=0)
        make_product(self.dist, 'Bravo', 'Tools', '100', stock=10)
        make_product(self.dist, 'Charlie', 'Toys', '200', stock=11)
        make_product(self.dist, 'Delta', '', '50', stock=1)
        make_product(self.other, 'Secret', 'Hidden', '1', stock=0)

    def names(self, resp):
        return [p.name for p in resp.context['page_obj'].object_list]

    def test_summary_stats(self):
        stats = self.client.get(self.url).context['stats']
        self.assertEqual(stats['total'], 4)
        self.assertEqual(stats['out'], 1)                    # Alpha
        self.assertEqual(stats['low'], 2)                    # Bravo (10) and Delta (1)
        self.assertEqual(stats['categories'], ['Tools', 'Toys'])
        self.assertTrue(stats['has_uncategorised'])
        self.assertEqual(stats['value'], Decimal('0') + 100 * 10 + 200 * 11 + 50 * 1)

    def test_stats_cover_the_whole_catalog_not_the_filtered_view(self):
        resp = self.client.get(self.url, {'q': 'alpha'})
        self.assertEqual(self.names(resp), ['Alpha'])
        self.assertEqual(resp.context['stats']['total'], 4)

    def test_other_distributors_data_never_leaks(self):
        resp = self.client.get(self.url)
        self.assertNotContains(resp, 'Secret')
        self.assertNotContains(resp, 'Hidden')
        self.assertEqual(self.client.get(self.url, {'category': 'Hidden'}).context['category'], '')

    def test_category_filter(self):
        self.assertEqual(self.names(self.client.get(self.url, {'category': 'Tools'})), ['Alpha', 'Bravo'])
        self.assertEqual(self.names(self.client.get(self.url, {'category': '__none__'})), ['Delta'])

    def test_unknown_category_is_ignored_not_an_error(self):
        resp = self.client.get(self.url, {'category': 'Nope'})
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(self.names(resp)), 4)

    def test_stock_filters_and_boundaries(self):
        get = lambda v: self.names(self.client.get(self.url, {'stock': v}))      # noqa: E731
        self.assertEqual(get('out'), ['Alpha'])
        self.assertEqual(get('low'), ['Bravo', 'Delta'])             # 10 is low, 11 is not; 0 is 'out'
        self.assertEqual(get('available'), ['Bravo', 'Charlie', 'Delta'])
        self.assertEqual(len(get('bogus')), 4)

    def test_filters_combine(self):
        resp = self.client.get(self.url, {'category': 'Tools', 'stock': 'low'})
        self.assertEqual(self.names(resp), ['Bravo'])
        self.assertTrue(resp.context['filters_active'])

    def test_sorting(self):
        get = lambda v: self.names(self.client.get(self.url, {'sort': v}))       # noqa: E731
        self.assertEqual(get('price'), ['Delta', 'Bravo', 'Charlie', 'Alpha'])
        self.assertEqual(get('price_desc'), ['Alpha', 'Charlie', 'Bravo', 'Delta'])
        self.assertEqual(get('stock'), ['Alpha', 'Delta', 'Bravo', 'Charlie'])
        self.assertEqual(get('name_desc'), ['Delta', 'Charlie', 'Bravo', 'Alpha'])
        self.assertEqual(get('newest')[0], 'Delta')

    def test_hostile_sort_value_falls_back_to_name(self):
        for bad in ('price; DROP TABLE', '-name,distributor__password', '', 'distributor__password'):
            resp = self.client.get(self.url, {'sort': bad})
            self.assertEqual(resp.status_code, 200, bad)
            self.assertEqual(resp.context['sort'], 'name', bad)
            self.assertEqual(self.names(resp), ['Alpha', 'Bravo', 'Charlie', 'Delta'], bad)

    def test_search_still_matches_name_or_category(self):
        self.assertEqual(self.names(self.client.get(self.url, {'q': 'toys'})), ['Charlie'])
        self.assertEqual(self.names(self.client.get(self.url, {'q': 'ALPH'})), ['Alpha'])

    def test_overlong_search_is_truncated_safely(self):
        self.assertEqual(self.client.get(self.url, {'q': 'a' * 5000}).status_code, 200)

    def test_table_and_card_layouts(self):
        table = self.client.get(self.url)
        self.assertEqual(table.context['view_mode'], 'table')
        self.assertContains(table, 'invoice-table')
        self.assertNotContains(table, 'product-grid')
        grid = self.client.get(self.url, {'view': 'grid'})
        self.assertEqual(grid.context['view_mode'], 'grid')
        self.assertContains(grid, 'product-grid')
        self.assertContains(grid, reverse('product_update', args=[Product.objects.get(name='Alpha').pk]))
        self.assertEqual(self.client.get(self.url, {'view': 'weird'}).context['view_mode'], 'table')

    def test_stock_badges(self):
        html = self.client.get(self.url).content.decode()
        self.assertIn('0 · out', html)
        self.assertIn('10 · low', html)
        self.assertIn('>11<', html)

    def test_pagination_keeps_the_active_filters(self):
        for n in range(20):
            make_product(self.dist, f'Bulk {n:02d}', 'Bulk')
        resp = self.client.get(self.url, {'category': 'Bulk', 'sort': 'price'})
        self.assertEqual(resp.context['page_obj'].paginator.num_pages, 2)
        self.assertContains(resp, 'category=Bulk&amp;sort=price&amp;page=2')
        page2 = self.client.get(self.url, {'category': 'Bulk', 'sort': 'price', 'page': 2})
        self.assertEqual(len(self.names(page2)), 5)

    def test_bad_page_numbers_do_not_crash(self):
        for page in ('0', '-1', 'x', '999'):
            self.assertEqual(self.client.get(self.url, {'page': page}).status_code, 200, page)

    def test_empty_states(self):
        self.assertContains(self.client.get(self.url, {'q': 'zzz'}), 'No products match your filters')
        fresh = Client(); fresh.force_login(make_user('new@x.com'))
        self.assertContains(fresh.get(self.url), 'Your catalog is empty')

    def test_product_names_are_html_escaped(self):
        make_product(self.dist, '<script>alert(1)</script>', '<b>x</b>')
        for params in ({}, {'view': 'grid'}):
            resp = self.client.get(self.url, params)
            self.assertNotContains(resp, '<script>alert(1)</script>')
            self.assertContains(resp, '&lt;script&gt;alert(1)&lt;/script&gt;')

    def test_admin_sees_every_catalog_but_gets_no_edit_controls(self):
        c = Client(); c.force_login(self.admin)
        resp = c.get(self.url)
        self.assertEqual(resp.context['stats']['total'], 5)
        self.assertContains(resp, 'Secret')
        for p in Product.objects.all():
            self.assertNotContains(resp, reverse('product_delete', args=[p.pk]))
        grid = c.get(self.url, {'view': 'grid'})
        self.assertNotContains(grid, reverse('product_update', args=[Product.objects.get(name='Alpha').pk]))

    def test_page_loads_its_script(self):
        self.assertContains(self.client.get(self.url), 'product_list.js')


class ProductFormUITests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.other = make_user('d2@x.com')
        self.client.force_login(self.dist)
        make_product(self.dist, 'Alpha', 'Tools')
        make_product(self.other, 'Secret', 'Hidden')

    def test_category_suggestions_are_only_your_own(self):
        resp = self.client.get(reverse('product_create'))
        self.assertContains(resp, '<option value="Tools">')
        self.assertNotContains(resp, 'Hidden')

    def test_preview_panel_and_script_are_present(self):
        resp = self.client.get(reverse('product_create'))
        for needle in ('id="product-preview"', 'product_form.js', 'data-preview="incl"', 'id="product-form"'):
            self.assertContains(resp, needle)

    def test_edit_form_is_prefilled(self):
        p = Product.objects.get(name='Alpha')
        resp = self.client.get(reverse('product_update', args=[p.pk]))
        self.assertContains(resp, 'value="Alpha"')
        self.assertContains(resp, 'Save changes')


class ProductDetailUITests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.client.force_login(self.dist)
        self.p = make_product(self.dist, 'Alpha', price='100', stock=3, gst='18')

    def _bill(self, qty, disc='0'):
        inv = Invoice.objects.create(distributor=self.dist, customer_name='Acme', issue_date=timezone.localdate())
        InvoiceItem.objects.create(invoice=inv, product=self.p, description='Alpha', quantity=Decimal(qty),
                                   unit_price=Decimal('100'), discount_percent=Decimal(disc), gst_percent=Decimal('18'))
        return inv

    def test_sales_summary(self):
        self._bill(2)
        last = self._bill(3, disc='10')
        resp = self.client.get(reverse('product_detail', args=[self.p.pk]))
        self.assertEqual(resp.context['units_sold'], Decimal('5'))
        self.assertEqual(resp.context['net_sales'], Decimal('470.00'))
        self.assertEqual(resp.context['invoice_count'], 2)
        self.assertEqual(resp.context['recent_lines'][0].invoice, last)       # newest first
        self.assertContains(resp, last.invoice_number)

    def test_unbilled_product(self):
        resp = self.client.get(reverse('product_detail', args=[self.p.pk]))
        self.assertEqual((resp.context['units_sold'], resp.context['invoice_count']), (Decimal('0'), 0))
        self.assertContains(resp, 'has not been billed yet')

    def test_low_stock_label(self):
        self.assertContains(self.client.get(reverse('product_detail', args=[self.p.pk])), 'low stock')

    def test_gst_arithmetic_is_unchanged(self):
        resp = self.client.get(reverse('product_detail', args=[self.p.pk]))
        self.assertContains(resp, '₹118.00')
