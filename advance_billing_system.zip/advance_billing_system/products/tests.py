from decimal import Decimal

from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse

from accounts.models import UserProfile

from .models import Product

PW = 'Some-Pass-123!'


def make_user(email, role=UserProfile.ROLE_DISTRIBUTOR):
    u = User.objects.create_user(username=email, email=email, password=PW)
    UserProfile.objects.create(user=u, role=role)
    return u


def data(**kw):
    d = {'name': 'Widget', 'category': 'Hardware', 'price': '99.50', 'stock': '10', 'gst_rate': '18'}
    d.update(kw)
    return d


class ProductCRUDTests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.other = make_user('d2@x.com')
        self.admin = make_user('a@x.com', UserProfile.ROLE_ADMIN)
        self.client.force_login(self.dist)
        self.mine = Product.objects.create(distributor=self.dist, name='Mine', price=Decimal('100'), stock=5, gst_rate=Decimal('12'))
        self.theirs = Product.objects.create(distributor=self.other, name='Theirs', price=Decimal('50'), stock=1)

    # ---- Create
    def test_create(self):
        resp = self.client.post(reverse('product_create'), data())
        self.assertRedirects(resp, reverse('product_list'))
        p = Product.objects.get(name='Widget')
        self.assertEqual((p.distributor, p.price, p.stock, p.gst_rate), (self.dist, Decimal('99.50'), 10, Decimal('18')))

    def test_create_validation(self):
        for bad in ({'price': '0'}, {'price': '-1'}, {'stock': '-1'}, {'gst_rate': '101'}, {'name': ''}):
            resp = self.client.post(reverse('product_create'), data(**bad))
            self.assertEqual(resp.status_code, 200, bad)
        self.assertEqual(Product.objects.filter(distributor=self.dist).count(), 1)

    # ---- Read
    def test_list_shows_only_own_products_with_actions(self):
        resp = self.client.get(reverse('product_list'))
        self.assertContains(resp, 'Mine')
        self.assertNotContains(resp, 'Theirs')
        self.assertContains(resp, reverse('product_update', args=[self.mine.pk]))
        self.assertContains(resp, reverse('product_delete', args=[self.mine.pk]))

    def test_list_search(self):
        Product.objects.create(distributor=self.dist, name='Gadget', category='Tools', price=1)
        resp = self.client.get(reverse('product_list'), {'q': 'tool'})
        self.assertContains(resp, 'Gadget')
        self.assertNotContains(resp, '>Mine<')

    def test_detail_shows_gst_maths(self):
        resp = self.client.get(reverse('product_detail', args=[self.mine.pk]))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, '₹100.00')
        self.assertContains(resp, '₹12.00')        # GST amount
        self.assertContains(resp, '₹112.00')       # incl. GST

    def test_detail_of_another_distributors_product_is_404(self):
        self.assertEqual(self.client.get(reverse('product_detail', args=[self.theirs.pk])).status_code, 404)

    # ---- Update
    def test_update(self):
        resp = self.client.post(reverse('product_update', args=[self.mine.pk]), data(name='Mine v2', price='120.00'))
        self.assertRedirects(resp, reverse('product_list'))
        self.mine.refresh_from_db()
        self.assertEqual((self.mine.name, self.mine.price), ('Mine v2', Decimal('120.00')))
        self.assertEqual(self.mine.distributor, self.dist)

    def test_update_form_prefilled_and_validated(self):
        resp = self.client.get(reverse('product_update', args=[self.mine.pk]))
        self.assertContains(resp, 'value="Mine"')
        resp = self.client.post(reverse('product_update', args=[self.mine.pk]), data(price='0'))
        self.assertContains(resp, 'Price must be greater than 0')
        self.mine.refresh_from_db()
        self.assertEqual(self.mine.price, Decimal('100.00'))

    def test_cannot_update_others_product(self):
        resp = self.client.post(reverse('product_update', args=[self.theirs.pk]), data(name='Hacked'))
        self.assertEqual(resp.status_code, 404)
        self.theirs.refresh_from_db()
        self.assertEqual(self.theirs.name, 'Theirs')

    # ---- Delete
    def test_delete_requires_post(self):
        self.assertEqual(self.client.get(reverse('product_delete', args=[self.mine.pk])).status_code, 405)
        self.assertTrue(Product.objects.filter(pk=self.mine.pk).exists())

    def test_delete(self):
        resp = self.client.post(reverse('product_delete', args=[self.mine.pk]), follow=True)
        self.assertRedirects(resp, reverse('product_list'))
        self.assertFalse(Product.objects.filter(pk=self.mine.pk).exists())
        self.assertContains(resp, 'removed from your catalog')

    def test_cannot_delete_others_product(self):
        self.assertEqual(self.client.post(reverse('product_delete', args=[self.theirs.pk])).status_code, 404)
        self.assertTrue(Product.objects.filter(pk=self.theirs.pk).exists())

    def test_deleting_a_product_keeps_invoice_lines(self):
        from billing.models import Invoice, InvoiceItem
        inv = Invoice.objects.create(distributor=self.dist, customer_name='Cust', due_date='2030-01-01')
        item = InvoiceItem.objects.create(invoice=inv, product=self.mine, description='Mine', quantity=2, unit_price=Decimal('100'))
        self.client.post(reverse('product_delete', args=[self.mine.pk]))
        item.refresh_from_db()
        self.assertIsNone(item.product)
        self.assertEqual(item.description, 'Mine')

    # ---- Auth / roles
    def test_login_required_everywhere(self):
        anon = Client()
        for name, args in (('product_list', []), ('product_create', []), ('product_detail', [self.mine.pk]),
                           ('product_update', [self.mine.pk]), ('product_delete', [self.mine.pk])):
            resp = anon.get(reverse(name, args=args))
            self.assertIn(resp.status_code, (302, 405), name)
            if resp.status_code == 302:
                self.assertIn('login', resp.url)
        anon.post(reverse('product_delete', args=[self.mine.pk]))
        self.assertTrue(Product.objects.filter(pk=self.mine.pk).exists())

    def test_admin_can_read_all_but_not_modify(self):
        c = Client(); c.force_login(self.admin)
        self.assertContains(c.get(reverse('product_list')), 'Theirs')
        self.assertEqual(c.get(reverse('product_detail', args=[self.theirs.pk])).status_code, 200)
        self.assertNotContains(c.get(reverse('product_list')), reverse('product_delete', args=[self.theirs.pk]))
        c.post(reverse('product_update', args=[self.theirs.pk]), data(name='Admin edit'))
        c.post(reverse('product_delete', args=[self.theirs.pk]))
        self.theirs.refresh_from_db()
        self.assertEqual(self.theirs.name, 'Theirs')
