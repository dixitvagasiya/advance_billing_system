from django import forms

from .models import Product


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'category', 'price', 'stock', 'gst_rate']

    def __init__(self, *args, distributor=None, **kwargs):
        super().__init__(*args, **kwargs)

        # Whose catalog this product belongs to (needed for the duplicate-name
        # check and for suggesting categories they already use).
        if distributor is None and self.instance.distributor_id:
            distributor = self.instance.distributor
        self.distributor = distributor
        self.category_choices = []
        if distributor is not None:
            self.category_choices = list(
                Product.objects.filter(distributor=distributor).exclude(category='')
                .order_by('category').values_list('category', flat=True).distinct()
            )

        self.fields['name'].widget.attrs.update({'class': 'field-input', 'placeholder': 'Product or SKU name', 'autofocus': True})
        self.fields['category'].widget.attrs.update({'class': 'field-input', 'placeholder': 'e.g. Electronics',
                                                     'list': 'category-options', 'autocomplete': 'off'})
        self.fields['price'].widget.attrs.update({'class': 'field-input', 'placeholder': '0.00', 'step': '0.01', 'min': '0.01'})
        self.fields['stock'].widget.attrs.update({'class': 'field-input', 'placeholder': '0', 'min': '0'})
        self.fields['gst_rate'].widget.attrs.update({'class': 'field-input', 'placeholder': '0', 'step': '0.01', 'min': '0', 'max': '100'})
        self.fields['category'].required = False

    def clean_name(self):
        # Collapse stray spaces ("  Blue   Pen " -> "Blue Pen") so lookalike names match.
        name = ' '.join(self.cleaned_data['name'].split())
        if not name:
            raise forms.ValidationError('Enter a product name.')
        if self.distributor is not None:
            clash = Product.objects.filter(distributor=self.distributor, name__iexact=name)
            if self.instance.pk:
                clash = clash.exclude(pk=self.instance.pk)
            if clash.exists():
                raise forms.ValidationError('You already have a product with this name.')
        return name

    def clean_category(self):
        category = ' '.join((self.cleaned_data.get('category') or '').split())
        # Reuse the spelling already in the catalog so "electronics" and
        # "Electronics" don't become two separate filter entries.
        existing = {c.lower(): c for c in self.category_choices}
        return existing.get(category.lower(), category)

    def clean_price(self):
        price = self.cleaned_data['price']
        if price <= 0:
            raise forms.ValidationError('Price must be greater than 0.')
        return price

    def clean_stock(self):
        stock = self.cleaned_data['stock']
        if stock < 0:
            raise forms.ValidationError('Stock cannot be negative.')
        return stock
