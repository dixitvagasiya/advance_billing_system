"""JSON API for customers.

POST /customers/api/register/
    Register a customer in the signed-in Distributor's own customer book.

    Auth      Session cookie of a logged-in Distributor. CSRF IS enforced, so
              browser callers send the token in the `X-CSRFToken` header
              (the front-end form does this automatically).

    Request   Content-Type: application/json
        {
          "name":    "Acme Traders",            // required
          "email":   "accounts@acme.example",   // optional, unique per distributor
          "phone":   "+919876543210",           // optional, 7-15 digits, unique per distributor
          "address": "12 Market Road, Jamnagar",// optional
          "notes":   "Pays on the 5th"          // optional
        }

    Responses
        201 {"id", "name", "email", "phone", "address", "notes", "created_at"}
            + Location header pointing at the edit page
        400 {"errors": {"<field>": ["message", ...]}}   validation problems
            {"error": "..."}                            malformed body
        401 {"error": "..."}   not signed in
        403 {"error": "..."}   signed in but not a Distributor, or missing/invalid CSRF token
        405 {"error": "..."}   any method other than POST
        415 {"error": "..."}   body is not application/json
"""
import json

from django.http import JsonResponse
from django.urls import reverse
from django.views.decorators.csrf import csrf_protect

from accounts.models import UserProfile

from .forms import CustomerForm

_FIELDS = ('name', 'email', 'phone', 'address', 'notes')


def _error(message, status, **headers):
    response = JsonResponse({'error': message}, status=status)
    for name, value in headers.items():
        response[name.replace('_', '-')] = value
    return response


def serialize(customer):
    return {
        'id': customer.pk,
        'name': customer.name,
        'email': customer.email,
        'phone': customer.phone,
        'address': customer.address,
        'notes': customer.notes,
        'created_at': customer.created_at.isoformat(),
    }


@csrf_protect
def register_customer(request):
    if request.method != 'POST':
        return _error('Method not allowed. Use POST.', 405, Allow='POST')

    user = request.user
    if not user.is_authenticated:
        return _error('Authentication required. Sign in as a distributor.', 401)
    if not (hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_DISTRIBUTOR):
        return _error('Only distributor accounts can register customers.', 403)

    if 'application/json' not in request.headers.get('Content-Type', ''):
        return _error('Content-Type must be application/json.', 415)
    try:
        data = json.loads(request.body or b'')
    except (ValueError, UnicodeDecodeError):
        return _error('Request body must be valid JSON.', 400)
    if not isinstance(data, dict):
        return _error('Request body must be a JSON object.', 400)

    # Only whitelisted fields reach the form; non-strings are rejected rather than coerced.
    payload = {}
    for field in _FIELDS:
        value = data.get(field, '')
        if value is None:
            value = ''
        if not isinstance(value, str):
            return JsonResponse({'errors': {field: ['Must be a string.']}}, status=400)
        payload[field] = value

    form = CustomerForm(payload, distributor=user)
    if not form.is_valid():
        return JsonResponse({'errors': {f: list(e) for f, e in form.errors.items()}}, status=400)

    customer = form.save(commit=False)
    customer.distributor = user          # never taken from the request body
    customer.save()

    response = JsonResponse(serialize(customer), status=201)
    response['Location'] = reverse('customer_update', args=[customer.pk])
    return response
