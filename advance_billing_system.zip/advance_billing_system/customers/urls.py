from django.urls import path

from . import api, views

urlpatterns = [
    path('', views.customer_list_view, name='customer_list'),
    path('api/register/', api.register_customer, name='api_customer_register'),
    path('new/', views.customer_create_view, name='customer_create'),
    path('<int:pk>/edit/', views.customer_update_view, name='customer_update'),
    path('<int:pk>/delete/', views.customer_delete_view, name='customer_delete'),
]
