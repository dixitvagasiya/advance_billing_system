import json

from django.contrib.auth.models import User
from django.test import Client, TestCase
from django.urls import reverse

from accounts.models import UserProfile

from .models import Customer

PW = 'Some-Pass-123!'


def make_user(email, role=UserProfile.ROLE_DISTRIBUTOR):
    u = User.objects.create_user(username=email, email=email, password=PW)
    UserProfile.objects.create(user=u, role=role)
    return u


class CustomerRegistrationAPITests(TestCase):
    url = '/customers/api/register/'

    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.other = make_user('d2@x.com')
        self.client.force_login(self.dist)

    def post(self, data, client=None, **extra):
        return (client or self.client).post(self.url, json.dumps(data), content_type='application/json', **extra)

    def test_registers_customer_for_signed_in_distributor(self):
        resp = self.post({'name': 'Acme  Traders', 'email': 'A@Acme.com', 'phone': '+919876543210',
                          'address': '12 Market Rd', 'notes': 'Pays on 5th'})
        self.assertEqual(resp.status_code, 201)
        body = resp.json()
        self.assertEqual(body['name'], 'Acme Traders')           # whitespace collapsed
        self.assertEqual(body['email'], 'a@acme.com')            # lower-cased
        c = Customer.objects.get(pk=body['id'])
        self.assertEqual(c.distributor, self.dist)
        self.assertTrue(resp['Location'].endswith(f'/customers/{c.pk}/edit/'))

    def test_only_name_is_required(self):
        self.assertEqual(self.post({'name': 'Solo'}).status_code, 201)
        resp = self.post({})
        self.assertEqual(resp.status_code, 400)
        self.assertIn('name', resp.json()['errors'])

    def test_validation_errors(self):
        resp = self.post({'name': 'X', 'email': 'nope', 'phone': 'abc'})
        self.assertEqual(resp.status_code, 400)
        errs = resp.json()['errors']
        self.assertIn('email', errs)
        self.assertIn('phone', errs)
        self.assertEqual(Customer.objects.count(), 0)

    def test_duplicates_scoped_to_the_distributor(self):
        self.post({'name': 'A', 'email': 'dup@c.com', 'phone': '+919000000001'})
        resp = self.post({'name': 'B', 'email': 'DUP@c.com', 'phone': '+919000000002'})
        self.assertIn('email', resp.json()['errors'])
        resp = self.post({'name': 'C', 'phone': '+919000000001'})
        self.assertIn('phone', resp.json()['errors'])
        # a different distributor may register the same person
        c2 = Client(); c2.force_login(self.other)
        self.assertEqual(self.post({'name': 'A', 'email': 'dup@c.com'}, client=c2).status_code, 201)

    def test_distributor_cannot_be_spoofed_from_body(self):
        resp = self.post({'name': 'Sneaky', 'distributor': self.other.pk, 'distributor_id': self.other.pk})
        self.assertEqual(resp.status_code, 201)
        self.assertEqual(Customer.objects.get(pk=resp.json()['id']).distributor, self.dist)

    def test_requires_login(self):
        resp = self.post({'name': 'X'}, client=Client())
        self.assertEqual(resp.status_code, 401)
        self.assertEqual(Customer.objects.count(), 0)

    def test_admins_are_refused(self):
        admin = make_user('a@x.com', UserProfile.ROLE_ADMIN)
        c = Client(); c.force_login(admin)
        self.assertEqual(self.post({'name': 'X'}, client=c).status_code, 403)

    def test_csrf_is_enforced(self):
        c = Client(enforce_csrf_checks=True); c.force_login(self.dist)
        self.assertEqual(self.post({'name': 'X'}, client=c).status_code, 403)
        self.assertEqual(Customer.objects.count(), 0)

    def test_csrf_header_accepted(self):
        c = Client(enforce_csrf_checks=True); c.force_login(self.dist)
        token = c.get(reverse('customer_create')).cookies['csrftoken'].value
        resp = self.post({'name': 'With token'}, client=c, HTTP_X_CSRFTOKEN=token)
        self.assertEqual(resp.status_code, 201)

    def test_method_content_type_and_body_checks(self):
        resp = self.client.get(self.url)
        self.assertEqual((resp.status_code, resp['Allow']), (405, 'POST'))
        self.assertEqual(self.client.post(self.url, 'name=x', content_type='application/x-www-form-urlencoded').status_code, 415)
        self.assertEqual(self.client.post(self.url, '{bad', content_type='application/json').status_code, 400)
        self.assertEqual(self.client.post(self.url, '[1]', content_type='application/json').status_code, 400)
        resp = self.post({'name': ['x']})
        self.assertEqual(resp.status_code, 400)

    def test_oversize_name_rejected(self):
        self.assertEqual(self.post({'name': 'x' * 151}).status_code, 400)


class CustomerFormPageTests(TestCase):
    def setUp(self):
        self.dist = make_user('d1@x.com')
        self.client.force_login(self.dist)

    def test_registration_form_renders_with_api_hook(self):
        resp = self.client.get(reverse('customer_create'))
        self.assertEqual(resp.status_code, 200)
        for f in ('name', 'email', 'phone', 'address', 'notes'):
            self.assertContains(resp, f'name="{f}"')
        self.assertContains(resp, 'data-api="/customers/api/register/"')
        self.assertContains(resp, 'customer_form.js')
        self.assertContains(resp, 'csrfmiddlewaretoken')

    def test_no_js_fallback_posts_normally(self):
        resp = self.client.post(reverse('customer_create'), {'name': 'Plain Co', 'phone': '+919111111111'})
        self.assertRedirects(resp, reverse('customer_list'))
        self.assertTrue(Customer.objects.filter(name='Plain Co', distributor=self.dist).exists())

    def test_register_and_add_another_goes_back_to_form(self):
        resp = self.client.post(reverse('customer_create'), {'name': 'One', 'again': '1'})
        self.assertRedirects(resp, reverse('customer_create'))

    def test_form_page_shows_server_errors(self):
        resp = self.client.post(reverse('customer_create'), {'name': '', 'email': 'bad'})
        self.assertContains(resp, 'This field is required')

    def test_edit_form_has_no_api_hook_and_enforces_uniqueness(self):
        a = Customer.objects.create(distributor=self.dist, name='A', email='a@c.com')
        b = Customer.objects.create(distributor=self.dist, name='B', email='b@c.com')
        resp = self.client.get(reverse('customer_update', args=[a.pk]))
        self.assertNotContains(resp, 'data-api')
        resp = self.client.post(reverse('customer_update', args=[b.pk]), {'name': 'B', 'email': 'a@c.com'})
        self.assertContains(resp, 'already have a customer with this email')
        resp = self.client.post(reverse('customer_update', args=[b.pk]), {'name': 'B2', 'email': 'b@c.com'})
        self.assertRedirects(resp, reverse('customer_list'))   # keeping own email is fine

    def test_other_distributors_customer_is_404(self):
        other = make_user('d2@x.com')
        c = Customer.objects.create(distributor=other, name='Theirs')
        self.assertEqual(self.client.get(reverse('customer_update', args=[c.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse('customer_delete', args=[c.pk])).status_code, 404)
        self.assertTrue(Customer.objects.filter(pk=c.pk).exists())
