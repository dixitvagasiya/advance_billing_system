# Configure OTP email delivery

The password-recovery OTP is sent through Django's SMTP email backend. The app no longer uses Django's console email backend by default. Without real SMTP sender credentials, an email cannot be delivered; the recovery form now displays an error instead of claiming an OTP was sent.

## Gmail SMTP setup (Windows / local development)

1. Open the `advance_billing_system` folder (the same folder that contains `manage.py`).
2. Copy `.env.example` to a new file named `.env`.
3. In `.env`, set `EMAIL_HOST_USER` to your sending Gmail address.
4. Create a Google App Password for that account and put it in `EMAIL_HOST_PASSWORD`. Do not use your normal Gmail account password. Paste the app password without spaces. Google may require 2-Step Verification to be enabled before App Passwords are available.
5. Change `DEFAULT_FROM_EMAIL` so it uses the same sender address, save the file, and restart Django.
6. Submit the Admin login page's **Forgot password?** form using the email address of an existing Admin account. Check the mailbox's Inbox and Spam/Junk folders.

Example values (replace every placeholder):

```dotenv
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=true
EMAIL_USE_SSL=false
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-16-character-app-password
DEFAULT_FROM_EMAIL=Advance Billing System <your-email@gmail.com>
EMAIL_TIMEOUT=15
```

The project reads a local `.env` file automatically (no third-party dotenv package is needed). Environment variables set in Windows/your hosting service take precedence over values in `.env`. Do not share or commit `.env`; it contains private email credentials. The `.env.example` file is safe to keep as a template.

## Other email providers

Replace `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USE_TLS`, `EMAIL_USE_SSL`, the sender address, and credentials with the values supplied by your email provider. Usually choose either TLS on port 587 or SSL on port 465, not both.

## Run the tests

From the folder containing `manage.py`, run:

```bash
python manage.py test accounts
```

The automated recovery tests override the email backend with Django's in-memory test backend, so tests do not send real email.
