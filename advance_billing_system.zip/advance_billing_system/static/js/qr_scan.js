/* QR upload page: posts the chosen image to the decode endpoint and shows the result.
 * All server text is inserted with textContent (never innerHTML). */
(function () {
  'use strict';
  var root = document.getElementById('qr-scan');
  if (!root) return;

  var form = document.getElementById('qr-form');
  var input = document.getElementById('qr-image');
  var button = document.getElementById('qr-submit');
  var statusBox = document.getElementById('qr-status');
  var results = document.getElementById('qr-results');
  var previewWrap = document.getElementById('qr-preview-wrap');
  var preview = document.getElementById('qr-preview');
  var MAX_BYTES = 5 * 1024 * 1024;

  function setStatus(message, isError) {
    statusBox.textContent = message || '';
    statusBox.className = isError ? 'field-error' : 'range-note';
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function renderCode(code) {
    var card = el('div', 'card-panel');
    if (code.invoice) {
      var inv = code.invoice;
      card.appendChild(el('div', 'preview-label', 'Invoice found'));
      var link = el('a', 'link', inv.invoice_number);
      link.href = inv.url;
      var title = el('div', 'preview-name');
      title.appendChild(link);
      card.appendChild(title);
      card.appendChild(el('div', 'preview-cat', inv.customer_name + ' \u00b7 ' + inv.issue_date + ' \u00b7 ' + inv.status));
      card.appendChild(el('div', 'preview-price', '\u20b9' + inv.total));
      if (!inv.qr_is_current) {
        card.appendChild(el('div', 'field-error', 'This invoice was changed after the QR code was made. Trust the invoice, not the code.'));
      }
    } else if (code.is_invoice_qr) {
      card.appendChild(el('div', 'preview-label', 'Invoice not found'));
      card.appendChild(el('div', 'preview-cat', 'This looks like an invoice QR code, but no matching invoice is available to your account.'));
    } else {
      card.appendChild(el('div', 'preview-label', 'QR code text'));
    }
    card.appendChild(el('pre', 'qr-payload', code.text));
    return card;
  }

  input.addEventListener('change', function () {
    results.textContent = '';
    setStatus('');
    var file = input.files[0];
    if (!file) { previewWrap.hidden = true; return; }
    preview.src = URL.createObjectURL(file);
    previewWrap.hidden = false;
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    results.textContent = '';
    var file = input.files[0];
    if (!file) { setStatus('Choose an image first.', true); return; }
    if (file.size > MAX_BYTES) { setStatus('That image is larger than 5 MB.', true); return; }

    var body = new FormData();
    body.append('image', file);
    button.disabled = true;
    setStatus('Reading\u2026');

    fetch(root.dataset.endpoint, {
      method: 'POST',
      body: body,
      credentials: 'same-origin',
      headers: { 'X-CSRFToken': form.elements['csrfmiddlewaretoken'].value, 'Accept': 'application/json' }
    })
      .then(function (response) {
        return response.json().catch(function () { return {}; }).then(function (data) { return { ok: response.ok, data: data }; });
      })
      .then(function (r) {
        if (!r.ok || !r.data.ok) { setStatus(r.data.message || 'Something went wrong. Please try again.', true); return; }
        setStatus(r.data.count === 1 ? 'Found 1 QR code.' : 'Found ' + r.data.count + ' QR codes.');
        r.data.codes.forEach(function (code) { results.appendChild(renderCode(code)); });
      })
      .catch(function () { setStatus('Could not reach the server. Check your connection.', true); })
      .then(function () { button.disabled = false; });
  });
})();
