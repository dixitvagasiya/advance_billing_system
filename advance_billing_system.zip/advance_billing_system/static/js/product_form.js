/* Product form: live preview of how the product will look and what it costs
 * with GST. Purely a convenience; the server re-validates everything. */
(function () {
  'use strict';
  var form = document.getElementById('product-form');
  var preview = document.getElementById('product-preview');
  if (!form || !preview) return;

  var LOW_STOCK = 10;
  var fields = {
    name: form.elements['name'],
    category: form.elements['category'],
    price: form.elements['price'],
    stock: form.elements['stock'],
    gst: form.elements['gst_rate']
  };

  function out(key) { return preview.querySelector('[data-preview="' + key + '"]'); }
  function num(input) {
    var n = parseFloat(input.value);
    return isFinite(n) ? n : 0;
  }
  function money(n) {
    // round half up to 2 dp, like the server
    var r = Math.round((n + Number.EPSILON) * 100) / 100;
    return '₹' + r.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function setError(input, message) {
    var group = input.closest('.field-group');
    var box = group.querySelector('.js-hint');
    if (!message) { if (box) box.remove(); input.removeAttribute('aria-invalid'); return; }
    if (!box) {
      box = document.createElement('div');
      box.className = 'field-error js-hint';
      group.appendChild(box);
    }
    box.textContent = message;
    input.setAttribute('aria-invalid', 'true');
  }

  function update() {
    var price = Math.max(num(fields.price), 0);
    var gstRate = Math.min(Math.max(num(fields.gst), 0), 100);
    var stock = Math.max(Math.floor(num(fields.stock)), 0);
    var gst = Math.round((price * gstRate / 100 + Number.EPSILON) * 100) / 100;

    out('name').textContent = fields.name.value.trim() || 'Product name';
    out('category').textContent = fields.category.value.trim() || 'Uncategorised';
    out('price').textContent = money(price);
    out('gst').textContent = money(gst);
    out('incl').textContent = money(price + gst);

    var tag = out('stock');
    tag.className = 'tag ' + (stock === 0 ? 'low' : stock <= LOW_STOCK ? 'warn' : 'ok');
    tag.textContent = stock === 0 ? 'Out of stock' : stock <= LOW_STOCK ? stock + ' left' : stock + ' in stock';
  }

  // Gentle inline hints once a field has been touched (server remains the authority).
  function hint(input, check) {
    input.addEventListener('blur', function () { setError(input, check(input.value)); });
    input.addEventListener('input', function () { if (input.getAttribute('aria-invalid')) setError(input, check(input.value)); });
  }
  hint(fields.price, function (v) { return v !== '' && !(parseFloat(v) > 0) ? 'Price must be greater than 0.' : ''; });
  hint(fields.stock, function (v) { return v !== '' && (parseFloat(v) < 0 || v.indexOf('.') !== -1) ? 'Stock must be a whole number, 0 or more.' : ''; });
  hint(fields.gst, function (v) { var n = parseFloat(v); return v !== '' && (n < 0 || n > 100) ? 'GST must be between 0 and 100.' : ''; });

  Object.keys(fields).forEach(function (k) { fields[k].addEventListener('input', update); });
  update();
})();
