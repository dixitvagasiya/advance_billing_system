/* effects.js — small progressive-enhancement layer for effects.css.
 * Nothing here is required for the site to work. */
(function () {
  'use strict';
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Button ripple */
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('button.btn-gold, .btn-primary, .btn-secondary, .btn-danger');
    if (!btn || reduce) return;
    var rect = btn.getBoundingClientRect();
    var size = Math.max(rect.width, rect.height);
    var dot = document.createElement('span');
    dot.className = 'ripple';
    dot.style.width = dot.style.height = size + 'px';
    dot.style.left = (e.clientX - rect.left - size / 2) + 'px';
    dot.style.top = (e.clientY - rect.top - size / 2) + 'px';
    btn.appendChild(dot);
    setTimeout(function () { dot.remove(); }, 700);
  });

  /* Pointer spotlight on stat cards */
  document.querySelectorAll('.stat-cell').forEach(function (el) {
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect();
      el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
  });

  /* Count-up for numeric stat values (₹1,234.50 / 12) */
  if (!reduce) {
    document.querySelectorAll('.stat-value').forEach(function (el) {
      var text = el.textContent.trim();
      var m = text.match(/^(\D*)([\d,]+(?:\.\d+)?)(.*)$/);
      if (!m) return;
      var target = parseFloat(m[2].replace(/,/g, ''));
      if (!isFinite(target) || target === 0) return;
      var decimals = (m[2].split('.')[1] || '').length;
      var start = null, dur = 900;
      function fmt(v) { return v.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }); }
      el.textContent = m[1] + fmt(0) + m[3];
      function step(ts) {
        if (start === null) start = ts;
        var p = Math.min((ts - start) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = m[1] + fmt(target * eased) + m[3];
        if (p < 1) requestAnimationFrame(step); else el.textContent = text;
      }
      requestAnimationFrame(step);
    });
  }

  /* Scroll reveal */
  var reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold: .15 });
    reveals.forEach(function (el) { io.observe(el); });
  } else { reveals.forEach(function (el) { el.classList.add('in'); }); }

  /* Mobile nav toggle */
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* Mark errors on fields so CSS can colour the underline */
  document.querySelectorAll('.field, .field-group').forEach(function (g) {
    var e = g.querySelector('.errorlist, .field-error');
    if (e && e.textContent.trim()) g.classList.add('has-error');
  });

  /* Confirm-before-delete forms: <form data-confirm="Delete X?"> */
  document.addEventListener('submit', function (e) {
    var msg = e.target.getAttribute && e.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  });
})();
