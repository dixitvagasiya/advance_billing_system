/* Admin registration page: show/hide password, strength meter + checklist,
 * live "passwords match" message. Purely progressive enhancement: the form
 * posts normally and the server does all real validation. */
(function () {
  'use strict';

  var form = document.getElementById('admin-register-form');
  if (!form) return;

  var password = form.querySelector('#id_password');
  var confirm = form.querySelector('#id_confirm_password');
  var meter = document.getElementById('pw-strength');
  var bar = document.getElementById('pw-strength-bar');
  var label = document.getElementById('pw-strength-label');
  var matchMsg = document.getElementById('pw-match');
  var ruleItems = document.querySelectorAll('#pw-rules li');

  // ---- show / hide toggles ------------------------------------------------
  form.querySelectorAll('.pw-wrap').forEach(function (wrap) {
    var input = wrap.querySelector('input');
    var what = input.id === 'id_registration_key' ? 'key' : 'password';
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-toggle';
    btn.textContent = 'Show';
    btn.setAttribute('aria-label', 'Show ' + what);
    btn.setAttribute('aria-pressed', 'false');
    btn.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
      btn.setAttribute('aria-label', (show ? 'Hide ' : 'Show ') + what);
      btn.setAttribute('aria-pressed', String(show));
    });
    wrap.appendChild(btn);
  });

  // ---- strength -------------------------------------------------------------
  var RULES = {
    length: function (v) { return v.length >= 8; },
    case:   function (v) { return /[a-z]/.test(v) && /[A-Z]/.test(v); },
    number: function (v) { return /\d/.test(v); },
    symbol: function (v) { return /[^A-Za-z0-9]/.test(v); }
  };
  var LABELS = ['', 'Too weak', 'Weak', 'Fair', 'Good', 'Strong'];

  function strength(value) {
    if (!value) return 0;
    var score = 0;
    Object.keys(RULES).forEach(function (k) { if (RULES[k](value)) score++; });
    if (value.length >= 12) score++;
    return Math.max(1, score);   // anything typed is at least level 1
  }

  function updateStrength() {
    var value = password.value;
    var level = strength(value);
    meter.hidden = !value;
    bar.setAttribute('data-level', String(level));
    label.textContent = LABELS[level];
    ruleItems.forEach(function (li) {
      var ok = RULES[li.getAttribute('data-rule')](value);
      li.classList.toggle('ok', ok);
    });
  }

  // ---- confirm ------------------------------------------------------------------
  function updateMatch() {
    if (!confirm.value) { matchMsg.hidden = true; return; }
    var same = confirm.value === password.value;
    matchMsg.hidden = false;
    matchMsg.textContent = same ? 'Passwords match' : 'Passwords do not match';
    matchMsg.className = 'match-msg ' + (same ? 'match-ok' : 'match-bad');
  }

  password.addEventListener('input', function () { updateStrength(); updateMatch(); });
  confirm.addEventListener('input', updateMatch);
  updateStrength();
  updateMatch();
})();
