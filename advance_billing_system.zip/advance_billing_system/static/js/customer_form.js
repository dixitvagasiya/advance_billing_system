/* Customer registration form.
 * Progressive enhancement: without JS the form posts normally to the same
 * view. With JS it validates inline and calls the JSON API
 * (POST /customers/api/register/) so there is no full page reload. */
(function () {
  'use strict';
  var form = document.getElementById('customer-form');
  if (!form || !form.dataset.api) return;

  var okBox = document.getElementById('form-success');
  var okText = document.getElementById('form-success-text');
  var errBox = document.getElementById('form-error');
  var PHONE = /^\+?\d{7,15}$/;
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var FIELDS = ['name', 'email', 'phone', 'address', 'notes'];

  function input(name) { return form.elements[name]; }
  function group(name) { return input(name).closest('.field-group'); }
  function errEl(name) { return form.querySelector('[data-error-for="' + name + '"]'); }

  function setError(name, msg) {
    var g = group(name), e = errEl(name);
    g.classList.toggle('has-error', !!msg);
    g.classList.toggle('is-valid', !msg && input(name).value.trim() !== '');
    if (e) e.textContent = msg || '';
    input(name).setAttribute('aria-invalid', msg ? 'true' : 'false');
  }

  function check(name) {
    var v = input(name).value.trim();
    var msg = '';
    if (name === 'name' && !v) msg = 'Customer name is required.';
    if (name === 'email' && v && !EMAIL.test(v)) msg = 'Enter a valid email address.';
    if (name === 'phone' && v && !PHONE.test(v.replace(/[\s-]/g, ''))) msg = 'Enter a valid phone number (7–15 digits, optional leading +).';
    setError(name, msg);
    return !msg;
  }

  FIELDS.forEach(function (n) {
    input(n).addEventListener('blur', function () { check(n); });
    input(n).addEventListener('input', function () {
      if (group(n).classList.contains('has-error')) check(n);
    });
  });

  function csrf() { return form.querySelector('[name=csrfmiddlewaretoken]').value; }

  function showTopError(msg) { errBox.textContent = msg; errBox.hidden = false; }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var again = e.submitter && e.submitter.name === 'again';
    okBox.classList.remove('show');
    errBox.hidden = true;

    var valid = FIELDS.map(check).every(Boolean);
    if (!valid) {
      var firstBad = FIELDS.filter(function (n) { return group(n).classList.contains('has-error'); })[0];
      if (firstBad) input(firstBad).focus();
      return;
    }

    var body = {};
    FIELDS.forEach(function (n) {
      var v = input(n).value.trim();
      body[n] = n === 'phone' ? v.replace(/[\s-]/g, '') : v;
    });

    var btn = document.getElementById('submit-btn');
    btn.classList.add('is-loading');

    fetch(form.dataset.api, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrf(), 'Accept': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) { return { status: res.status, data: data }; });
    }).then(function (r) {
      btn.classList.remove('is-loading');
      if (r.status === 201) {
        okText.textContent = r.data.name + ' was registered.';
        okBox.classList.add('show');
        if (again) {
          form.reset();
          FIELDS.forEach(function (n) { setError(n, ''); group(n).classList.remove('is-valid'); });
          input('name').focus();
        } else {
          setTimeout(function () { window.location.href = form.dataset.listUrl; }, 900);
        }
      } else if (r.status === 400 && r.data.errors) {
        Object.keys(r.data.errors).forEach(function (n) { if (input(n)) setError(n, r.data.errors[n][0]); });
        var bad = FIELDS.filter(function (n) { return group(n).classList.contains('has-error'); })[0];
        if (bad) input(bad).focus();
      } else {
        showTopError(r.data.error || 'Something went wrong. Please try again.');
      }
    }).catch(function () {
      btn.classList.remove('is-loading');
      showTopError('Network problem — check your connection and try again.');
    });
  });
})();
