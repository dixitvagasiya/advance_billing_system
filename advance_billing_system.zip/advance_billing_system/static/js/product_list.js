/* Product list: apply the dropdown filters as soon as one changes.
 * The Apply button stays visible, so everything still works without JS. */
(function () {
  'use strict';
  var form = document.getElementById('product-filters');
  if (!form) return;
  form.querySelectorAll('select').forEach(function (select) {
    select.addEventListener('change', function () { form.submit(); });
  });
})();
