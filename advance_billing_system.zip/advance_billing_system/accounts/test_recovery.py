"""Tests: registration (admin + distributor) and OTP password recovery
(admin + distributor, web + admin JSON API)."""
import json
import re
from datetime import timedelta

from django.contrib.auth.models import User
from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import OTP, UserProfile

OLD = 'Old-Password-1!x'
NEW = 'Brand-New-Pass-7#z'


def make_user(email, role, password=OLD):
    user = User.objects.create_user(username=email, email=email, password=password, first_name='Test')
    UserProfile.objects.create(user=user, role=role)
    return user


def last_code():
    """The 6-digit code from the most recent outgoing email."""
    return re.search(r'\b(\d{6})\b', mail.outbox[-1].body).group(1)


class RecoveryBase(TestCase):
    def setUp(self):
        cache.clear()
        self.admin = make_user('admin@co.com', UserProfile.ROLE_ADMIN)
        self.dist = make_user('dist@co.com', UserProfile.ROLE_DISTRIBUTOR)


# --------------------------------------------------------------------------- registration

class DistributorRegistrationTests(TestCase):
    url = '/accounts/distributor/register/'

    def payload(self, **kw):
        d = {'name': 'Ravi Kumar', 'email': 'ravi@dist.com', 'phone': '+919800000000',
             'password': 'longenough1', 'confirm_password': 'longenough1'}
        d.update(kw)
        return d

    def test_registers_and_can_log_in(self):
        resp = self.client.post(self.url, self.payload(), follow=True)
        self.assertRedirects(resp, reverse('distributor_login'))
        user = User.objects.get(email='ravi@dist.com')
        self.assertEqual(user.profile.role, UserProfile.ROLE_DISTRIBUTOR)
        resp = self.client.post(reverse('distributor_login'),
                                {'email': 'ravi@dist.com', 'password': 'longenough1'}, follow=True)
        self.assertRedirects(resp, reverse('distributor_dashboard'))

    def test_duplicate_email_and_mismatch_rejected(self):
        self.client.post(self.url, self.payload())
        resp = self.client.post(self.url, self.payload(email='RAVI@dist.com'))
        self.assertContains(resp, 'already exists')
        resp = self.client.post(self.url, self.payload(email='x@y.com', confirm_password='nope12345'))
        self.assertContains(resp, 'do not match')
        self.assertEqual(User.objects.count(), 1)

    def test_distributor_cannot_log_in_to_admin_portal(self):
        self.client.post(self.url, self.payload())
        resp = self.client.post(reverse('admin_login'), {'email': 'ravi@dist.com', 'password': 'longenough1'})
        self.assertNotIn('_auth_user_id', self.client.session)
        self.assertEqual(resp.status_code, 200)


# --------------------------------------------------------------------------- OTP model

class OTPModelTests(RecoveryBase):
    def test_code_is_hashed_not_stored(self):
        otp, code = OTP.issue('dist@co.com')
        self.assertEqual(len(code), 6)
        self.assertNotIn(code, otp.code_hash)
        self.assertTrue(otp.matches(code))
        self.assertFalse(otp.matches('000000' if code != '000000' else '111111'))

    def test_new_code_invalidates_old(self):
        first, _ = OTP.issue('dist@co.com')
        OTP.issue('dist@co.com')
        first.refresh_from_db()
        self.assertTrue(first.is_used)

    def test_expiry(self):
        otp, _ = OTP.issue('dist@co.com')
        OTP.objects.filter(pk=otp.pk).update(created_at=timezone.now() - timedelta(minutes=11))
        otp.refresh_from_db()
        self.assertTrue(otp.is_expired)
        self.assertFalse(otp.is_valid())


# --------------------------------------------------------------------------- admin web flow

@override_settings(OTP_RESEND_COOLDOWN_SECONDS=0, DEBUG=False)
class AdminRecoveryWebTests(RecoveryBase):
    def request_code(self, email='admin@co.com'):
        return self.client.post(reverse('admin_forgot_password'), {'email': email})

    def test_login_page_links_to_recovery(self):
        resp = self.client.get(reverse('admin_login'))
        self.assertContains(resp, reverse('admin_forgot_password'))

    def test_full_happy_path(self):
        resp = self.request_code()
        self.assertRedirects(resp, reverse('admin_verify_otp'))
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(mail.outbox[0].to, ['admin@co.com'])

        resp = self.client.post(reverse('admin_verify_otp'), {
            'otp': last_code(), 'new_password': NEW, 'confirm_password': NEW}, follow=True)
        self.assertRedirects(resp, reverse('admin_login'))
        self.assertContains(resp, 'Password reset')

        resp = self.client.post(reverse('admin_login'), {'email': 'admin@co.com', 'password': NEW}, follow=True)
        self.assertRedirects(resp, reverse('admin_dashboard'))

    def test_old_password_stops_working(self):
        self.request_code()
        self.client.post(reverse('admin_verify_otp'), {'otp': last_code(), 'new_password': NEW, 'confirm_password': NEW})
        self.client.post(reverse('admin_login'), {'email': 'admin@co.com', 'password': OLD})
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_code_is_single_use(self):
        self.request_code()
        code = last_code()
        data = {'otp': code, 'new_password': NEW, 'confirm_password': NEW}
        self.client.post(reverse('admin_verify_otp'), data)
        # session was cleared on success; start a fresh recovery session without a new code
        session = self.client.session
        session['admin_password_reset_email'] = 'admin@co.com'
        session.save()
        resp = self.client.post(reverse('admin_verify_otp'), {**data, 'new_password': 'Another-Pass-8$q', 'confirm_password': 'Another-Pass-8$q'})
        self.assertContains(resp, 'invalid or has expired')
        self.assertTrue(User.objects.get(email='admin@co.com').check_password(NEW))

    def test_unknown_email_gets_same_response_and_no_mail(self):
        resp = self.request_code('nobody@co.com')
        self.assertRedirects(resp, reverse('admin_verify_otp'), fetch_redirect_response=False)
        self.assertEqual(len(mail.outbox), 0)
        page = self.client.get(reverse('admin_verify_otp'))
        self.assertContains(page, "If an account exists")
        self.assertNotContains(page, 'No account found')

    def test_distributor_email_cannot_recover_through_admin_portal(self):
        self.request_code('dist@co.com')
        self.assertEqual(len(mail.outbox), 0)
        OTP.objects.create(email='dist@co.com', code_hash=OTP.hash_code('dist@co.com', '123456'))
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': '123456', 'new_password': NEW, 'confirm_password': NEW})
        self.assertContains(resp, 'invalid or has expired')
        self.assertTrue(User.objects.get(email='dist@co.com').check_password(OLD))

    def test_wrong_code_rejected(self):
        self.request_code()
        good = last_code()
        bad = '000000' if good != '000000' else '111111'
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': bad, 'new_password': NEW, 'confirm_password': NEW})
        self.assertContains(resp, 'invalid or has expired')
        self.assertTrue(User.objects.get(email='admin@co.com').check_password(OLD))

    @override_settings(OTP_MAX_ATTEMPTS=3)
    def test_code_burns_after_too_many_wrong_guesses(self):
        self.request_code()
        good = last_code()
        bad = '000000' if good != '000000' else '111111'
        for _ in range(3):
            self.client.post(reverse('admin_verify_otp'), {'otp': bad, 'new_password': NEW, 'confirm_password': NEW})
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': good, 'new_password': NEW, 'confirm_password': NEW})
        self.assertContains(resp, 'invalid or has expired')
        self.assertTrue(User.objects.get(email='admin@co.com').check_password(OLD))

    def test_expired_code_rejected(self):
        self.request_code()
        OTP.objects.update(created_at=timezone.now() - timedelta(minutes=30))
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': last_code(), 'new_password': NEW, 'confirm_password': NEW})
        self.assertContains(resp, 'invalid or has expired')

    def test_weak_password_keeps_code_usable(self):
        self.request_code()
        code = last_code()
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': code, 'new_password': 'password123', 'confirm_password': 'password123'})
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'too common')
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': code, 'new_password': NEW, 'confirm_password': NEW}, follow=True)
        self.assertRedirects(resp, reverse('admin_login'))

    def test_mismatched_confirmation_rejected(self):
        self.request_code()
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': last_code(), 'new_password': NEW, 'confirm_password': NEW + 'x'})
        self.assertContains(resp, 'do not match')
        self.assertTrue(User.objects.get(email='admin@co.com').check_password(OLD))

    def test_verify_page_without_session_redirects(self):
        resp = self.client.get(reverse('admin_verify_otp'))
        self.assertRedirects(resp, reverse('admin_forgot_password'), fetch_redirect_response=False)

    def test_resend_issues_new_code_and_kills_old(self):
        self.request_code()
        first = last_code()
        resp = self.client.post(reverse('admin_resend_otp'))
        self.assertRedirects(resp, reverse('admin_verify_otp'))
        self.assertEqual(len(mail.outbox), 2)
        second = last_code()
        if first != second:
            resp = self.client.post(reverse('admin_verify_otp'), {'otp': first, 'new_password': NEW, 'confirm_password': NEW})
            self.assertContains(resp, 'invalid or has expired')
        resp = self.client.post(reverse('admin_verify_otp'), {'otp': second, 'new_password': NEW, 'confirm_password': NEW}, follow=True)
        self.assertRedirects(resp, reverse('admin_login'))

    def test_resend_requires_post(self):
        self.request_code()
        self.assertEqual(self.client.get(reverse('admin_resend_otp')).status_code, 405)

    def test_email_is_case_insensitive(self):
        self.request_code('ADMIN@Co.com')
        self.assertEqual(len(mail.outbox), 1)

    def test_pages_render_with_admin_branding(self):
        self.assertContains(self.client.get(reverse('admin_forgot_password')), 'Admin Portal')
        self.request_code()
        page = self.client.get(reverse('admin_verify_otp'))
        self.assertContains(page, 'admin@co.com')
        self.assertContains(page, reverse('admin_login'))

    def test_otp_not_in_page_or_messages_when_debug_off(self):
        resp = self.request_code()
        page = self.client.get(resp.url)
        self.assertNotContains(page, last_code())

    @override_settings(DEBUG=True)
    def test_debug_mode_shows_code_for_local_dev(self):
        resp = self.request_code()
        page = self.client.get(resp.url)
        self.assertContains(page, last_code())


@override_settings(DEBUG=False)
class RecoveryThrottleTests(RecoveryBase):
    def test_cooldown_blocks_rapid_requests_without_sending(self):
        url = reverse('admin_forgot_password')
        self.client.post(url, {'email': 'admin@co.com'})
        resp = self.client.post(url, {'email': 'admin@co.com'}, follow=True)
        self.assertContains(resp, 'Please wait')
        self.assertEqual(len(mail.outbox), 1)

    def test_cooldown_applies_to_unknown_emails_too(self):
        url = reverse('admin_forgot_password')
        self.client.post(url, {'email': 'ghost@co.com'})
        resp = self.client.post(url, {'email': 'ghost@co.com'}, follow=True)
        self.assertContains(resp, 'Please wait')    # identical behaviour => no enumeration

    @override_settings(OTP_RESEND_COOLDOWN_SECONDS=0, OTP_MAX_REQUESTS_PER_HOUR=3)
    def test_hourly_cap(self):
        url = reverse('admin_forgot_password')
        for _ in range(3):
            self.client.post(url, {'email': 'admin@co.com'})
        resp = self.client.post(url, {'email': 'admin@co.com'}, follow=True)
        self.assertContains(resp, 'Too many code requests')
        self.assertEqual(len(mail.outbox), 3)


# --------------------------------------------------------------------------- distributor web flow (existing URLs)

@override_settings(OTP_RESEND_COOLDOWN_SECONDS=0, DEBUG=False)
class DistributorRecoveryWebTests(RecoveryBase):
    def test_full_happy_path_and_redirect_to_distributor_login(self):
        resp = self.client.post(reverse('forgot_password'), {'email': 'dist@co.com'})
        self.assertRedirects(resp, reverse('verify_otp'))
        resp = self.client.post(reverse('verify_otp'), {'otp': last_code(), 'new_password': NEW, 'confirm_password': NEW}, follow=True)
        self.assertRedirects(resp, reverse('distributor_login'))
        resp = self.client.post(reverse('distributor_login'), {'email': 'dist@co.com', 'password': NEW}, follow=True)
        self.assertRedirects(resp, reverse('distributor_dashboard'))

    def test_admin_email_cannot_recover_through_distributor_portal(self):
        self.client.post(reverse('forgot_password'), {'email': 'admin@co.com'})
        self.assertEqual(len(mail.outbox), 0)

    def test_distributor_page_branding(self):
        self.assertContains(self.client.get(reverse('forgot_password')), 'Distributor Portal')


# --------------------------------------------------------------------------- admin JSON API

@override_settings(OTP_RESEND_COOLDOWN_SECONDS=0)
class AdminRecoveryAPITests(RecoveryBase):
    req = '/accounts/api/admin/password-recovery/request/'
    rst = '/accounts/api/admin/password-recovery/reset/'

    def post(self, url, data, raw=None):
        return self.client.post(url, raw if raw is not None else json.dumps(data), content_type='application/json')

    def test_request_then_reset(self):
        resp = self.post(self.req, {'email': 'admin@co.com'})
        self.assertEqual(resp.status_code, 202)
        self.assertEqual(len(mail.outbox), 1)
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': last_code(), 'new_password': NEW, 'confirm_password': NEW})
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(User.objects.get(email='admin@co.com').check_password(NEW))

    def test_request_response_identical_for_unknown_and_distributor_emails(self):
        known = self.post(self.req, {'email': 'admin@co.com'})
        unknown = self.post(self.req, {'email': 'ghost@co.com'})
        dist = self.post(self.req, {'email': 'dist@co.com'})
        self.assertEqual(known.status_code, unknown.status_code)
        self.assertEqual(known.json(), unknown.json())
        self.assertEqual(known.json(), dist.json())
        self.assertEqual(len(mail.outbox), 1)

    def test_request_validation(self):
        self.assertEqual(self.post(self.req, {'email': 'not-an-email'}).status_code, 400)
        self.assertEqual(self.post(self.req, {}).status_code, 400)
        self.assertEqual(self.post(self.req, None, raw='{bad').status_code, 400)
        self.assertEqual(self.post(self.req, None, raw='[]').status_code, 400)

    def test_only_post(self):
        for url in (self.req, self.rst):
            resp = self.client.get(url)
            self.assertEqual(resp.status_code, 405)
            self.assertEqual(resp['Allow'], 'POST')

    def test_reset_with_wrong_code(self):
        self.post(self.req, {'email': 'admin@co.com'})
        good = last_code()
        bad = '000000' if good != '000000' else '111111'
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': bad, 'new_password': NEW})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json(), {'error': 'Invalid or expired code.'})
        self.assertTrue(User.objects.get(email='admin@co.com').check_password(OLD))

    def test_reset_for_distributor_account_fails_even_with_valid_code(self):
        OTP.objects.create(email='dist@co.com', code_hash=OTP.hash_code('dist@co.com', '123456'))
        resp = self.post(self.rst, {'email': 'dist@co.com', 'otp': '123456', 'new_password': NEW})
        self.assertEqual(resp.status_code, 400)
        self.assertTrue(User.objects.get(email='dist@co.com').check_password(OLD))

    def test_reset_field_validation(self):
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': '12', 'new_password': 'short'})
        errs = resp.json()['errors']
        self.assertIn('otp', errs)
        self.assertIn('new_password', errs)
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': '123456', 'new_password': NEW, 'confirm_password': 'x'})
        self.assertIn('confirm_password', resp.json()['errors'])

    def test_weak_password_reports_rules_and_keeps_code(self):
        self.post(self.req, {'email': 'admin@co.com'})
        code = last_code()
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': code, 'new_password': 'password123'})
        self.assertEqual(resp.status_code, 400)
        self.assertIn('new_password', resp.json()['errors'])
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': code, 'new_password': NEW})
        self.assertEqual(resp.status_code, 200)

    @override_settings(OTP_MAX_ATTEMPTS=3)
    def test_brute_force_burns_the_code(self):
        self.post(self.req, {'email': 'admin@co.com'})
        good = last_code()
        bad = '000000' if good != '000000' else '111111'
        for _ in range(3):
            self.post(self.rst, {'email': 'admin@co.com', 'otp': bad, 'new_password': NEW})
        resp = self.post(self.rst, {'email': 'admin@co.com', 'otp': good, 'new_password': NEW})
        self.assertEqual(resp.status_code, 400)

    def test_non_string_values_do_not_crash(self):
        resp = self.post(self.rst, {'email': ['a'], 'otp': 123456, 'new_password': {'x': 1}})
        self.assertEqual(resp.status_code, 400)

    @override_settings(OTP_RESEND_COOLDOWN_SECONDS=60)
    def test_throttle_returns_429_with_retry_after(self):
        self.post(self.req, {'email': 'admin@co.com'})
        resp = self.post(self.req, {'email': 'admin@co.com'})
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(resp['Retry-After'], '60')

    def test_no_session_created(self):
        self.post(self.req, {'email': 'admin@co.com'})
        self.assertNotIn('_auth_user_id', self.client.session)
