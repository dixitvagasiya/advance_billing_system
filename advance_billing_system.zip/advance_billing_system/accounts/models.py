import hashlib
import hmac
import secrets
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone


class UserProfile(models.Model):
    """Extends Django's built-in User with a role and phone number.

    Role decides which login route / dashboard a user belongs to
    (task 2: separate Admin and Distributor routes).
    """

    ROLE_ADMIN = 'admin'
    ROLE_DISTRIBUTOR = 'distributor'
    ROLE_CHOICES = (
        (ROLE_ADMIN, 'Admin'),
        (ROLE_DISTRIBUTOR, 'Distributor'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_DISTRIBUTOR)
    phone = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.get_full_name() or self.user.username} ({self.get_role_display()})'


class OTP(models.Model):
    """One-time codes used for password recovery.

    Security properties:
      * the 6-digit code is generated with `secrets` and only an HMAC of it is
        stored, so a database leak does not reveal live codes;
      * codes are short-lived (settings.OTP_VALIDITY_MINUTES) and single-use;
      * a code is burned after settings.OTP_MAX_ATTEMPTS wrong guesses.
    """

    PURPOSE_PASSWORD_RESET = 'password_reset'
    PURPOSE_CHOICES = (
        (PURPOSE_PASSWORD_RESET, 'Password Reset'),
    )

    email = models.EmailField()
    code_hash = models.CharField(max_length=64, blank=True)
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES, default=PURPOSE_PASSWORD_RESET)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)
    attempts = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.email} · {self.purpose} · {self.created_at:%Y-%m-%d %H:%M}'

    @property
    def is_expired(self):
        validity = getattr(settings, 'OTP_VALIDITY_MINUTES', 10)
        return timezone.now() > self.created_at + timedelta(minutes=validity)

    @property
    def attempts_exhausted(self):
        return self.attempts >= getattr(settings, 'OTP_MAX_ATTEMPTS', 5)

    def is_valid(self):
        return not self.is_used and not self.is_expired and not self.attempts_exhausted

    @staticmethod
    def generate_code():
        return f'{secrets.randbelow(1_000_000):06d}'

    @staticmethod
    def hash_code(email, code):
        key = settings.SECRET_KEY.encode('utf-8')
        msg = f'{email.lower()}:{code}'.encode('utf-8')
        return hmac.new(key, msg, hashlib.sha256).hexdigest()

    def matches(self, code):
        if not self.code_hash:
            return False
        return hmac.compare_digest(self.code_hash, self.hash_code(self.email, str(code)))

    @classmethod
    def issue(cls, email, purpose=PURPOSE_PASSWORD_RESET):
        """Create a fresh OTP, invalidating older unused ones.

        Returns (otp, plain_code). The plain code exists only in memory so it
        can be emailed; it is never stored.
        """
        email = email.lower().strip()
        cls.objects.filter(email=email, purpose=purpose, is_used=False).update(is_used=True)
        code = cls.generate_code()
        otp = cls.objects.create(email=email, purpose=purpose, code_hash=cls.hash_code(email, code))
        return otp, code
