from django.urls import path

from . import api, views

urlpatterns = [
    # Admin portal
    path('admin-portal/login/', views.admin_login_view, name='admin_login'),
    path('admin-portal/register/', views.admin_register_view, name='admin_register'),
    path('admin-portal/dashboard/', views.admin_dashboard_view, name='admin_dashboard'),

    # Distributor portal
    path('distributor/login/', views.distributor_login_view, name='distributor_login'),
    path('distributor/register/', views.distributor_register_view, name='distributor_register'),
    path('distributor/dashboard/', views.distributor_dashboard_view, name='distributor_dashboard'),
    path('distributor/profile/', views.distributor_profile_view, name='distributor_profile'),
    path('distributor/profile/edit/', views.distributor_profile_update_view, name='distributor_profile_update'),

    # Shared: forgot password / OTP
    path('forgot-password/', views.forgot_password_view, name='forgot_password'),
    path('verify-otp/', views.verify_otp_view, name='verify_otp'),
    path('resend-otp/', views.resend_otp_view, name='resend_otp'),

    # JSON API
    path('api/admin/register/', api.admin_register, name='api_admin_register'),

    path('logout/', views.logout_view, name='logout'),
]
