from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator

from . import services

phone_validator = RegexValidator(
    regex=r'^\+?\d{7,15}$',
    message='Enter a valid phone number (7–15 digits, optional leading +).',
)


class StyledFormMixin:
    """Adds a shared CSS class to every field so templates stay simple."""

    def _style(self, extra_classes=''):
        for field in self.fields.values():
            existing = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = f'{existing} field-input {extra_classes}'.strip()


class LoginForm(StyledFormMixin, forms.Form):
    email = forms.EmailField(
        label='Email address',
        widget=forms.EmailInput(attrs={'placeholder': 'you@company.com', 'autofocus': True}),
    )
    password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={'placeholder': '••••••••'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()


class DistributorRegistrationForm(StyledFormMixin, forms.Form):
    name = forms.CharField(
        label='Full name', max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Priya Sharma', 'autofocus': True}),
    )
    email = forms.EmailField(
        label='Email address',
        widget=forms.EmailInput(attrs={'placeholder': 'priya@distributorco.com'}),
    )
    phone = forms.CharField(
        label='Phone number', max_length=15, validators=[phone_validator],
        widget=forms.TextInput(attrs={'placeholder': '+91 98765 43210'}),
    )
    password = forms.CharField(
        label='Password', min_length=8,
        widget=forms.PasswordInput(attrs={'placeholder': 'At least 8 characters'}),
        help_text='At least 8 characters.',
    )
    confirm_password = forms.CharField(
        label='Confirm password',
        widget=forms.PasswordInput(attrs={'placeholder': 'Re-enter your password'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()

    def clean_email(self):
        email = self.cleaned_data['email'].lower().strip()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('An account with this email already exists.')
        return email

    def clean(self):
        cleaned = super().clean()
        password = cleaned.get('password')
        confirm = cleaned.get('confirm_password')
        if password and confirm and password != confirm:
            self.add_error('confirm_password', 'Passwords do not match.')
        return cleaned


class ProfileUpdateForm(StyledFormMixin, forms.Form):
    """Editable profile fields. Email is deliberately excluded — it's also
    the login username, so changing it needs its own uniqueness/re-auth
    handling that's out of scope here.
    """

    name = forms.CharField(
        label='Full name', max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Priya Sharma', 'autofocus': True}),
    )
    phone = forms.CharField(
        label='Phone number', max_length=15, validators=[phone_validator],
        widget=forms.TextInput(attrs={'placeholder': '+91 98765 43210'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()


class ForgotPasswordForm(StyledFormMixin, forms.Form):
    email = forms.EmailField(
        label='Email address',
        widget=forms.EmailInput(attrs={'placeholder': 'you@company.com', 'autofocus': True}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()


class OTPVerifyForm(StyledFormMixin, forms.Form):
    otp = forms.CharField(
        label='6-digit OTP', max_length=6, min_length=6,
        widget=forms.TextInput(attrs={
            'placeholder': '••••••', 'inputmode': 'numeric',
            'autocomplete': 'one-time-code', 'autofocus': True,
        }),
    )
    new_password = forms.CharField(
        label='New password', min_length=8,
        widget=forms.PasswordInput(attrs={'placeholder': 'At least 8 characters'}),
    )
    confirm_password = forms.CharField(
        label='Confirm new password',
        widget=forms.PasswordInput(attrs={'placeholder': 'Re-enter your new password'}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()

    def clean(self):
        cleaned = super().clean()
        password = cleaned.get('new_password')
        confirm = cleaned.get('confirm_password')
        if password and confirm and password != confirm:
            self.add_error('confirm_password', 'Passwords do not match.')
        return cleaned


class AdminRegistrationForm(StyledFormMixin, forms.Form):
    """Admin sign-up, used by both the web page and the JSON API.

    Order matters for security: the registration key is checked FIRST and,
    if it is wrong, nothing else is validated or reported. That way a caller
    without the key learns nothing (e.g. whether an email is registered).
    """

    name = forms.CharField(
        label='Full name', max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Priya Sharma', 'autofocus': True, 'autocomplete': 'name'}),
    )
    email = forms.EmailField(
        label='Work email',
        widget=forms.EmailInput(attrs={'placeholder': 'priya@company.com', 'autocomplete': 'email'}),
    )
    phone = forms.CharField(
        label='Phone number (optional)', max_length=15, required=False, validators=[phone_validator],
        widget=forms.TextInput(attrs={'placeholder': '+91 98765 43210', 'autocomplete': 'tel'}),
    )
    password = forms.CharField(
        label='Password', strip=False,
        widget=forms.PasswordInput(attrs={'placeholder': 'Create a strong password', 'autocomplete': 'new-password'}),
    )
    confirm_password = forms.CharField(
        label='Confirm password', strip=False,
        widget=forms.PasswordInput(attrs={'placeholder': 'Re-enter your password', 'autocomplete': 'new-password'}),
    )
    registration_key = forms.CharField(
        label='Admin registration key', strip=False,
        widget=forms.PasswordInput(attrs={'placeholder': 'Provided by the system owner', 'autocomplete': 'off'}),
        help_text='Only people given this key can create admin accounts.',
    )

    def __init__(self, *args, require_confirm=True, **kwargs):
        super().__init__(*args, **kwargs)
        # The JSON API does not need a "type it twice" field (optional there).
        self.fields['confirm_password'].required = require_confirm
        self.key_failed = False
        self._style()

    def clean(self):
        cleaned = super().clean()

        # 1) Key first. Wrong/missing key -> stop and reveal nothing else.
        if not services.key_is_valid(cleaned.get('registration_key', '')):
            self.key_failed = True
            self._errors.clear()   # other field messages must not be shown to a caller without the key
            self.add_error('registration_key', 'Invalid registration key.')
            return cleaned

        # 2) Everything else, now that the caller is authorised.
        email = cleaned.get('email')
        if email:
            email = email.lower().strip()
            cleaned['email'] = email
            if (User.objects.filter(email__iexact=email).exists()
                    or User.objects.filter(username__iexact=email).exists()):
                self.add_error('email', 'An account with this email already exists.')

        password = cleaned.get('password')
        confirm = cleaned.get('confirm_password')
        if password and confirm and password != confirm:
            self.add_error('confirm_password', 'Passwords do not match.')
        if password:
            candidate = User(
                username=email or '', email=email or '',
                first_name=(cleaned.get('name') or '').split(' ')[0],
            )
            try:
                validate_password(password, user=candidate)   # project-wide AUTH_PASSWORD_VALIDATORS
            except ValidationError as exc:
                self.add_error('password', exc)
        return cleaned
