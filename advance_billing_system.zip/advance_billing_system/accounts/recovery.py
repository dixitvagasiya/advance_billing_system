"""Password recovery by emailed OTP, shared by the Admin portal, the
Distributor portal and the Admin JSON API.

Design rules
  * Role-scoped: the Admin flow only ever touches Admin-role accounts and the
    Distributor flow only Distributor-role accounts.
  * No account enumeration: requesting a code looks identical whether or not
    the address belongs to an account, and so does a wrong code.
  * Throttled: a cooldown between requests and an hourly cap per account
    (counted even for unknown addresses, so throttling leaks nothing), plus a
    per-code attempt limit enforced in OTP.
"""
import logging

from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.core.mail import send_mail
from django.db import transaction

from .models import OTP, UserProfile

logger = logging.getLogger(__name__)

# Result codes for reset_password()
OK = 'ok'
INVALID = 'invalid'            # wrong / expired / used / exhausted code, or no such account
WEAK_PASSWORD = 'weak_password'


class Throttled(Exception):
    def __init__(self, retry_after):
        super().__init__(f'Try again in {retry_after}s')
        self.retry_after = retry_after


def normalise(email):
    return (email or '').lower().strip()


def find_user(email, role):
    """The account for this email in this role, or None."""
    return (User.objects.filter(email__iexact=normalise(email), is_active=True,
                                profile__role=role).first())


# ---- throttling (Django cache; per account, regardless of existence) --------

def _cooldown_key(role, email):
    return f'otp-cooldown:{role}:{email}'


def _hourly_key(role, email):
    return f'otp-hourly:{role}:{email}'


def _check_and_count(role, email):
    cooldown = getattr(settings, 'OTP_RESEND_COOLDOWN_SECONDS', 60)
    cap = getattr(settings, 'OTP_MAX_REQUESTS_PER_HOUR', 5)

    if cooldown and not cache.add(_cooldown_key(role, email), 1, cooldown):
        raise Throttled(cooldown)

    hkey = _hourly_key(role, email)
    if not cache.add(hkey, 1, 3600):
        try:
            count = cache.incr(hkey)
        except ValueError:
            cache.set(hkey, 1, 3600)
            count = 1
        if count > cap:
            cache.delete(_cooldown_key(role, email))
            raise Throttled(3600)


# ---- email --------------------------------------------------------------------

def send_otp_email(email, code):
    """Send the OTP. Delivery problems are logged, never shown to the caller
    (showing them would reveal that the address has an account)."""
    minutes = getattr(settings, 'OTP_VALIDITY_MINUTES', 10)
    try:
        send_mail(
            subject='Your Advance Billing System password reset code',
            message=(
                f'Your one-time password is {code}.\n'
                f'It is valid for {minutes} minutes and can be used once.\n\n'
                'If you did not request a password reset, you can ignore this email — '
                'your password has not changed.'
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[email],
            fail_silently=False,
        )
        return True
    except Exception:       # SMTP down, bad config, ...
        logger.exception('Could not send password-reset OTP email')
        return False


# ---- public API ---------------------------------------------------------------

def request_otp(email, role):
    """Issue and email a code if (and only if) a matching account exists.

    Returns the plain code when one was issued, otherwise None (caller must not
    reveal which). Raises Throttled when called too often.
    """
    email = normalise(email)
    _check_and_count(role, email)
    user = find_user(email, role)
    if user is None:
        return None
    _otp, code = OTP.issue(email)
    send_otp_email(email, code)
    return code


def reset_password(email, role, code, new_password):
    """Verify the code and set the new password.

    Returns (status, messages): status is OK / INVALID / WEAK_PASSWORD, and
    messages lists the password-rule problems for WEAK_PASSWORD.
    """
    email = normalise(email)
    user = find_user(email, role)
    with transaction.atomic():
        otp = (OTP.objects.select_for_update()
               .filter(email=email, purpose=OTP.PURPOSE_PASSWORD_RESET, is_used=False)
               .order_by('-created_at').first())
        if user is None or otp is None or not otp.is_valid():
            return INVALID, []

        if not otp.matches(code):
            otp.attempts += 1
            if otp.attempts_exhausted:
                otp.is_used = True
            otp.save(update_fields=['attempts', 'is_used'])
            return INVALID, []

        # Code is right. Check the password BEFORE burning the code so a typo'd
        # weak password doesn't force the user to request another OTP.
        try:
            validate_password(new_password, user=user)
        except ValidationError as exc:
            return WEAK_PASSWORD, list(exc.messages)

        otp.is_used = True
        otp.save(update_fields=['is_used'])
        user.set_password(new_password)
        user.save(update_fields=['password'])
    return OK, []


def password_errors(new_password, user=None):
    try:
        validate_password(new_password, user=user)
    except ValidationError as exc:
        return list(exc.messages)
    return []
