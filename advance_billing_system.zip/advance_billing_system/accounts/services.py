"""Admin registration logic shared by the web form and the JSON API, so the
two can never disagree about who may register or what makes a valid account."""
import hmac

from django.conf import settings
from django.contrib.auth.models import User
from django.core.cache import cache
from django.db import transaction

from .models import UserProfile


# ---- registration key ------------------------------------------------------

def key_is_configured():
    return bool(getattr(settings, 'ADMIN_REGISTRATION_KEY', ''))


def key_is_valid(supplied):
    """Constant-time comparison; False when registration is not configured."""
    configured = getattr(settings, 'ADMIN_REGISTRATION_KEY', '')
    if not configured or not supplied:
        return False
    return hmac.compare_digest(str(supplied).encode('utf-8'), configured.encode('utf-8'))


# ---- brute-force throttle (per client IP, via Django's cache) ---------------

def _fail_key(request):
    # REMOTE_ADDR on purpose: X-Forwarded-For is client-controlled unless a
    # trusted proxy sets it, so honouring it would let attackers dodge the limit.
    return f"admin-reg-fail:{request.META.get('REMOTE_ADDR', 'unknown')}"


def is_locked_out(request):
    limit = getattr(settings, 'ADMIN_REGISTRATION_MAX_FAILED_KEYS', 5)
    return cache.get(_fail_key(request), 0) >= limit


def record_failed_key(request):
    key = _fail_key(request)
    window = getattr(settings, 'ADMIN_REGISTRATION_LOCKOUT_SECONDS', 900)
    if not cache.add(key, 1, window):
        try:
            cache.incr(key)
        except ValueError:          # expired between add() and incr()
            cache.set(key, 1, window)


# ---- account creation -------------------------------------------------------

def create_admin_user(*, name, email, phone, password):
    """Create a User + UserProfile(role=admin) atomically.

    The account gets the project's Admin *role* only. It is NOT given Django's
    is_staff / is_superuser, so it cannot open the /admin/ database console.
    """
    first_name, _, last_name = name.strip().partition(' ')
    with transaction.atomic():
        user = User.objects.create_user(
            username=email, email=email, password=password,
            first_name=first_name, last_name=last_name,
        )
        UserProfile.objects.create(user=user, role=UserProfile.ROLE_ADMIN, phone=phone)
    return user
