import json

from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.urls import reverse

from .models import UserProfile

KEY = 'test-registration-key-123'
STRONG = 'Correct-Horse-9!battery'


def valid_payload(**overrides):
    data = {
        'name': 'Priya Sharma', 'email': 'priya@company.com', 'phone': '+919876543210',
        'password': STRONG, 'confirm_password': STRONG, 'registration_key': KEY,
    }
    data.update(overrides)
    return data


@override_settings(ADMIN_REGISTRATION_KEY=KEY)
class AdminRegisterPageTests(TestCase):
    def setUp(self):
        cache.clear()
        self.url = reverse('admin_register')

    def test_form_is_rendered(self):
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        for name in ('name', 'email', 'phone', 'password', 'confirm_password', 'registration_key'):
            self.assertContains(resp, f'name="{name}"')
        self.assertContains(resp, 'admin_register.js')
        self.assertContains(resp, 'Admin Portal')

    def test_password_fields_are_masked_and_not_echoed(self):
        resp = self.client.post(self.url, valid_payload(confirm_password='different'))
        self.assertEqual(resp.status_code, 200)
        self.assertNotContains(resp, STRONG)
        self.assertNotContains(resp, KEY)

    def test_registers_an_admin_and_redirects_to_login(self):
        resp = self.client.post(self.url, valid_payload(), follow=True)
        self.assertRedirects(resp, reverse('admin_login'))
        self.assertContains(resp, 'Admin account created successfully')
        user = User.objects.get(email='priya@company.com')
        self.assertEqual(user.profile.role, UserProfile.ROLE_ADMIN)
        self.assertEqual(user.get_full_name(), 'Priya Sharma')
        self.assertEqual(user.profile.phone, '+919876543210')

    def test_new_admin_can_log_in_to_the_admin_portal(self):
        self.client.post(self.url, valid_payload())
        resp = self.client.post(reverse('admin_login'), {'email': 'priya@company.com', 'password': STRONG}, follow=True)
        self.assertRedirects(resp, reverse('admin_dashboard'))

    def test_account_gets_role_only_not_django_superuser_powers(self):
        self.client.post(self.url, valid_payload())
        user = User.objects.get(email='priya@company.com')
        self.assertFalse(user.is_staff)
        self.assertFalse(user.is_superuser)

    def test_not_auto_logged_in(self):
        self.client.post(self.url, valid_payload())
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_email_is_normalised_to_lowercase(self):
        self.client.post(self.url, valid_payload(email='Priya@Company.COM'))
        self.assertTrue(User.objects.filter(username='priya@company.com').exists())

    def test_phone_is_optional(self):
        self.client.post(self.url, valid_payload(phone=''))
        self.assertEqual(User.objects.get(email='priya@company.com').profile.phone, '')

    def test_wrong_key_creates_nothing(self):
        resp = self.client.post(self.url, valid_payload(registration_key='nope'))
        self.assertContains(resp, 'Invalid registration key.')
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_wrong_key_does_not_leak_whether_email_exists(self):
        User.objects.create_user('taken@company.com', 'taken@company.com', 'x')
        resp = self.client.post(self.url, valid_payload(email='taken@company.com', registration_key='nope'))
        self.assertContains(resp, 'Invalid registration key.')
        self.assertNotContains(resp, 'already exists')

    def test_duplicate_email_rejected_case_insensitively(self):
        User.objects.create_user('taken@company.com', 'taken@company.com', 'x')
        resp = self.client.post(self.url, valid_payload(email='TAKEN@company.com'))
        self.assertContains(resp, 'An account with this email already exists.')
        self.assertEqual(User.objects.filter(email__iexact='taken@company.com').count(), 1)

    def test_password_rules_enforced(self):
        for bad, why in (('short1!', 'too short'), ('password123', 'common'), ('1234567890123', 'numeric')):
            resp = self.client.post(self.url, valid_payload(password=bad, confirm_password=bad))
            self.assertEqual(resp.status_code, 200, why)
            self.assertFalse(User.objects.filter(email='priya@company.com').exists(), why)

    def test_password_similar_to_email_rejected(self):
        resp = self.client.post(self.url, valid_payload(password='priya@company.com', confirm_password='priya@company.com'))
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_mismatched_confirmation_rejected(self):
        resp = self.client.post(self.url, valid_payload(confirm_password=STRONG + 'x'))
        self.assertContains(resp, 'Passwords do not match.')
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_required_fields(self):
        resp = self.client.post(self.url, valid_payload(name='', email=''))
        self.assertContains(resp, 'This field is required.')
        self.assertFalse(User.objects.exists())

    def test_csrf_is_enforced_on_the_web_form(self):
        strict = Client(enforce_csrf_checks=True)
        self.assertEqual(strict.post(self.url, valid_payload()).status_code, 403)
        self.assertFalse(User.objects.exists())

    def test_lockout_after_repeated_wrong_keys(self):
        for _ in range(5):
            self.client.post(self.url, valid_payload(registration_key='guess'))
        resp = self.client.post(self.url, valid_payload())          # even the CORRECT key is blocked now
        self.assertEqual(resp.status_code, 429)
        self.assertContains(resp, 'Too many incorrect registration keys', status_code=429)
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_correct_key_attempts_are_not_counted_against_the_limit(self):
        for i in range(8):
            self.client.post(self.url, valid_payload(email=f'a{i}@company.com'))
        self.assertEqual(User.objects.count(), 8)

    @override_settings(ADMIN_REGISTRATION_KEY='')
    def test_disabled_until_a_key_is_configured(self):
        for resp in (self.client.get(self.url), self.client.post(self.url, valid_payload(registration_key=''))):
            self.assertEqual(resp.status_code, 403)
            self.assertContains(resp, 'Admin registration is not enabled', status_code=403)
        self.assertFalse(User.objects.exists())

    def test_login_page_links_to_registration(self):
        resp = self.client.get(reverse('admin_login'))
        self.assertContains(resp, reverse('admin_register'))


@override_settings(ADMIN_REGISTRATION_KEY=KEY)
class AdminRegisterAPITests(TestCase):
    def setUp(self):
        cache.clear()
        self.url = reverse('api_admin_register')
        self.api = Client(enforce_csrf_checks=True)       # prove no CSRF token is needed

    def post(self, payload, raw=None):
        body = raw if raw is not None else json.dumps(payload)
        return self.api.post(self.url, body, content_type='application/json')

    def test_creates_an_admin(self):
        resp = self.post(valid_payload())
        self.assertEqual(resp.status_code, 201)
        body = resp.json()
        self.assertEqual(body['email'], 'priya@company.com')
        self.assertEqual(body['name'], 'Priya Sharma')
        self.assertEqual(body['role'], 'admin')
        self.assertEqual(body['phone'], '+919876543210')
        user = User.objects.get(pk=body['id'])
        self.assertTrue(user.check_password(STRONG))
        self.assertEqual(user.profile.role, UserProfile.ROLE_ADMIN)
        self.assertFalse(user.is_staff or user.is_superuser)

    def test_response_never_contains_secrets(self):
        text = self.post(valid_payload()).content.decode()
        self.assertNotIn(STRONG, text)
        self.assertNotIn(KEY, text)
        self.assertNotIn('password', text.lower())

    def test_does_not_log_the_caller_in_or_set_a_session(self):
        resp = self.post(valid_payload())
        self.assertEqual(resp.status_code, 201)
        # Inspect the response itself: merely reading client.session would create a cookie.
        self.assertEqual(len(resp.cookies), 0)
        self.assertNotIn('sessionid', self.api.cookies)
        self.assertNotIn('_auth_user_id', self.api.session)

    def test_new_admin_can_authenticate(self):
        self.post(valid_payload())
        self.assertIsNotNone(authenticate(username='priya@company.com', password=STRONG))

    def test_confirm_password_is_optional_but_checked_when_sent(self):
        payload = valid_payload()
        del payload['confirm_password']
        self.assertEqual(self.post(payload).status_code, 201)
        resp = self.post(valid_payload(email='b@company.com', confirm_password='nope'))
        self.assertEqual(resp.status_code, 400)
        self.assertIn('confirm_password', resp.json()['errors'])

    def test_missing_or_wrong_key_is_403(self):
        payload = valid_payload()
        del payload['registration_key']
        self.assertEqual(self.post(payload).status_code, 403)
        resp = self.post(valid_payload(registration_key='wrong'))
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(resp.json(), {'error': 'Invalid registration key.'})
        self.assertFalse(User.objects.exists())

    def test_wrong_key_reveals_nothing_about_other_fields(self):
        User.objects.create_user('taken@company.com', 'taken@company.com', 'x')
        resp = self.post(valid_payload(email='taken@company.com', registration_key='wrong', password='x'))
        self.assertEqual(resp.status_code, 403)
        self.assertNotIn('exists', resp.content.decode())
        self.assertNotIn('errors', resp.json())

    def test_validation_errors_are_400_with_field_messages(self):
        resp = self.post(valid_payload(email='not-an-email', password='password123', confirm_password='password123', name=''))
        self.assertEqual(resp.status_code, 400)
        errors = resp.json()['errors']
        self.assertIn('email', errors)
        self.assertIn('password', errors)
        self.assertIn('name', errors)
        self.assertFalse(User.objects.exists())

    def test_duplicate_email_is_400(self):
        self.post(valid_payload())
        resp = self.post(valid_payload(email='PRIYA@company.com'))
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json()['errors']['email'], ['An account with this email already exists.'])

    def test_only_post_allowed(self):
        for method in ('get', 'put', 'delete', 'patch'):
            resp = getattr(self.api, method)(self.url)
            self.assertEqual(resp.status_code, 405, method)
            self.assertEqual(resp['Allow'], 'POST')
            self.assertIn('error', resp.json())

    def test_malformed_bodies_are_400(self):
        self.assertEqual(self.post(None, raw='{not json').status_code, 400)
        self.assertEqual(self.post(None, raw='').status_code, 400)
        self.assertEqual(self.post(None, raw='["a", "list"]').status_code, 400)
        self.assertEqual(self.post(None, raw='"just a string"').status_code, 400)

    def test_lockout_returns_429_with_retry_after(self):
        for _ in range(5):
            self.assertEqual(self.post(valid_payload(registration_key='guess')).status_code, 403)
        resp = self.post(valid_payload())                       # correct key, but locked out
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(resp['Retry-After'], '900')
        self.assertFalse(User.objects.exists())

    @override_settings(ADMIN_REGISTRATION_KEY='')
    def test_disabled_without_a_configured_key(self):
        resp = self.post(valid_payload(registration_key=''))
        self.assertEqual(resp.status_code, 403)
        self.assertIn('not enabled', resp.json()['error'])

    def test_api_and_web_form_share_rules(self):
        """Same weak password is refused by both entry points."""
        weak = valid_payload(password='password123', confirm_password='password123')
        self.assertEqual(self.post(weak).status_code, 400)
        self.client.post(reverse('admin_register'), weak)
        self.assertFalse(User.objects.exists())
