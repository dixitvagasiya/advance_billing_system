import json
import re
from datetime import timedelta
from unittest.mock import patch

from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.core import mail
from django.core.cache import cache
from django.test import Client, TestCase, override_settings
from django.utils import timezone
from django.urls import reverse

from .models import OTP, UserProfile

KEY = 'test-registration-key-123'
STRONG = 'Correct-Horse-9!battery'


def valid_payload(**overrides):
    data = {
        'name': 'Priya Sharma', 'email': 'priya@company.com', 'phone': '+919876543210',
        'password': STRONG, 'confirm_password': STRONG, 'registration_key': KEY,
    }
    data.update(overrides)
    return data


@override_settings(ADMIN_REGISTRATION_KEY=KEY)
class AdminRegisterPageTests(TestCase):
    def setUp(self):
        cache.clear()
        self.url = reverse('admin_register')

    def test_form_is_rendered(self):
        resp = self.client.get(self.url)
        self.assertEqual(resp.status_code, 200)
        for name in ('name', 'email', 'phone', 'password', 'confirm_password', 'registration_key'):
            self.assertContains(resp, f'name="{name}"')
        self.assertContains(resp, 'admin_register.js')
        self.assertContains(resp, 'Admin Portal')

    def test_password_fields_are_masked_and_not_echoed(self):
        resp = self.client.post(self.url, valid_payload(confirm_password='different'))
        self.assertEqual(resp.status_code, 200)
        self.assertNotContains(resp, STRONG)
        self.assertNotContains(resp, KEY)

    def test_registers_an_admin_and_redirects_to_login(self):
        resp = self.client.post(self.url, valid_payload(), follow=True)
        self.assertRedirects(resp, reverse('admin_login'))
        self.assertContains(resp, 'Admin account created successfully')
        user = User.objects.get(email='priya@company.com')
        self.assertEqual(user.profile.role, UserProfile.ROLE_ADMIN)
        self.assertEqual(user.get_full_name(), 'Priya Sharma')
        self.assertEqual(user.profile.phone, '+919876543210')

    def test_new_admin_can_log_in_to_the_admin_portal(self):
        self.client.post(self.url, valid_payload())
        resp = self.client.post(reverse('admin_login'), {'email': 'priya@company.com', 'password': STRONG}, follow=True)
        self.assertRedirects(resp, reverse('admin_dashboard'))

    def test_account_gets_role_only_not_django_superuser_powers(self):
        self.client.post(self.url, valid_payload())
        user = User.objects.get(email='priya@company.com')
        self.assertFalse(user.is_staff)
        self.assertFalse(user.is_superuser)

    def test_not_auto_logged_in(self):
        self.client.post(self.url, valid_payload())
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_email_is_normalised_to_lowercase(self):
        self.client.post(self.url, valid_payload(email='Priya@Company.COM'))
        self.assertTrue(User.objects.filter(username='priya@company.com').exists())

    def test_phone_is_optional(self):
        self.client.post(self.url, valid_payload(phone=''))
        self.assertEqual(User.objects.get(email='priya@company.com').profile.phone, '')

    def test_wrong_key_creates_nothing(self):
        resp = self.client.post(self.url, valid_payload(registration_key='nope'))
        self.assertContains(resp, 'Invalid registration key.')
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_wrong_key_does_not_leak_whether_email_exists(self):
        User.objects.create_user('taken@company.com', 'taken@company.com', 'x')
        resp = self.client.post(self.url, valid_payload(email='taken@company.com', registration_key='nope'))
        self.assertContains(resp, 'Invalid registration key.')
        self.assertNotContains(resp, 'already exists')

    def test_duplicate_email_rejected_case_insensitively(self):
        User.objects.create_user('taken@company.com', 'taken@company.com', 'x')
        resp = self.client.post(self.url, valid_payload(email='TAKEN@company.com'))
        self.assertContains(resp, 'An account with this email already exists.')
        self.assertEqual(User.objects.filter(email__iexact='taken@company.com').count(), 1)

    def test_password_rules_enforced(self):
        for bad, why in (('short1!', 'too short'), ('password123', 'common'), ('1234567890123', 'numeric')):
            resp = self.client.post(self.url, valid_payload(password=bad, confirm_password=bad))
            self.assertEqual(resp.status_code, 200, why)
            self.assertFalse(User.objects.filter(email='priya@company.com').exists(), why)

    def test_password_similar_to_email_rejected(self):
        resp = self.client.post(self.url, valid_payload(password='priya@company.com', confirm_password='priya@company.com'))
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_mismatched_confirmation_rejected(self):
        resp = self.client.post(self.url, valid_payload(confirm_password=STRONG + 'x'))
        self.assertContains(resp, 'Passwords do not match.')
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_required_fields(self):
        resp = self.client.post(self.url, valid_payload(name='', email=''))
        self.assertContains(resp, 'This field is required.')
        self.assertFalse(User.objects.exists())

    def test_csrf_is_enforced_on_the_web_form(self):
        strict = Client(enforce_csrf_checks=True)
        self.assertEqual(strict.post(self.url, valid_payload()).status_code, 403)
        self.assertFalse(User.objects.exists())

    def test_lockout_after_repeated_wrong_keys(self):
        for _ in range(5):
            self.client.post(self.url, valid_payload(registration_key='guess'))
        resp = self.client.post(self.url, valid_payload())          # even the CORRECT key is blocked now
        self.assertEqual(resp.status_code, 429)
        self.assertContains(resp, 'Too many incorrect registration keys', status_code=429)
        self.assertFalse(User.objects.filter(email='priya@company.com').exists())

    def test_correct_key_attempts_are_not_counted_against_the_limit(self):
        for i in range(8):
            self.client.post(self.url, valid_payload(email=f'a{i}@company.com'))
        self.assertEqual(User.objects.count(), 8)

    @override_settings(ADMIN_REGISTRATION_KEY='')
    def test_disabled_until_a_key_is_configured(self):
        for resp in (self.client.get(self.url), self.client.post(self.url, valid_payload(registration_key=''))):
            self.assertEqual(resp.status_code, 403)
            self.assertContains(resp, 'Admin registration is not enabled', status_code=403)
        self.assertFalse(User.objects.exists())

    def test_login_page_links_to_registration(self):
        resp = self.client.get(reverse('admin_login'))
        self.assertContains(resp, reverse('admin_register'))


@override_settings(ADMIN_REGISTRATION_KEY=KEY)
class AdminRegisterAPITests(TestCase):
    def setUp(self):
        cache.clear()
        self.url = reverse('api_admin_register')
        self.api = Client(enforce_csrf_checks=True)       # prove no CSRF token is needed

    def post(self, payload, raw=None):
        body = raw if raw is not None else json.dumps(payload)
        return self.api.post(self.url, body, content_type='application/json')

    def test_creates_an_admin(self):
        resp = self.post(valid_payload())
        self.assertEqual(resp.status_code, 201)
        body = resp.json()
        self.assertEqual(body['email'], 'priya@company.com')
        self.assertEqual(body['name'], 'Priya Sharma')
        self.assertEqual(body['role'], 'admin')
        self.assertEqual(body['phone'], '+919876543210')
        user = User.objects.get(pk=body['id'])
        self.assertTrue(user.check_password(STRONG))
        self.assertEqual(user.profile.role, UserProfile.ROLE_ADMIN)
        self.assertFalse(user.is_staff or user.is_superuser)

    def test_response_never_contains_secrets(self):
        text = self.post(valid_payload()).content.decode()
        self.assertNotIn(STRONG, text)
        self.assertNotIn(KEY, text)
        self.assertNotIn('password', text.lower())

    def test_does_not_log_the_caller_in_or_set_a_session(self):
        resp = self.post(valid_payload())
        self.assertEqual(resp.status_code, 201)
        # Inspect the response itself: merely reading client.session would create a cookie.
        self.assertEqual(len(resp.cookies), 0)
        self.assertNotIn('sessionid', self.api.cookies)
        self.assertNotIn('_auth_user_id', self.api.session)

    def test_new_admin_can_authenticate(self):
        self.post(valid_payload())
        self.assertIsNotNone(authenticate(username='priya@company.com', password=STRONG))

    def test_confirm_password_is_optional_but_checked_when_sent(self):
        payload = valid_payload()
        del payload['confirm_password']
        self.assertEqual(self.post(payload).status_code, 201)
        resp = self.post(valid_payload(email='b@company.com', confirm_password='nope'))
        self.assertEqual(resp.status_code, 400)
        self.assertIn('confirm_password', resp.json()['errors'])

    def test_missing_or_wrong_key_is_403(self):
        payload = valid_payload()
        del payload['registration_key']
        self.assertEqual(self.post(payload).status_code, 403)
        resp = self.post(valid_payload(registration_key='wrong'))
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(resp.json(), {'error': 'Invalid registration key.'})
        self.assertFalse(User.objects.exists())

    def test_wrong_key_reveals_nothing_about_other_fields(self):
        User.objects.create_user('taken@company.com', 'taken@company.com', 'x')
        resp = self.post(valid_payload(email='taken@company.com', registration_key='wrong', password='x'))
        self.assertEqual(resp.status_code, 403)
        self.assertNotIn('exists', resp.content.decode())
        self.assertNotIn('errors', resp.json())

    def test_validation_errors_are_400_with_field_messages(self):
        resp = self.post(valid_payload(email='not-an-email', password='password123', confirm_password='password123', name=''))
        self.assertEqual(resp.status_code, 400)
        errors = resp.json()['errors']
        self.assertIn('email', errors)
        self.assertIn('password', errors)
        self.assertIn('name', errors)
        self.assertFalse(User.objects.exists())

    def test_duplicate_email_is_400(self):
        self.post(valid_payload())
        resp = self.post(valid_payload(email='PRIYA@company.com'))
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.json()['errors']['email'], ['An account with this email already exists.'])

    def test_only_post_allowed(self):
        for method in ('get', 'put', 'delete', 'patch'):
            resp = getattr(self.api, method)(self.url)
            self.assertEqual(resp.status_code, 405, method)
            self.assertEqual(resp['Allow'], 'POST')
            self.assertIn('error', resp.json())

    def test_malformed_bodies_are_400(self):
        self.assertEqual(self.post(None, raw='{not json').status_code, 400)
        self.assertEqual(self.post(None, raw='').status_code, 400)
        self.assertEqual(self.post(None, raw='["a", "list"]').status_code, 400)
        self.assertEqual(self.post(None, raw='"just a string"').status_code, 400)

    def test_lockout_returns_429_with_retry_after(self):
        for _ in range(5):
            self.assertEqual(self.post(valid_payload(registration_key='guess')).status_code, 403)
        resp = self.post(valid_payload())                       # correct key, but locked out
        self.assertEqual(resp.status_code, 429)
        self.assertEqual(resp['Retry-After'], '900')
        self.assertFalse(User.objects.exists())

    @override_settings(ADMIN_REGISTRATION_KEY='')
    def test_disabled_without_a_configured_key(self):
        resp = self.post(valid_payload(registration_key=''))
        self.assertEqual(resp.status_code, 403)
        self.assertIn('not enabled', resp.json()['error'])

    def test_api_and_web_form_share_rules(self):
        """Same weak password is refused by both entry points."""
        weak = valid_payload(password='password123', confirm_password='password123')
        self.assertEqual(self.post(weak).status_code, 400)
        self.client.post(reverse('admin_register'), weak)
        self.assertFalse(User.objects.exists())


class DistributorRegistrationTests(TestCase):
    password = 'Correct-Horse-9!battery'

    def test_registration_creates_distributor_and_redirects_to_login(self):
        response = self.client.post(reverse('distributor_register'), {
            'name': 'Ravi Patel',
            'email': 'ravi@distributorco.com',
            'phone': '+919876543210',
            'password': self.password,
            'confirm_password': self.password,
        }, follow=True)
        self.assertRedirects(response, reverse('distributor_login'))
        user = User.objects.get(email='ravi@distributorco.com')
        self.assertTrue(user.check_password(self.password))
        self.assertEqual(user.profile.role, UserProfile.ROLE_DISTRIBUTOR)
        self.assertEqual(user.get_full_name(), 'Ravi Patel')

    def test_registration_rejects_mismatched_password_confirmation(self):
        response = self.client.post(reverse('distributor_register'), {
            'name': 'Ravi Patel',
            'email': 'ravi@distributorco.com',
            'phone': '+919876543210',
            'password': self.password,
            'confirm_password': 'Not-the-same-Password1!',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Passwords do not match.')
        self.assertFalse(User.objects.filter(email='ravi@distributorco.com').exists())


@override_settings(
    EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
    OTP_RESEND_COOLDOWN_SECONDS=0,
)
class AdminPasswordRecoveryTests(TestCase):
    old_password = 'Original$Password82!'
    new_password = 'Saffron$Cobalt47!River'

    def setUp(self):
        cache.clear()
        mail.outbox = []
        self.admin = User.objects.create_user(
            username='admin@company.com',
            email='admin@company.com',
            password=self.old_password,
            first_name='Priya',
            last_name='Sharma',
        )
        UserProfile.objects.create(user=self.admin, role=UserProfile.ROLE_ADMIN)
        self.forgot_url = reverse('admin_forgot_password')
        self.verify_url = reverse('admin_verify_otp')

    def start_reset(self, email='admin@company.com'):
        response = self.client.post(self.forgot_url, {'email': email})
        self.assertRedirects(response, self.verify_url)
        return response

    def get_email_otp(self):
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(mail.outbox[0].to, ['admin@company.com'])
        match = re.search(r'one-time password is (\d{6})', mail.outbox[0].body)
        self.assertIsNotNone(match, mail.outbox[0].body)
        return match.group(1)

    def reset_payload(self, otp):
        return {
            'otp': otp,
            'new_password': self.new_password,
            'confirm_password': self.new_password,
        }

    @patch('accounts.models.random.randint', return_value=654321)
    def test_otp_generation_uses_the_requested_six_digit_random_logic(self, randint):
        self.assertEqual(OTP.generate_code(), '654321')
        randint.assert_called_once_with(100000, 999999)

    def test_smtp_missing_credentials_shows_delivery_error_instead_of_claiming_success(self):
        with self.settings(
            EMAIL_BACKEND='django.core.mail.backends.smtp.EmailBackend',
            EMAIL_HOST='smtp.gmail.com',
            EMAIL_HOST_USER='',
            EMAIL_HOST_PASSWORD='',
            DEFAULT_FROM_EMAIL='no-reply@example.com',
        ):
            response = self.client.post(self.forgot_url, {'email': 'admin@company.com'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'The OTP email could not be sent')
        self.assertFalse(OTP.objects.filter(email='admin@company.com').exists())
        self.assertEqual(mail.outbox, [])

    def test_admin_login_has_a_dedicated_forgot_password_link(self):
        response = self.client.get(reverse('admin_login'))
        self.assertContains(response, self.forgot_url)

    def test_admin_otp_is_emailed_and_password_is_reset(self):
        self.start_reset()
        otp = self.get_email_otp()
        response = self.client.post(self.verify_url, self.reset_payload(otp), follow=True)
        self.assertRedirects(response, reverse('admin_login'))
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password(self.new_password))
        self.assertFalse(self.admin.check_password(self.old_password))
        reset_record = OTP.objects.get(email='admin@company.com')
        self.assertTrue(reset_record.is_used)
        self.assertContains(response, 'Password reset successfully')

    def test_otp_is_not_exposed_in_debug_page_messages(self):
        response = self.client.post(self.forgot_url, {'email': 'admin@company.com'}, follow=True)
        code = self.get_email_otp()
        self.assertNotContains(response, code)

    def test_invalid_code_does_not_change_password(self):
        self.start_reset()
        otp = self.get_email_otp()
        wrong_code = f'{(int(otp) + 1) % 1_000_000:06d}'
        response = self.client.post(self.verify_url, self.reset_payload(wrong_code))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'invalid or has expired')
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password(self.old_password))

    def test_expired_code_is_rejected(self):
        self.start_reset()
        otp_code = self.get_email_otp()
        OTP.objects.filter(email='admin@company.com').update(
            created_at=timezone.now() - timedelta(minutes=20)
        )
        response = self.client.post(self.verify_url, self.reset_payload(otp_code))
        self.assertContains(response, 'invalid or has expired')
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password(self.old_password))

    def test_passwords_must_match_and_satisfy_project_policy(self):
        self.start_reset()
        otp_code = self.get_email_otp()
        payload = self.reset_payload(otp_code)
        payload['confirm_password'] = 'Different$Password1!'
        response = self.client.post(self.verify_url, payload)
        self.assertContains(response, 'Passwords do not match.')
        self.assertFalse(OTP.objects.get(email='admin@company.com').is_used)

        payload.update(new_password='password', confirm_password='password')
        response = self.client.post(self.verify_url, payload)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['form'].errors.get('new_password'))
        self.assertFalse(OTP.objects.get(email='admin@company.com').is_used)

    def test_otp_can_only_be_used_once(self):
        self.start_reset()
        otp_code = self.get_email_otp()
        self.client.post(self.verify_url, self.reset_payload(otp_code))
        response = self.client.post(self.verify_url, self.reset_payload(otp_code))
        self.assertRedirects(response, self.forgot_url)
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password(self.new_password))

    def test_resend_invalidates_previous_code_and_sends_a_new_email(self):
        self.start_reset()
        self.get_email_otp()
        first_otp = OTP.objects.get(email='admin@company.com')

        response = self.client.post(reverse('admin_resend_otp'))
        self.assertRedirects(response, self.verify_url)
        self.assertEqual(len(mail.outbox), 2)
        self.assertTrue(OTP.objects.get(pk=first_otp.pk).is_used)
        second_code_match = re.search(
            r'one-time password is (\d{6})', mail.outbox[1].body
        )
        self.assertIsNotNone(second_code_match)
        second_code = second_code_match.group(1)
        latest_otp = OTP.objects.filter(email='admin@company.com').first()
        self.assertEqual(latest_otp.code, second_code)
        self.assertFalse(latest_otp.is_used)

        # Whether or not the randomly generated values happen to match, the
        # first record is marked used and the most recently issued OTP works.
        response = self.client.post(self.verify_url, self.reset_payload(second_code))
        self.assertRedirects(response, reverse('admin_login'))
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password(self.new_password))

    def test_five_incorrect_codes_invalidate_the_otp(self):
        self.start_reset()
        code = self.get_email_otp()
        wrong_code = f'{(int(code) + 1) % 1_000_000:06d}'
        for _ in range(5):
            self.client.post(self.verify_url, self.reset_payload(wrong_code))

        response = self.client.post(self.verify_url, self.reset_payload(code))
        self.assertRedirects(response, self.forgot_url)
        self.admin.refresh_from_db()
        self.assertTrue(self.admin.check_password(self.old_password))
        self.assertTrue(OTP.objects.get(email='admin@company.com').is_used)

    def test_admin_recovery_does_not_send_codes_to_distributor_accounts(self):
        distributor = User.objects.create_user(
            username='distributor@company.com',
            email='distributor@company.com',
            password=self.old_password,
        )
        UserProfile.objects.create(user=distributor, role=UserProfile.ROLE_DISTRIBUTOR)
        self.start_reset(email='distributor@company.com')
        self.assertEqual(mail.outbox, [])
        response = self.client.post(
            self.verify_url, self.reset_payload('123456')
        )
        self.assertContains(response, 'invalid or has expired')
        distributor.refresh_from_db()
        self.assertTrue(distributor.check_password(self.old_password))

    def test_badly_configured_or_unknown_email_gets_same_generic_next_step(self):
        known = self.client.post(self.forgot_url, {'email': 'admin@company.com'})
        self.assertRedirects(known, self.verify_url)
        self.client.get(self.forgot_url)
        cache.clear()
        self.client.cookies.clear()
        unknown_client = Client()
        unknown = unknown_client.post(self.forgot_url, {'email': 'missing@company.com'})
        self.assertEqual(known.status_code, unknown.status_code)
        self.assertEqual(known['Location'], unknown['Location'])


@override_settings(
    EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
    OTP_RESEND_COOLDOWN_SECONDS=0,
)
class DistributorPasswordRecoveryTests(TestCase):
    def setUp(self):
        cache.clear()
        mail.outbox = []
        self.old_password = 'Original$Password82!'
        self.new_password = 'Saffron$Cobalt47!River'
        self.distributor = User.objects.create_user(
            username='seller@company.com',
            email='seller@company.com',
            password=self.old_password,
        )
        UserProfile.objects.create(
            user=self.distributor, role=UserProfile.ROLE_DISTRIBUTOR
        )

    def test_distributor_flow_still_resets_only_distributor_password(self):
        response = self.client.post(
            reverse('forgot_password'), {'email': 'seller@company.com'}
        )
        self.assertRedirects(response, reverse('verify_otp'))
        otp = re.search(r'one-time password is (\d{6})', mail.outbox[0].body).group(1)
        response = self.client.post(reverse('verify_otp'), {
            'otp': otp,
            'new_password': self.new_password,
            'confirm_password': self.new_password,
        })
        self.assertRedirects(response, reverse('distributor_login'))
        self.distributor.refresh_from_db()
        self.assertTrue(self.distributor.check_password(self.new_password))
