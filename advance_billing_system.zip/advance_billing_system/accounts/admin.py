from django.contrib import admin

from .models import OTP, UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'phone', 'created_at')
    list_filter = ('role',)
    search_fields = ('user__username', 'user__email', 'phone')


@admin.register(OTP)
class OTPAdmin(admin.ModelAdmin):
    list_display = ('email', 'purpose', 'is_used', 'attempts', 'created_at')
    list_filter = ('purpose', 'is_used')
    search_fields = ('email',)
    readonly_fields = ('code_hash', 'attempts', 'created_at')
