from django.contrib import admin

from .models import OTP, UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'phone', 'created_at')
    list_filter = ('role',)
    search_fields = ('user__username', 'user__email', 'phone')


@admin.register(OTP)
class OTPAdmin(admin.ModelAdmin):
    # OTPs are credentials: never expose them through Django's admin UI.
    list_display = ('email', 'purpose', 'is_used', 'created_at')
    list_filter = ('purpose', 'is_used')
    search_fields = ('email',)
    readonly_fields = ('created_at',)
    exclude = ('code',)

    def has_add_permission(self, request):
        return False
