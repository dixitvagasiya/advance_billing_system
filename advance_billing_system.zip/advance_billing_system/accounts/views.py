from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.db import IntegrityError
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from .forms import (
    AdminRegistrationForm,
    DistributorRegistrationForm,
    ForgotPasswordForm,
    LoginForm,
    OTPVerifyForm,
    ProfileUpdateForm,
)
from . import services
from .models import OTP, UserProfile

RESET_SESSION_KEY = 'password_reset_email'


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _role_login(request, role, dashboard_url_name):
    """Shared login handler for both Admin and Distributor (task 1 & 2).

    Returns an HttpResponse (redirect) when login succeeds or the user is
    already authenticated; otherwise returns the LoginForm to render.
    """
    if request.user.is_authenticated:
        return redirect(dashboard_url_name)

    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        email = form.cleaned_data['email'].lower().strip()
        password = form.cleaned_data['password']
        user = authenticate(request, username=email, password=password)

        if user is not None and hasattr(user, 'profile') and user.profile.role == role:
            auth_login(request, user)
            return redirect(dashboard_url_name)

        messages.error(request, 'Invalid credentials, or this account is not registered for this portal.')

    return form


def _send_otp_email(email, code):
    """Send the OTP by email; falls back to the console backend in dev."""
    send_mail(
        subject='Your Advance Billing System OTP',
        message=(
            f'Your one-time password is {code}.\n'
            f'It is valid for {settings.OTP_VALIDITY_MINUTES} minutes.\n\n'
            'If you did not request this, you can ignore this email.'
        ),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[email],
        fail_silently=True,
    )


# ---------------------------------------------------------------------------
# Admin auth (task 1, 2)
# ---------------------------------------------------------------------------

def admin_login_view(request):
    result = _role_login(request, UserProfile.ROLE_ADMIN, 'admin_dashboard')
    if isinstance(result, HttpResponse):
        return result
    return render(request, 'accounts/admin_login.html', {'form': result})


def admin_register_view(request):
    """Front-end admin registration page.

    Gated by settings.ADMIN_REGISTRATION_KEY (see services.py): the page is
    inert until a key is configured, and repeated wrong keys are throttled.
    The JSON API at api_admin_register uses the same form and service code.
    """
    template = 'accounts/admin_register.html'

    if not services.key_is_configured():
        return render(request, template, {'state': 'disabled'}, status=403)
    if services.is_locked_out(request):
        minutes = max(1, settings.ADMIN_REGISTRATION_LOCKOUT_SECONDS // 60)
        return render(request, template, {'state': 'locked', 'minutes': minutes}, status=429)

    form = AdminRegistrationForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            try:
                services.create_admin_user(
                    name=form.cleaned_data['name'],
                    email=form.cleaned_data['email'],
                    phone=form.cleaned_data['phone'],
                    password=form.cleaned_data['password'],
                )
            except IntegrityError:   # lost a race with a concurrent identical sign-up
                form.add_error('email', 'An account with this email already exists.')
            else:
                messages.success(request, 'Admin account created successfully. Please sign in.')
                return redirect('admin_login')
        elif form.key_failed:
            services.record_failed_key(request)

    return render(request, template, {'form': form, 'state': 'form'})


# ---------------------------------------------------------------------------
# Distributor auth (task 1, 2)
# ---------------------------------------------------------------------------

def distributor_login_view(request):
    result = _role_login(request, UserProfile.ROLE_DISTRIBUTOR, 'distributor_dashboard')
    if isinstance(result, HttpResponse):
        return result
    return render(request, 'accounts/distributor_login.html', {'form': result})


def distributor_register_view(request):
    """Task 4 & 8: registration form, saved to DB, redirect to login with a message."""
    if request.user.is_authenticated:
        return redirect('distributor_dashboard')

    form = DistributorRegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        name = form.cleaned_data['name'].strip()
        email = form.cleaned_data['email']
        phone = form.cleaned_data['phone']
        password = form.cleaned_data['password']

        first_name, _, last_name = name.partition(' ')
        user = User.objects.create_user(
            username=email, email=email, password=password,
            first_name=first_name, last_name=last_name,
        )
        UserProfile.objects.create(user=user, role=UserProfile.ROLE_DISTRIBUTOR, phone=phone)

        messages.success(request, 'Account created successfully. Please log in.')
        return redirect('distributor_login')

    return render(request, 'accounts/distributor_register.html', {'form': form})


# ---------------------------------------------------------------------------
# Forgot password / OTP (task 5, 6)
# ---------------------------------------------------------------------------

def forgot_password_view(request):
    form = ForgotPasswordForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        email = form.cleaned_data['email'].lower().strip()
        if User.objects.filter(email__iexact=email).exists():
            otp = OTP.issue(email)
            _send_otp_email(email, otp.code)
            request.session[RESET_SESSION_KEY] = email
            if settings.DEBUG:
                messages.info(request, f'Debug mode: your OTP is {otp.code} (also printed to the server console).')
            return redirect('verify_otp')
        messages.error(request, 'No account found with that email address.')

    return render(request, 'accounts/forgot_password.html', {'form': form})


def resend_otp_view(request):
    email = request.session.get(RESET_SESSION_KEY)
    if not email:
        messages.error(request, 'Your reset session expired. Please start again.')
        return redirect('forgot_password')

    otp = OTP.issue(email)
    _send_otp_email(email, otp.code)
    messages.success(request, 'A new OTP has been sent.')
    if settings.DEBUG:
        messages.info(request, f'Debug mode: your OTP is {otp.code}.')
    return redirect('verify_otp')


def verify_otp_view(request):
    email = request.session.get(RESET_SESSION_KEY)
    if not email:
        messages.error(request, 'Your reset session expired. Please start again.')
        return redirect('forgot_password')

    form = OTPVerifyForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        code = form.cleaned_data['otp']
        otp = OTP.objects.filter(email=email, code=code, purpose=OTP.PURPOSE_PASSWORD_RESET).first()

        if otp and otp.is_valid():
            otp.is_used = True
            otp.save(update_fields=['is_used'])

            user = get_object_or_404(User, email__iexact=email)
            user.set_password(form.cleaned_data['new_password'])
            user.save()

            del request.session[RESET_SESSION_KEY]
            messages.success(request, 'Password reset. Please log in with your new password.')
            return redirect('distributor_login')

        messages.error(request, 'That code is invalid or has expired. Try again or resend a new one.')

    return render(request, 'accounts/verify_otp.html', {'form': form, 'email': email})


# ---------------------------------------------------------------------------
# Profile & dashboards (task 7)
# ---------------------------------------------------------------------------

@login_required(login_url='distributor_login')
def distributor_profile_view(request):
    return render(request, 'accounts/distributor_profile.html', {'profile': request.user.profile})


@login_required(login_url='distributor_login')
def distributor_profile_update_view(request):
    user = request.user
    initial = {'name': user.get_full_name() or user.username, 'phone': user.profile.phone}
    form = ProfileUpdateForm(request.POST or None, initial=initial)

    if request.method == 'POST' and form.is_valid():
        name = form.cleaned_data['name'].strip()
        first_name, _, last_name = name.partition(' ')
        user.first_name = first_name
        user.last_name = last_name
        user.save(update_fields=['first_name', 'last_name'])

        user.profile.phone = form.cleaned_data['phone']
        user.profile.save(update_fields=['phone'])

        messages.success(request, 'Profile updated.')
        return redirect('distributor_profile')

    return render(request, 'accounts/distributor_profile_form.html', {'form': form})


@login_required(login_url='distributor_login')
def distributor_dashboard_view(request):
    # Local imports avoid a hard app-load-order dependency between apps.
    from billing.models import Invoice
    from customers.models import Customer
    from products.models import Product

    invoices = Invoice.objects.filter(distributor=request.user)
    pending = invoices.exclude(status=Invoice.STATUS_PAID)
    context = {
        'invoice_count': invoices.count(),
        'pending_count': pending.count(),
        'pending_total': sum((inv.total for inv in pending), 0),
        'customer_count': Customer.objects.filter(distributor=request.user).count(),
        'product_count': Product.objects.filter(distributor=request.user).count(),
    }
    return render(request, 'accounts/distributor_dashboard.html', context)


@login_required(login_url='admin_login')
def admin_dashboard_view(request):
    from billing.models import Invoice
    from customers.models import Customer
    from products.models import Product

    invoices = Invoice.objects.all()
    pending = invoices.exclude(status=Invoice.STATUS_PAID)
    context = {
        'invoice_count': invoices.count(),
        'pending_count': pending.count(),
        'pending_total': sum((inv.total for inv in pending), 0),
        'distributor_count': UserProfile.objects.filter(role=UserProfile.ROLE_DISTRIBUTOR).count(),
        'customer_count': Customer.objects.count(),
        'product_count': Product.objects.count(),
    }
    return render(request, 'accounts/admin_dashboard.html', context)


def logout_view(request):
    was_admin = hasattr(request.user, 'profile') and request.user.profile.role == UserProfile.ROLE_ADMIN
    auth_logout(request)
    return redirect('admin_login' if was_admin else 'distributor_login')
