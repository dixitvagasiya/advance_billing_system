from django.conf import settings
from django.core.cache import cache
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.db import IntegrityError, transaction
from django.http import HttpResponse
from django.shortcuts import redirect, render

from .forms import (
    AdminRegistrationForm,
    DistributorRegistrationForm,
    ForgotPasswordForm,
    LoginForm,
    OTPVerifyForm,
    ProfileUpdateForm,
)
from . import services
from .models import OTP, UserProfile

DISTRIBUTOR_RESET_SESSION_KEY = 'password_reset_email'
ADMIN_RESET_SESSION_KEY = 'admin_password_reset_email'


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _role_login(request, role, dashboard_url_name):
    """Shared login handler for both Admin and Distributor (task 1 & 2).

    Returns an HttpResponse (redirect) when login succeeds or the user is
    already authenticated; otherwise returns the LoginForm to render.
    """
    if request.user.is_authenticated:
        return redirect(dashboard_url_name)

    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        email = form.cleaned_data['email'].lower().strip()
        password = form.cleaned_data['password']
        user = authenticate(request, username=email, password=password)

        if user is not None and hasattr(user, 'profile') and user.profile.role == role:
            auth_login(request, user)
            return redirect(dashboard_url_name)

        messages.error(request, 'Invalid credentials, or this account is not registered for this portal.')

    return form


def _send_otp_email(email, code):
    """Send the password-reset OTP through the configured email backend.

    This function raises on failed delivery. It never reports a successful send
    merely because a code was generated or saved in the database.
    """
    sent = send_mail(
        subject='Your Advance Billing System password reset code',
        message=(
            f'Your one-time password is {code}.\n'
            f'It is valid for {settings.OTP_VALIDITY_MINUTES} minutes.\n\n'
            'If you did not request this, you can ignore this email.'
        ),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[email],
        fail_silently=False,
    )
    if sent != 1:
        raise RuntimeError('The password reset email was not accepted for delivery.')


def _otp_throttle_key(role, email):
    """Build a cache key without storing a raw email address in the key."""
    import hashlib

    digest = hashlib.sha256(email.lower().encode('utf-8')).hexdigest()
    return f'password-reset-send:{role}:{digest}'


def _otp_attempts_key(role, email):
    import hashlib

    digest = hashlib.sha256(email.lower().encode('utf-8')).hexdigest()
    return f'password-reset-attempts:{role}:{digest}'


def _smtp_email_is_configured():
    """Return False when SMTP is selected but required credentials are absent."""
    backend = getattr(settings, 'EMAIL_BACKEND', '')
    if backend == 'django.core.mail.backends.smtp.EmailBackend':
        return bool(
            getattr(settings, 'EMAIL_HOST', '')
            and getattr(settings, 'EMAIL_HOST_USER', '')
            and getattr(settings, 'EMAIL_HOST_PASSWORD', '')
            and getattr(settings, 'DEFAULT_FROM_EMAIL', '')
        )
    # LocMemEmailBackend is useful for automated tests; other configured
    # backends are allowed to decide delivery and report any errors themselves.
    return True


def _send_password_reset_otp(email, role):
    """Issue and email an OTP, returning a precise internal delivery status."""
    if not _smtp_email_is_configured():
        return 'configuration_error'

    cooldown = max(0, int(getattr(settings, 'OTP_RESEND_COOLDOWN_SECONDS', 60)))
    throttle_key = _otp_throttle_key(role, email)
    if cache.get(throttle_key):
        return 'throttled'
    if cooldown:
        cache.set(throttle_key, True, timeout=cooldown)

    # Consume cooldown for unknown emails too, reducing enumeration and flooding.
    user_exists = User.objects.filter(
        email__iexact=email, profile__role=role
    ).exists()
    if not user_exists:
        return 'unknown_account'

    otp = OTP.issue(email)
    cache.delete(_otp_attempts_key(role, email))
    try:
        _send_otp_email(email, otp.code)
    except Exception:
        # Never leave a code active when it could not be delivered.
        OTP.objects.filter(pk=otp.pk, is_used=False).update(is_used=True)
        cache.delete(throttle_key)
        import logging
        logging.getLogger(__name__).exception('Unable to send password reset email')
        return 'delivery_error'
    return 'sent'


def _forgot_password_for_role(request, *, role, session_key, verify_url_name,
                              login_url_name, portal_label):
    form = ForgotPasswordForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        email = form.cleaned_data['email'].lower().strip()
        status = _send_password_reset_otp(email, role)

        if status in {'configuration_error', 'delivery_error'}:
            request.session.pop(session_key, None)
            messages.error(
                request,
                'The OTP email could not be sent. Configure and check the SMTP settings '
                'in the project .env file, then try again. No usable OTP was issued.'
            )
            return render(request, 'accounts/forgot_password.html', {
                'form': form,
                'login_url_name': login_url_name,
                'portal_label': portal_label,
            })

        request.session[session_key] = email
        if status == 'throttled':
            messages.warning(
                request,
                'A reset email was requested recently. Please check your inbox and spam folder, '
                'or wait before requesting another code.'
            )
        else:
            messages.info(
                request,
                f'If an account exists for that email in the {portal_label}, '
                'a password reset code has been sent. Check your inbox and spam folder.'
            )
        return redirect(verify_url_name)

    return render(request, 'accounts/forgot_password.html', {
        'form': form,
        'login_url_name': login_url_name,
        'portal_label': portal_label,
    })


def _resend_otp_for_role(request, *, role, session_key, verify_url_name):
    email = request.session.get(session_key)
    if not email:
        messages.error(request, 'Your reset session expired. Please start again.')
        return redirect('admin_forgot_password' if role == UserProfile.ROLE_ADMIN else 'forgot_password')

    status = _send_password_reset_otp(email, role)
    if status in {'configuration_error', 'delivery_error'}:
        messages.error(
            request,
            'The new OTP email could not be sent. Check the SMTP settings in .env. '
            'Request a new code after fixing email delivery.'
        )
    elif status == 'throttled':
        messages.warning(request, 'Please wait for the resend cooldown before requesting another OTP.')
    else:
        messages.info(request, 'If the account exists, a new code has been sent. Check your inbox and spam folder.')
    return redirect(verify_url_name)


def _record_failed_otp_attempt(role, email):
    attempts_key = _otp_attempts_key(role, email)
    attempts = cache.get(attempts_key, 0)
    if attempts == 0:
        cache.set(attempts_key, 1, timeout=settings.OTP_VALIDITY_MINUTES * 60)
    else:
        try:
            cache.incr(attempts_key)
        except ValueError:
            cache.set(attempts_key, 1, timeout=settings.OTP_VALIDITY_MINUTES * 60)
    return cache.get(attempts_key, 1)


def _verify_otp_for_role(request, *, role, session_key, login_url_name, portal_label):
    email = request.session.get(session_key)
    forgot_url_name = 'admin_forgot_password' if role == UserProfile.ROLE_ADMIN else 'forgot_password'
    if not email:
        messages.error(request, 'Your reset session expired. Please start again.')
        return redirect(forgot_url_name)

    user = User.objects.filter(email__iexact=email, profile__role=role).first()
    form = OTPVerifyForm(request.POST or None, user=user)
    attempts_key = _otp_attempts_key(role, email)
    max_attempts = max(1, int(getattr(settings, 'OTP_MAX_ATTEMPTS', 5)))

    if request.method == 'POST':
        code = (request.POST.get('otp') or '').strip()
        code_well_formed = len(code) == 6 and code.isdigit()
        otp = None
        if code_well_formed:
            otp = OTP.objects.filter(
                email__iexact=email,
                code=code,
                purpose=OTP.PURPOSE_PASSWORD_RESET,
            ).first()
        otp_valid = user is not None and otp is not None and otp.is_valid()

        # Count every well-formed wrong/expired code, even if the submitted new
        # password also fails validation, so password-field errors cannot be
        # used to bypass the OTP brute-force attempt limit.
        if code_well_formed and not otp_valid:
            attempts = _record_failed_otp_attempt(role, email)
            if attempts >= max_attempts:
                OTP.objects.filter(email__iexact=email, is_used=False).update(is_used=True)
                cache.delete(_otp_throttle_key(role, email))
                messages.error(request, 'Too many incorrect codes. Please request a new code.')
                return redirect(forgot_url_name)
            messages.error(request, 'That code is invalid or has expired. Try again or request a new one.')

        if form.is_valid() and otp_valid:
            # Conditional update ensures an OTP can be consumed only once, even
            # if two reset submissions race each other.
            with transaction.atomic():
                consumed = OTP.objects.filter(pk=otp.pk, is_used=False).update(is_used=True)
                if consumed:
                    user.set_password(form.cleaned_data['new_password'])
                    user.save(update_fields=['password'])

            if consumed:
                request.session.pop(session_key, None)
                cache.delete(attempts_key)
                cache.delete(_otp_throttle_key(role, email))
                messages.success(request, 'Password reset successfully. Please sign in with your new password.')
                return redirect(login_url_name)

            messages.error(request, 'That code is invalid or has expired. Try again or request a new one.')

    return render(request, 'accounts/verify_otp.html', {
        'form': form,
        'email': email,
        'login_url_name': login_url_name,
        'portal_label': portal_label,
        'resend_url_name': 'admin_resend_otp' if role == UserProfile.ROLE_ADMIN else 'resend_otp',
    })


# ---------------------------------------------------------------------------
# Admin auth (task 1, 2)
# ---------------------------------------------------------------------------

def admin_login_view(request):
    result = _role_login(request, UserProfile.ROLE_ADMIN, 'admin_dashboard')
    if isinstance(result, HttpResponse):
        return result
    return render(request, 'accounts/admin_login.html', {'form': result})


def admin_register_view(request):
    """Front-end admin registration page.

    Gated by settings.ADMIN_REGISTRATION_KEY (see services.py): the page is
    inert until a key is configured, and repeated wrong keys are throttled.
    The JSON API at api_admin_register uses the same form and service code.
    """
    template = 'accounts/admin_register.html'

    if not services.key_is_configured():
        return render(request, template, {'state': 'disabled'}, status=403)
    if services.is_locked_out(request):
        minutes = max(1, settings.ADMIN_REGISTRATION_LOCKOUT_SECONDS // 60)
        return render(request, template, {'state': 'locked', 'minutes': minutes}, status=429)

    form = AdminRegistrationForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            try:
                services.create_admin_user(
                    name=form.cleaned_data['name'],
                    email=form.cleaned_data['email'],
                    phone=form.cleaned_data['phone'],
                    password=form.cleaned_data['password'],
                )
            except IntegrityError:   # lost a race with a concurrent identical sign-up
                form.add_error('email', 'An account with this email already exists.')
            else:
                messages.success(request, 'Admin account created successfully. Please sign in.')
                return redirect('admin_login')
        elif form.key_failed:
            services.record_failed_key(request)

    return render(request, template, {'form': form, 'state': 'form'})


# ---------------------------------------------------------------------------
# Distributor auth (task 1, 2)
# ---------------------------------------------------------------------------

def distributor_login_view(request):
    result = _role_login(request, UserProfile.ROLE_DISTRIBUTOR, 'distributor_dashboard')
    if isinstance(result, HttpResponse):
        return result
    return render(request, 'accounts/distributor_login.html', {'form': result})


def distributor_register_view(request):
    """Task 4 & 8: registration form, saved to DB, redirect to login with a message."""
    if request.user.is_authenticated:
        return redirect('distributor_dashboard')

    form = DistributorRegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        name = form.cleaned_data['name'].strip()
        email = form.cleaned_data['email']
        phone = form.cleaned_data['phone']
        password = form.cleaned_data['password']

        first_name, _, last_name = name.partition(' ')
        user = User.objects.create_user(
            username=email, email=email, password=password,
            first_name=first_name, last_name=last_name,
        )
        UserProfile.objects.create(user=user, role=UserProfile.ROLE_DISTRIBUTOR, phone=phone)

        messages.success(request, 'Account created successfully. Please log in.')
        return redirect('distributor_login')

    return render(request, 'accounts/distributor_register.html', {'form': form})


# ---------------------------------------------------------------------------
# Forgot password / OTP
# ---------------------------------------------------------------------------

def admin_forgot_password_view(request):
    """Password recovery restricted to accounts with the Admin portal role."""
    return _forgot_password_for_role(
        request,
        role=UserProfile.ROLE_ADMIN,
        session_key=ADMIN_RESET_SESSION_KEY,
        verify_url_name='admin_verify_otp',
        login_url_name='admin_login',
        portal_label='Admin Portal',
    )


def forgot_password_view(request):
    """Distributor password recovery; Admin recovery has dedicated routes."""
    return _forgot_password_for_role(
        request,
        role=UserProfile.ROLE_DISTRIBUTOR,
        session_key=DISTRIBUTOR_RESET_SESSION_KEY,
        verify_url_name='verify_otp',
        login_url_name='distributor_login',
        portal_label='Distributor Portal',
    )


@require_POST
def admin_resend_otp_view(request):
    return _resend_otp_for_role(
        request,
        role=UserProfile.ROLE_ADMIN,
        session_key=ADMIN_RESET_SESSION_KEY,
        verify_url_name='admin_verify_otp',
    )


@require_POST
def resend_otp_view(request):
    return _resend_otp_for_role(
        request,
        role=UserProfile.ROLE_DISTRIBUTOR,
        session_key=DISTRIBUTOR_RESET_SESSION_KEY,
        verify_url_name='verify_otp',
    )


def admin_verify_otp_view(request):
    return _verify_otp_for_role(
        request,
        role=UserProfile.ROLE_ADMIN,
        session_key=ADMIN_RESET_SESSION_KEY,
        login_url_name='admin_login',
        portal_label='Admin Portal',
    )


def verify_otp_view(request):
    return _verify_otp_for_role(
        request,
        role=UserProfile.ROLE_DISTRIBUTOR,
        session_key=DISTRIBUTOR_RESET_SESSION_KEY,
        login_url_name='distributor_login',
        portal_label='Distributor Portal',
    )


# ---------------------------------------------------------------------------
# Profile & dashboards (task 7)
# ---------------------------------------------------------------------------

@login_required(login_url='distributor_login')
def distributor_profile_view(request):
    return render(request, 'accounts/distributor_profile.html', {'profile': request.user.profile})


@login_required(login_url='distributor_login')
def distributor_profile_update_view(request):
    user = request.user
    initial = {'name': user.get_full_name() or user.username, 'phone': user.profile.phone}
    form = ProfileUpdateForm(request.POST or None, initial=initial)

    if request.method == 'POST' and form.is_valid():
        name = form.cleaned_data['name'].strip()
        first_name, _, last_name = name.partition(' ')
        user.first_name = first_name
        user.last_name = last_name
        user.save(update_fields=['first_name', 'last_name'])

        user.profile.phone = form.cleaned_data['phone']
        user.profile.save(update_fields=['phone'])

        messages.success(request, 'Profile updated.')
        return redirect('distributor_profile')

    return render(request, 'accounts/distributor_profile_form.html', {'form': form})


@login_required(login_url='distributor_login')
def distributor_dashboard_view(request):
    # Local imports avoid a hard app-load-order dependency between apps.
    from billing.models import Invoice
    from customers.models import Customer
    from products.models import Product

    invoices = Invoice.objects.filter(distributor=request.user)
    pending = invoices.exclude(status=Invoice.STATUS_PAID)
    context = {
        'invoice_count': invoices.count(),
        'pending_count': pending.count(),
        'pending_total': sum((inv.total for inv in pending), 0),
        'customer_count': Customer.objects.filter(distributor=request.user).count(),
        'product_count': Product.objects.filter(distributor=request.user).count(),
    }
    return render(request, 'accounts/distributor_dashboard.html', context)


@login_required(login_url='admin_login')
def admin_dashboard_view(request):
    from billing.models import Invoice
    from customers.models import Customer
    from products.models import Product

    invoices = Invoice.objects.all()
    pending = invoices.exclude(status=Invoice.STATUS_PAID)
    context = {
        'invoice_count': invoices.count(),
        'pending_count': pending.count(),
        'pending_total': sum((inv.total for inv in pending), 0),
        'distributor_count': UserProfile.objects.filter(role=UserProfile.ROLE_DISTRIBUTOR).count(),
        'customer_count': Customer.objects.count(),
        'product_count': Product.objects.count(),
    }
    return render(request, 'accounts/admin_dashboard.html', context)


def logout_view(request):
    was_admin = hasattr(request.user, 'profile') and request.user.profile.role == UserProfile.ROLE_ADMIN
    auth_logout(request)
    return redirect('admin_login' if was_admin else 'distributor_login')
