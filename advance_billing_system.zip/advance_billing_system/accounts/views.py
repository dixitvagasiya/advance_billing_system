from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from .forms import (
    AdminRegistrationForm,
    DistributorRegistrationForm,
    ForgotPasswordForm,
    LoginForm,
    OTPVerifyForm,
    ProfileUpdateForm,
)
from . import recovery, services
from .decorators import admin_required
from .models import OTP, UserProfile

RESET_SESSION_KEY = 'password_reset_email'


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _role_login(request, role, dashboard_url_name):
    """Shared login handler for both Admin and Distributor (task 1 & 2).

    Returns an HttpResponse (redirect) when login succeeds or the user is
    already authenticated; otherwise returns the LoginForm to render.
    """
    if request.user.is_authenticated:
        return redirect(dashboard_url_name)

    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        email = form.cleaned_data['email'].lower().strip()
        password = form.cleaned_data['password']
        user = authenticate(request, username=email, password=password)

        if user is not None and hasattr(user, 'profile') and user.profile.role == role:
            auth_login(request, user)
            return redirect(dashboard_url_name)

        messages.error(request, 'Invalid credentials, or this account is not registered for this portal.')

    return form


# ---------------------------------------------------------------------------
# Admin auth (task 1, 2)
# ---------------------------------------------------------------------------

def admin_login_view(request):
    result = _role_login(request, UserProfile.ROLE_ADMIN, 'admin_dashboard')
    if isinstance(result, HttpResponse):
        return result
    return render(request, 'accounts/admin_login.html', {'form': result})


def admin_register_view(request):
    """Front-end admin registration page.

    Gated by settings.ADMIN_REGISTRATION_KEY (see services.py): the page is
    inert until a key is configured, and repeated wrong keys are throttled.
    The JSON API at api_admin_register uses the same form and service code.
    """
    template = 'accounts/admin_register.html'

    if not services.key_is_configured():
        return render(request, template, {'state': 'disabled'}, status=403)
    if services.is_locked_out(request):
        minutes = max(1, settings.ADMIN_REGISTRATION_LOCKOUT_SECONDS // 60)
        return render(request, template, {'state': 'locked', 'minutes': minutes}, status=429)

    form = AdminRegistrationForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            try:
                services.create_admin_user(
                    name=form.cleaned_data['name'],
                    email=form.cleaned_data['email'],
                    phone=form.cleaned_data['phone'],
                    password=form.cleaned_data['password'],
                )
            except IntegrityError:   # lost a race with a concurrent identical sign-up
                form.add_error('email', 'An account with this email already exists.')
            else:
                messages.success(request, 'Admin account created successfully. Please sign in.')
                return redirect('admin_login')
        elif form.key_failed:
            services.record_failed_key(request)

    return render(request, template, {'form': form, 'state': 'form'})


# ---------------------------------------------------------------------------
# Distributor auth (task 1, 2)
# ---------------------------------------------------------------------------

def distributor_login_view(request):
    result = _role_login(request, UserProfile.ROLE_DISTRIBUTOR, 'distributor_dashboard')
    if isinstance(result, HttpResponse):
        return result
    return render(request, 'accounts/distributor_login.html', {'form': result})


def distributor_register_view(request):
    """Task 4 & 8: registration form, saved to DB, redirect to login with a message."""
    if request.user.is_authenticated:
        return redirect('distributor_dashboard')

    form = DistributorRegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        name = form.cleaned_data['name'].strip()
        email = form.cleaned_data['email']
        phone = form.cleaned_data['phone']
        password = form.cleaned_data['password']

        first_name, _, last_name = name.partition(' ')
        user = User.objects.create_user(
            username=email, email=email, password=password,
            first_name=first_name, last_name=last_name,
        )
        UserProfile.objects.create(user=user, role=UserProfile.ROLE_DISTRIBUTOR, phone=phone)

        messages.success(request, 'Account created successfully. Please log in.')
        return redirect('distributor_login')

    return render(request, 'accounts/distributor_register.html', {'form': form})


# ---------------------------------------------------------------------------
# Forgot password / OTP — one implementation, two portals (Admin, Distributor)
# ---------------------------------------------------------------------------

PORTALS = {
    UserProfile.ROLE_ADMIN: {
        'role': UserProfile.ROLE_ADMIN,
        'badge': 'Admin Portal',
        'session_key': 'admin_password_reset_email',
        'login': 'admin_login',
        'forgot': 'admin_forgot_password',
        'verify': 'admin_verify_otp',
        'resend': 'admin_resend_otp',
    },
    UserProfile.ROLE_DISTRIBUTOR: {
        'role': UserProfile.ROLE_DISTRIBUTOR,
        'badge': 'Distributor Portal',
        'session_key': RESET_SESSION_KEY,
        'login': 'distributor_login',
        'forgot': 'forgot_password',
        'verify': 'verify_otp',
        'resend': 'resend_otp',
    },
}

GENERIC_SENT = "If an account exists for that email, we've sent a 6-digit code. It can take a minute to arrive."


def _portal_ctx(portal):
    return {'portal': {k: (reverse(portal[k]) if k in ('login', 'forgot', 'verify', 'resend') else portal[k])
                       for k in portal}}


def _issue_code(request, portal, email):
    """Request a code and flash a response that is identical whether or not
    the account exists. Returns nothing; the caller redirects to the verify page."""
    try:
        code = recovery.request_otp(email, portal['role'])
    except recovery.Throttled as exc:
        if exc.retry_after >= 3600:
            messages.error(request, 'Too many code requests for this email. Please try again in an hour.')
        else:
            messages.error(request, f'Please wait about {exc.retry_after} seconds before requesting another code.')
        return
    messages.success(request, GENERIC_SENT)
    if settings.DEBUG and code:
        messages.info(request, f'Debug mode: your OTP is {code} (also printed to the server console).')


def _forgot_password(request, portal):
    form = ForgotPasswordForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        email = recovery.normalise(form.cleaned_data['email'])
        request.session[portal['session_key']] = email
        _issue_code(request, portal, email)
        return redirect(portal['verify'])
    ctx = {'form': form, **_portal_ctx(portal)}
    return render(request, 'accounts/forgot_password.html', ctx)


@require_POST
def _resend_otp(request, portal):
    email = request.session.get(portal['session_key'])
    if not email:
        messages.error(request, 'Your reset session expired. Please start again.')
        return redirect(portal['forgot'])
    _issue_code(request, portal, email)
    return redirect(portal['verify'])


def _verify_otp(request, portal):
    email = request.session.get(portal['session_key'])
    if not email:
        messages.error(request, 'Your reset session expired. Please start again.')
        return redirect(portal['forgot'])

    form = OTPVerifyForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        status, problems = recovery.reset_password(
            email, portal['role'], form.cleaned_data['otp'], form.cleaned_data['new_password'])
        if status == recovery.OK:
            request.session.pop(portal['session_key'], None)
            messages.success(request, 'Password reset. Please sign in with your new password.')
            return redirect(portal['login'])
        if status == recovery.WEAK_PASSWORD:
            for problem in problems:
                form.add_error('new_password', problem)
        else:
            messages.error(request, 'That code is invalid or has expired. Try again or request a new one.')

    ctx = {'form': form, 'email': email, 'validity': settings.OTP_VALIDITY_MINUTES, **_portal_ctx(portal)}
    return render(request, 'accounts/verify_otp.html', ctx)


# Distributor portal (existing URL names)
def forgot_password_view(request):
    return _forgot_password(request, PORTALS[UserProfile.ROLE_DISTRIBUTOR])


def verify_otp_view(request):
    return _verify_otp(request, PORTALS[UserProfile.ROLE_DISTRIBUTOR])


def resend_otp_view(request):
    return _resend_otp(request, PORTALS[UserProfile.ROLE_DISTRIBUTOR])


# Admin portal
def admin_forgot_password_view(request):
    return _forgot_password(request, PORTALS[UserProfile.ROLE_ADMIN])


def admin_verify_otp_view(request):
    return _verify_otp(request, PORTALS[UserProfile.ROLE_ADMIN])


def admin_resend_otp_view(request):
    return _resend_otp(request, PORTALS[UserProfile.ROLE_ADMIN])


# ---------------------------------------------------------------------------
# Profile & dashboards (task 7)
# ---------------------------------------------------------------------------

@login_required(login_url='distributor_login')
def distributor_profile_view(request):
    return render(request, 'accounts/distributor_profile.html', {'profile': request.user.profile})


@login_required(login_url='distributor_login')
def distributor_profile_update_view(request):
    user = request.user
    initial = {'name': user.get_full_name() or user.username, 'phone': user.profile.phone}
    form = ProfileUpdateForm(request.POST or None, initial=initial)

    if request.method == 'POST' and form.is_valid():
        name = form.cleaned_data['name'].strip()
        first_name, _, last_name = name.partition(' ')
        user.first_name = first_name
        user.last_name = last_name
        user.save(update_fields=['first_name', 'last_name'])

        user.profile.phone = form.cleaned_data['phone']
        user.profile.save(update_fields=['phone'])

        messages.success(request, 'Profile updated.')
        return redirect('distributor_profile')

    return render(request, 'accounts/distributor_profile_form.html', {'form': form})


@login_required(login_url='distributor_login')
def distributor_dashboard_view(request):
    # Local imports avoid a hard app-load-order dependency between apps.
    from billing.models import Invoice
    from customers.models import Customer
    from products.models import Product

    invoices = Invoice.objects.filter(distributor=request.user)
    pending = invoices.exclude(status=Invoice.STATUS_PAID)
    context = {
        'invoice_count': invoices.count(),
        'pending_count': pending.count(),
        'pending_total': sum((inv.total for inv in pending), 0),
        'customer_count': Customer.objects.filter(distributor=request.user).count(),
        'product_count': Product.objects.filter(distributor=request.user).count(),
    }
    return render(request, 'accounts/distributor_dashboard.html', context)


@admin_required
def admin_dashboard_view(request):
    from billing.models import Invoice
    from customers.models import Customer
    from products.models import Product

    invoices = Invoice.objects.all()
    pending = invoices.exclude(status=Invoice.STATUS_PAID)
    context = {
        'invoice_count': invoices.count(),
        'pending_count': pending.count(),
        'pending_total': sum((inv.total for inv in pending), 0),
        'distributor_count': UserProfile.objects.filter(role=UserProfile.ROLE_DISTRIBUTOR).count(),
        'customer_count': Customer.objects.count(),
        'product_count': Product.objects.count(),
    }
    return render(request, 'accounts/admin_dashboard.html', context)


def logout_view(request):
    was_admin = hasattr(request.user, 'profile') and request.user.profile.role == UserProfile.ROLE_ADMIN
    auth_logout(request)
    return redirect('admin_login' if was_admin else 'distributor_login')
