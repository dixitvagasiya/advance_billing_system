from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied

from .models import UserProfile


def is_admin(user):
    return hasattr(user, 'profile') and user.profile.role == UserProfile.ROLE_ADMIN


def admin_required(view):
    """Signed-in ADMIN accounts only.

    Anonymous visitors are sent to the admin login page; signed-in
    distributors get a 403 (they must never see cross-distributor data).
    """
    @login_required(login_url='admin_login')
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not is_admin(request.user):
            raise PermissionDenied
        return view(request, *args, **kwargs)
    return wrapper
