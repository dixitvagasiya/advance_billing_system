"""JSON API for accounts.

POST /accounts/api/admin/register/
    Create an Admin-role account. Requires the server's registration key.

    Request  (Content-Type: application/json)
        {
          "name": "Priya Sharma",
          "email": "priya@company.com",
          "phone": "+919876543210",            // optional
          "password": "a-strong-password",
          "confirm_password": "a-strong-password",   // optional; checked if sent
          "registration_key": "<ADMIN_REGISTRATION_KEY>"
        }

    Responses
        201 {"id", "name", "email", "phone", "role": "admin"}
        400 {"errors": {"<field>": ["message", ...]}}   validation problems
            {"error": "..."}                            malformed body
        403 {"error": "..."}   wrong/missing key, or registration not enabled
        405 {"error": "..."}   any method other than POST
        429 {"error": "..."}   too many wrong keys from this address

Notes
    * No session or cookie is used or created, so CSRF does not apply and the
      endpoint is csrf_exempt. The caller is authorised solely by the key.
      It does not log the new admin in.
    * The key is checked before anything else, so an unauthorised caller
      learns nothing about existing accounts.
"""
import json

from django.conf import settings
from django.db import IntegrityError
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from . import services
from .forms import AdminRegistrationForm


def _error(message, status, **headers):
    response = JsonResponse({'error': message}, status=status)
    for name, value in headers.items():
        response[name.replace('_', '-')] = value
    return response


@csrf_exempt
def admin_register(request):
    if request.method != 'POST':
        return _error('Method not allowed. Use POST.', 405, Allow='POST')

    if not services.key_is_configured():
        return _error('Admin registration is not enabled on this server.', 403)

    if services.is_locked_out(request):
        return _error('Too many invalid registration keys. Try again later.', 429,
                      Retry_After=settings.ADMIN_REGISTRATION_LOCKOUT_SECONDS)

    try:
        data = json.loads(request.body or b'')
    except (ValueError, UnicodeDecodeError):
        return _error('Request body must be valid JSON.', 400)
    if not isinstance(data, dict):
        return _error('Request body must be a JSON object.', 400)

    form = AdminRegistrationForm(data, require_confirm=False)
    valid = form.is_valid()

    if form.key_failed:
        services.record_failed_key(request)
        return _error('Invalid registration key.', 403)

    if not valid:
        return JsonResponse({'errors': {field: list(errs) for field, errs in form.errors.items()}}, status=400)

    try:
        user = services.create_admin_user(
            name=form.cleaned_data['name'],
            email=form.cleaned_data['email'],
            phone=form.cleaned_data['phone'],
            password=form.cleaned_data['password'],
        )
    except IntegrityError:
        return JsonResponse({'errors': {'email': ['An account with this email already exists.']}}, status=400)

    return JsonResponse({
        'id': user.pk,
        'name': user.get_full_name(),
        'email': user.email,
        'phone': user.profile.phone,
        'role': user.profile.role,
    }, status=201)
